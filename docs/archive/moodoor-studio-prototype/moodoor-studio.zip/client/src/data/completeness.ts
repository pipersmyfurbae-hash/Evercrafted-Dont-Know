/* Release Fix 25.2 — canonical completeness, conflict, and dependency-aware reflow. */
import { MoodoorDesignRepository, type VNextDesign } from "./vnext";

export type CompletenessSeverity = "PASS" | "WARNING" | "BLOCK";
export type CompletenessIssue = { code: string; severity: CompletenessSeverity; message: string; stage: string; details?: Record<string, unknown> };
export type DesignCompletenessResult = {
  outcome: CompletenessSeverity;
  intentionalMonobotanical: boolean;
  accidentalFamilyCollapse: boolean;
  issues: CompletenessIssue[];
  roleTrace: Array<Record<string, unknown>>;
  sourceStage: string | null;
  summary: string;
};

const upper = (value: unknown) => String(value || "").toUpperCase();
const familyOf = (value: any) => String(value?.family_name || value?.approved_family || value?.family || value?.family_id || "").trim();
const roleKind = (value: any) => upper(value?.role || value?.build_phase || "");
const isSecondary = (value: any) => /SECONDARY/.test(roleKind(value));
const isSupport = (value: any) => /SUPPORT|BRIDGE|TRANSITION|ACCENT|FILLER|ECHO/.test(roleKind(value));
function intervalParts(from: number, to: number) { const start = ((from % 360) + 360) % 360; const end = ((to % 360) + 360) % 360; return start <= end ? [[start, end]] : [[start, 360], [0, end]]; }
function overlaps(aFrom: number, aTo: number, bFrom: number, bTo: number) { return intervalParts(aFrom, aTo).some(([a,b]) => intervalParts(bFrom,bTo).some(([c,d]) => Math.max(a,c) < Math.min(b,d))); }
function intentional(d: VNextDesign) { const record: any = d; const raw: any = d.raw_legacy; return Boolean(record.intentional_monobotanical || record.material_intent?.intentional_monobotanical || raw?.intentional_monobotanical || raw?.material_intent?.intentional_monobotanical); }

function traceRoles(d: VNextDesign) {
  const orch: any[] = d.floral_orchestration?.roles || [];
  const quals: any[] = d.botanical_qualification?.floral_qualifications || [];
  const selections: any[] = d.botanical_selection?.floral_selections || [];
  const resolutions: any[] = d.inventory_resolution?.floral_resolutions || [];
  const placements: any[] = d.blueprint?.placements || [];
  const ecrObjects: any[] = d.ecr?.objects || [];
  return orch.map((role) => {
    const q = quals.find((item) => item.role_id === role.role_id);
    const s = selections.find((item) => item.role_id === role.role_id);
    const r = resolutions.find((item) => item.role_id === role.role_id);
    const bp = placements.filter((item) => item.cluster_id && role.role_id && String(item.build_phase || "").toUpperCase().includes(roleKind(role).includes("PRIMARY") ? "PRIMARY" : roleKind(role).includes("SECONDARY") ? "SECONDARY" : "SUPPORT"));
    const ecr = ecrObjects.filter((item) => item.source_role_id === role.role_id || item.source_placement_id && bp.some((placement) => placement.placement_id === item.source_placement_id));
    return { role: role.role, job: role.reason, role_id: role.role_id, qualified_families: q ? [q.reason, q.required?.hard?.form_class].filter(Boolean) : [], selected_family: familyOf(s), selection_reason: s?.reason || null, role_sharing_decision: q?.shared_family_eligible ?? null, inventory_effect: r ? { sku: r.sku, status: r.status, reason: r.reason } : null, blueprint_result: { placement_count: bp.length, build_phases: Array.from(new Set(bp.map((item) => item.build_phase))) }, ecr_result: { object_count: ecr.length, families: Array.from(new Set(ecr.map((item) => familyOf(item)).filter(Boolean))) } };
  });
}

export function validateDesignCompleteness(d: VNextDesign): DesignCompletenessResult {
  const issues: CompletenessIssue[] = [];
  const orch: any[] = d.floral_orchestration?.roles || [];
  const active = orch.filter((role) => !role.optional);
  const selections: any[] = d.botanical_selection?.floral_selections || [];
  const resolutions: any[] = d.inventory_resolution?.floral_resolutions || [];
  const intentionalMono = intentional(d);
  const hasSecondaryIntent = active.some(isSecondary);
  const roleById = new Map(orch.map((role: any) => [role.role_id, role]));
  const withRole = (item: any) => ({ ...item, role: roleById.get(item.role_id)?.role || item.role, build_phase: item.build_phase || roleById.get(item.role_id)?.role });
  const roleSelections = selections.map(withRole);
  const roleResolutions = resolutions.map(withRole);
  const rolePlacements = (d.blueprint?.placements || []).map((item: any) => ({ ...item, role: item.role || item.build_phase }));
  const families = new Set(roleSelections.map(familyOf).filter(Boolean));
  const roleFamilies = roleSelections.filter((item) => familyOf(item)).map((item) => familyOf(item));
  const hasSecondaryMaterial = roleSelections.some(isSecondary) || roleResolutions.some(isSecondary) || rolePlacements.some(isSecondary);
  const hasSupportIntent = active.some(isSupport);
  const hasSupportMaterial = roleSelections.some(isSupport) || roleResolutions.some(isSupport) || rolePlacements.some(isSupport);
  const expectedFamilyBudget = Number(d.floral_orchestration?.material_family_budget?.minimum || 0);
  if (hasSecondaryIntent && !hasSecondaryMaterial) issues.push({ code: "REQUIRED_SECONDARY_LOST", severity: "BLOCK", message: "A secondary floral movement was requested, but no secondary material survived into the canonical design.", stage: "Floral Orchestration → Materials" });
  if (hasSupportIntent && !hasSupportMaterial) issues.push({ code: "REQUIRED_SUPPORT_LOST", severity: "BLOCK", message: "Supporting floral movement was requested, but no supporting material survived into the canonical design.", stage: "Floral Orchestration → Materials" });
  if (active.length > 1 && families.size <= 1 && !intentionalMono) issues.push({ code: "ACCIDENTAL_FAMILY_COLLAPSE", severity: "BLOCK", message: "Multiple distinct floral jobs collapsed into one family without an intentional monobotanical declaration.", stage: "Botanical Selection", details: { family: Array.from(families)[0] || "unresolved", role_count: active.length } });
  if (expectedFamilyBudget > 1 && families.size < expectedFamilyBudget && !intentionalMono) issues.push({ code: "FAMILY_BUDGET_UNMET", severity: "WARNING", message: "The approved family budget is wider than the material families currently represented.", stage: "Botanical Selection", details: { expected: expectedFamilyBudget, actual: families.size } });
  if (resolutions.some((item) => ["NO_MATCH", "UNKNOWN_AVAILABILITY"].includes(item.status))) issues.push({ code: "INVENTORY_UNAVAILABLE", severity: "BLOCK", message: "Some materials needed for this design aren't available in the current inventory.", stage: "Inventory Resolution" });
  const bp: any = d.blueprint;
  const silence = (bp?.silence_zones || []).filter((zone: any) => zone.enforcement === "hard");
  const sweeps = bp?.greenery_sweeps || [];
  for (const zone of silence) for (const sweep of sweeps) if (overlaps(Number(zone.from_deg), Number(zone.to_deg), Number(sweep.arc_from_deg), Number(sweep.arc_to_deg)) && !sweep.permits_hard_silence) issues.push({ code: "HARD_SILENCE_COLLISION", severity: "BLOCK", message: "One greenery sweep is crossing an area the design is meant to leave open.", stage: "Blueprint", details: { sweep_id: sweep.sweep_id, silence: `${zone.from_deg}–${zone.to_deg}`, sweep: `${sweep.arc_from_deg}–${sweep.arc_to_deg}` } });
  if (bp && ((bp.negative_space_zones || []).length === 0 || (bp.silence_zones || []).length === 0)) issues.push({ code: "MISSING_SPACE_CONTRACT", severity: "BLOCK", message: "The design does not carry its protected quiet-space boundaries into the Blueprint.", stage: "Blueprint" });
  const placementDepth = new Set((bp?.placements || []).map((item: any) => item.depth_plane)).size;
  if (active.length > 2 && placementDepth < 2) issues.push({ code: "DEPTH_COLLAPSE", severity: "WARNING", message: "The material architecture does not yet express more than one depth relationship.", stage: "Blueprint" });
  const outcome = issues.some((item) => item.severity === "BLOCK") ? "BLOCK" : issues.some((item) => item.severity === "WARNING") ? "WARNING" : "PASS";
  const sourceStage = issues[0]?.stage || null;
  const summary = outcome === "BLOCK" ? "We need to resolve one part of your design." : outcome === "WARNING" ? "Your design is usable, with one material note to review." : "The approved material architecture is complete.";
  return { outcome, intentionalMonobotanical: intentionalMono, accidentalFamilyCollapse: issues.some((item) => item.code === "ACCIDENTAL_FAMILY_COLLAPSE"), issues, roleTrace: traceRoles(d), sourceStage, summary };
}

export function reflowBlueprintGreeneryRecord(bp: any) {
  if (!bp) throw new Error("Compile Blueprint before reflowing greenery.");
  const hard = (bp.silence_zones || []).filter((zone: any) => zone.enforcement === "hard");
  const nextSweeps = (bp.greenery_sweeps || []).map((sweep: any) => {
    const length = ((Number(sweep.arc_to_deg) - Number(sweep.arc_from_deg)) + 360) % 360 || 1;
    const collides = hard.some((zone: any) => overlaps(Number(zone.from_deg), Number(zone.to_deg), Number(sweep.arc_from_deg), Number(sweep.arc_to_deg)));
    if (!collides) return sweep;
    const candidates = [188, 260, 20, 300].map((start) => ({ ...sweep, arc_from_deg: start, arc_to_deg: start + length, hard_stop_deg: start + length + 5 }));
    const replacement = candidates.find((candidate) => !hard.some((zone: any) => overlaps(Number(zone.from_deg), Number(zone.to_deg), Number(candidate.arc_from_deg), Number(candidate.arc_to_deg))));
    return replacement || sweep;
  });
  return { ...bp, greenery_sweeps: nextSweeps, status: "REVIEWED" as const, validation: { ...bp.validation, outcome: "PASS" as const, reasons: [...(bp.validation?.reasons || []), "Greenery reflowed around authoritative hard silence; unaffected floral placements preserved."] } };
}

export function reflowBlueprintGreenery(d: VNextDesign) { const next = reflowBlueprintGreeneryRecord(d.blueprint); MoodoorDesignRepository.update(d.canonical_id, { blueprint: next }); return next; }

export const MoodoorDesignCompletenessService = { validate: validateDesignCompleteness, reflowGreenery: reflowBlueprintGreenery };
