import { describe, expect, it } from "vitest";
import { MoodoorDesignCompletenessService, reflowBlueprintGreeneryRecord } from "./completeness";

const base = (overrides: any = {}) => ({
  canonical_id: "MD-000001",
  revision: 1,
  identity: { name: "MD-000001", product_type: "Wreath", size: "24 inch", season: "", notes: "" },
  essence: { memory: "A quiet threshold", essence: "Quiet return", emotional_tags: [] },
  floral_orchestration: { material_family_budget: { minimum: 2 }, roles: [
    { role_id: "R1", role: "PRIMARY_FOCAL", optional: false, reason: "Primary movement" },
    { role_id: "R2", role: "SECONDARY_FOCAL", optional: false, reason: "Secondary movement" },
    { role_id: "R3", role: "SUPPORTING_FLORAL", optional: false, reason: "Support movement" },
  ] },
  botanical_selection: { floral_selections: [
    { role_id: "R1", family_name: "Peony", reason: "best focal fit" },
    { role_id: "R2", family_name: "Peony", reason: "fallback family" },
    { role_id: "R3", family_name: "Peony", reason: "fallback family" },
  ] },
  inventory_resolution: { floral_resolutions: [
    { role_id: "R1", family_name: "Peony", sku: "PH-PEO-IVORY-A", status: "EXACT_MATCH", reason: "in stock" },
    { role_id: "R2", family_name: "Peony", sku: "PH-PEO-IVORY-A", status: "EXACT_MATCH", reason: "in stock" },
    { role_id: "R3", family_name: "Peony", sku: "PH-PEO-IVORY-A", status: "EXACT_MATCH", reason: "in stock" },
  ] },
  blueprint: { silence_zones: [{ from_deg: 112, to_deg: 188, enforcement: "hard" }], negative_space_zones: [{ from_deg: 112, to_deg: 188 }], placements: [{ placement_id: "P1", angle_deg: 40, depth_plane: "foreground", build_phase: "PRIMARY_FLORALS" }], greenery_sweeps: [{ sweep_id: "G2", arc_from_deg: 110, arc_to_deg: 185, zone_id: "Z2", sku: "EU-EUC-SAGE-A" }], validation: { outcome: "PASS", reasons: [] } },
  ...overrides,
});

describe("Release Fix 25.2 completeness", () => {
  it("identifies MD-000001 accidental family collapse and required secondary survival failure", () => {
    const result = MoodoorDesignCompletenessService.validate(base());
    expect(result.outcome).toBe("BLOCK");
    expect(result.accidentalFamilyCollapse).toBe(true);
    expect(result.issues.map((issue) => issue.code)).toContain("HARD_SILENCE_COLLISION");
    expect(result.roleTrace.find((row) => row.role === "PRIMARY_FOCAL")?.selected_family).toBe("Peony");
  });

  it("blocks a requested secondary role that disappears before materials", () => {
    const source = base();
    source.botanical_selection.floral_selections = source.botanical_selection.floral_selections.filter((item: any) => item.role_id !== "R2");
    source.inventory_resolution.floral_resolutions = source.inventory_resolution.floral_resolutions.filter((item: any) => item.role_id !== "R2");
    const result = MoodoorDesignCompletenessService.validate(source);
    expect(result.issues.map((issue) => issue.code)).toContain("REQUIRED_SECONDARY_LOST");
  });

  it("allows declared intentional monobotanical sharing", () => {
    const result = MoodoorDesignCompletenessService.validate(base({ raw_legacy: { intentional_monobotanical: true }, blueprint: { ...base().blueprint, greenery_sweeps: [] } }));
    expect(result.intentionalMonobotanical).toBe(true);
    expect(result.issues.map((issue) => issue.code)).not.toContain("ACCIDENTAL_FAMILY_COLLAPSE");
  });

  it("reflows only the conflicting greenery sweep and preserves floral placement geometry", () => {
    const design = base();
    const before = design.blueprint.placements.map((placement: any) => ({ id: placement.placement_id, angle: placement.angle_deg }));
    const next = reflowBlueprintGreeneryRecord(design.blueprint);
    expect(next.greenery_sweeps[0].arc_from_deg).not.toBe(110);
    expect(next.placements.map((placement: any) => ({ id: placement.placement_id, angle: placement.angle_deg }))).toEqual(before);
    expect(next.validation.reasons.join(" ")).toContain("unaffected floral placements preserved");
  });
});
