/* Moodoor Studio — Botanical Instrument Panel. Unified read service; no writes and no legacy storage access. */
import { LegacyBlueprintAdapter, LegacyCatalogAdapter, LegacyCollectionAdapter, LegacyFeaturedAdapter, LegacyLibraryAdapter, LegacyRenderAdapter, LegacyStoriesAdapter } from "./adapters";
import { getEffectiveEVS } from "./evs";
import { MoodoorIdentityResolver } from "./resolver";
import type { HealthSummary, MoodoorDesign, RenderRef, StoryRef, CollectionRef } from "./models";
import { MoodoorDesignRepository, type VNextDesign } from "./vnext";

const libraryRecords = LegacyLibraryAdapter.read();
const catalogRecords = LegacyCatalogAdapter.read();
const storyRecords = LegacyStoriesAdapter.read();
const renderRecords = LegacyRenderAdapter.read();
const collectionRecords = LegacyCollectionAdapter.read();
const blueprintRecords = LegacyBlueprintAdapter.read();
const featuredRecords = LegacyFeaturedAdapter.read();
const resolver = new MoodoorIdentityResolver(libraryRecords);

function sourcesFor(id: string) {
  return [
    ...libraryRecords.filter((x) => x.normalized.id === id),
    ...catalogRecords.filter((x) => resolver.resolve(x.normalized, "moodoor_catalog").canonicalId === id),
    ...storyRecords.filter((x) => resolver.resolve(x.normalized, "moodoor_stories").canonicalId === id),
    ...renderRecords.filter((x) => resolver.resolve(x.normalized, "moodoor.studio.renders").canonicalId === id),
    ...blueprintRecords.filter((x) => resolver.resolve(x.normalized, "blueprint").canonicalId === id),
    ...featuredRecords.filter((x) => resolver.resolve(x.normalized, "moodoor-featured").canonicalId === id),
  ];
}

function buildDesign(item: any): MoodoorDesign {
  const id = item.id;
  const catalog = catalogRecords.find((x) => x.normalized.id === item.legacy_aliases?.[0]?.legacyId || resolver.resolve(x.normalized, "moodoor_catalog").canonicalId === id)?.normalized;
  const storiesForDesign = storyRecords.filter((x) => x.normalized.library_item_id === id || x.normalized.catalog_id === catalog?.id);
  const rendersForDesign = renderRecords.filter((x) => x.normalized.library_item_id === id);
  const collectionsForDesign = collectionRecords.filter((x) => {
    const members = [...(x.normalized.memberIds || []), ...(x.normalized.members || []).map((m: any) => m.id)];
    return members.some((member: string) => member === id || item.legacy_aliases?.some((a: any) => a.legacyId === member));
  });
  const blueprint = blueprintRecords.find((x) => x.normalized.library_item_id === id)?.normalized;
  const observed = item.observed_evs || catalog?.vector || null;
  const effective = getEffectiveEVS(item.predicted_evs || null, observed);
  const aliases = [{ source: "library_item", legacyId: item.id }, ...(item.legacy_aliases || []).map((a: any) => ({ source: a.source, legacyId: a.id }))];
  const identity = resolver.resolve(item, "library_item");
  return {
    canonicalId: id,
    legacyAliases: aliases,
    origin: { sources: sourcesFor(id).map((x) => x.source), recordCount: sourcesFor(id).length, fixtureMode: true },
    name: item.name || catalog?.name || "Untitled design",
    status: catalog ? "published" : "draft",
    essence: { memory: catalog?.tagline, emotionalTags: item.predicted_evs ? Object.entries(item.predicted_evs).sort(([, a], [, b]) => (b as number) - (a as number)).slice(0, 3).map(([key]) => key) : [] },
    predictedEvs: item.predicted_evs || null,
    observedEvs: observed,
    effectiveEvs: effective,
    territory: { id: item.territoryId ?? catalog?.territoryId ?? null, name: item.territoryName ?? catalog?.territoryName ?? null },
    blueprint: blueprint ? { blueprintId: blueprint.blueprint_id, formula: blueprint.formula, canvas: { type: blueprint.canvas.type, diameterIn: blueprint.canvas.diameter_in }, silenceArcs: blueprint.silence_arcs, buildSpec: blueprint.build_spec } : null,
    materials: (item.materials || []).map((m: any) => ({ sku: m.sku, species: m.species, canonId: m.canon_id, colorName: m.color_name, primaryHex: m.primary_hex, primaryRole: m.primary_role, qty: m.qty })),
    renders: rendersForDesign.map((x) => ({ renderId: x.normalized.render_id, type: x.normalized.type, status: x.normalized.image_reference ? "linked" : "missing", imageReference: x.normalized.image_reference, imageReferenceKind: x.normalized.image_reference_kind, observedEvs: x.normalized.observed_evs } as RenderRef)),
    stories: storiesForDesign.map((x) => ({ storyId: x.normalized.story_id, title: x.normalized.title, status: x.normalized.library_item_id ? "linked" : "orphan", sourceMode: x.normalized.source_mode, memory: x.normalized.memory, paragraphs: x.normalized.paras } as StoryRef)),
    collections: collectionsForDesign.map((x) => ({ collectionId: x.normalized.collection_id, name: x.normalized.name, membershipStatus: "linked", memberCount: (x.normalized.memberIds || x.normalized.members || []).length, unresolvedMembers: [] } as CollectionRef)),
    commerce: { orderIds: [], committedSkus: [] },
    production: { jobIds: [], statuses: [] },
    publishing: { publicAliases: featuredRecords.filter((x) => x.normalized.library_item_id === id).map((x) => x.normalized.public_route), status: catalog ? "public" : "draft" },
    createdAt: null, updatedAt: null, schemaVersion: "studio.v1", identity, rawSources: sourcesFor(id).map((x) => ({ source: x.source, sourceId: x.sourceId, raw: x.raw })),
  };
}

const designs = libraryRecords.map((x) => ({ ...buildDesign(x.normalized), sourceKind: "legacy" as const }));
function buildVNextDesign(record: VNextDesign): MoodoorDesign {
  return {
    canonicalId: record.canonical_id, sourceKind: "vnext", vnextMeta: { status: record.status, originType: record.origin.type, revision: record.revision, createdAt: record.created_at, updatedAt: record.updated_at },
    legacyAliases: record.legacy_aliases.map((a) => ({ source: a.source, legacyId: a.legacy_id })), origin: { sources: ["moodoor.vnext.designs"], recordCount: 1, fixtureMode: false }, name: record.identity.name, status: record.status === "ARCHIVED" ? "unresolved" : "draft", essence: { memory: record.essence.memory, emotionalTags: record.essence.emotional_tags }, predictedEvs: record.predicted_evs, observedEvs: record.observed_evs, effectiveEvs: record.effective_evs, territory: record.territory, blueprint: null, materials: [], renders: [], stories: [], collections: [], commerce: { orderIds: [], committedSkus: [] }, production: { jobIds: [], statuses: [] }, publishing: { publicAliases: [], status: "draft" }, createdAt: record.created_at, updatedAt: record.updated_at, schemaVersion: "studio.v1", identity: { status: "EXACT", canonicalId: record.canonical_id, evidence: [{ tier: 1, matchedBy: "canonical_id", detail: "Native vNext canonical ID" }], aliases: record.legacy_aliases.map((a) => ({ source: a.source, legacyId: a.legacy_id })) }, rawSources: [{ source: "moodoor.vnext.designs", sourceId: record.canonical_id, raw: record }],
  };
}
export const MoodoorLibraryService = {
  getAllDesigns: () => [...designs, ...MoodoorDesignRepository.list().map(buildVNextDesign)],
  getDesignByCanonicalId: (id: string) => MoodoorLibraryService.getAllDesigns().find((d) => d.canonicalId === id),
  getDesignAliases: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.legacyAliases || [],
  getDesignStories: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.stories || [],
  getDesignRenders: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.renders || [],
  getDesignCollections: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.collections || [],
  getDesignBlueprint: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.blueprint || null,
  getEffectiveEVS: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.effectiveEvs || { vector: null, source: "missing" as const },
  getIdentityStatus: (id: string) => MoodoorLibraryService.getDesignByCanonicalId(id)?.identity || null,
  getHealthSummary: (): HealthSummary => ({ legacyLibraryItems: libraryRecords.length, catalogRecords: catalogRecords.length, stories: storyRecords.length, renders: renderRecords.length, collections: collectionRecords.length, orders: 1, exactMatches: designs.filter((d) => d.identity.status === "EXACT").length, resolvedAliases: MoodoorLibraryService.getAllDesigns().reduce((n, d) => n + d.legacyAliases.length, 0), ambiguousRecords: 0, orphans: storyRecords.filter((s) => !s.normalized.library_item_id).length + renderRecords.filter((r) => !r.normalized.library_item_id).length, duplicateCandidates: 0, missingRenderPayloads: rendersForMissing(), missingStories: designs.filter((d) => d.stories.length === 0).length, brokenCollectionMembership: collectionRecords.filter((c) => !(c.normalized.memberIds?.length || c.normalized.members?.length)).length }),
  getVNextDesign: (id: string) => MoodoorDesignRepository.get(id),
  fixtureMode: true,
};
function rendersForMissing() { return renderRecords.filter((r) => !r.normalized.image_reference).length; }
