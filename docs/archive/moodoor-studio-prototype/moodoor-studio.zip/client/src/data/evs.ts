/* Moodoor Studio — Botanical Instrument Panel. EVS behavior mirrors the approved compatibility rules. */
import { EVS_AXES, type EVSAxis, type EVSVector } from "./models";

export function isValidEVS(value: unknown): value is EVSVector {
  if (!value || typeof value !== "object") return false;
  return EVS_AXES.every((axis) => {
    const n = (value as Record<EVSAxis, unknown>)[axis];
    return typeof n === "number" && Number.isFinite(n) && n >= 0 && n <= 1;
  });
}

export function getPredictedEVS(predicted: EVSVector | null) { return predicted; }
export function getObservedEVS(observed: EVSVector | null) { return isValidEVS(observed) ? observed : null; }
export function getEffectiveEVS(predicted: EVSVector | null, observed: EVSVector | null) {
  const validObserved = getObservedEVS(observed);
  if (validObserved) return { vector: validObserved, source: "observed" as const };
  if (isValidEVS(predicted)) return { vector: predicted, source: "predicted" as const };
  return { vector: null, source: "missing" as const };
}

export function getEVSDrift(predicted: EVSVector | null, observed: EVSVector | null) {
  if (!isValidEVS(predicted) || !isValidEVS(observed)) return { drift: false, available: false, axes: [] as Array<{ axis: EVSAxis; delta: number }> };
  const axes = EVS_AXES.map((axis) => ({ axis, delta: Number((observed[axis] - predicted[axis]).toFixed(3)) })).filter((item) => Math.abs(item.delta) > 0.15);
  return { drift: axes.length > 0, available: true, axes };
}
