/* Moodoor Studio — Botanical Instrument Panel. Candidate matches never auto-merge. */
import type { AdapterRecord } from "./adapters";
import type { IdentityResult, LegacyAlias, MoodoorDesign } from "./models";

export class MoodoorIdentityResolver {
  private byLibraryId = new Map<string, string>();
  private byCatalogId = new Map<string, string[]>();
  private byBlueprintId = new Map<string, string>();
  constructor(private readonly library: Array<AdapterRecord<any>>) {
    library.forEach((record) => {
      const item = record.normalized;
      this.byLibraryId.set(item.id, item.id);
      this.byBlueprintId.set(item.blueprint_id, item.id);
      (item.legacy_aliases || []).forEach((alias: LegacyAlias) => {
        const current = this.byCatalogId.get(alias.legacyId) || [];
        this.byCatalogId.set(alias.legacyId, [...current, item.id]);
      });
    });
  }
  resolve(record: any, source: string): IdentityResult {
    const aliases: LegacyAlias[] = [];
    if (record.id && this.byLibraryId.has(record.id)) return { status: "EXACT", canonicalId: record.id, evidence: [{ tier: 1, matchedBy: "library_item_id", detail: "Exact LibraryItem id" }], aliases: [{ source, legacyId: record.id }] };
    if (record.library_item_id && this.byLibraryId.has(record.library_item_id)) return { status: "EXACT", canonicalId: record.library_item_id, evidence: [{ tier: 1, matchedBy: "library_item_id", detail: "Explicit foreign key" }], aliases: [{ source, legacyId: record.library_item_id }] };
    if (record.blueprint_id && this.byBlueprintId.has(record.blueprint_id)) return { status: "RESOLVED", canonicalId: this.byBlueprintId.get(record.blueprint_id)!, evidence: [{ tier: 2, matchedBy: "blueprint_id", detail: "Stable blueprint alias" }], aliases: [{ source, legacyId: record.blueprint_id }] };
    if (record.id && this.byCatalogId.has(record.id)) {
      const candidates = this.byCatalogId.get(record.id)!;
      if (candidates.length === 1) return { status: "RESOLVED", canonicalId: candidates[0], evidence: [{ tier: 4, matchedBy: "legacy_alias", detail: "Exact catalog crosswalk" }], aliases: [{ source, legacyId: record.id }] };
      return { status: "AMBIGUOUS", canonicalId: null, evidence: [{ tier: 5, matchedBy: "legacy_alias", detail: `Multiple candidates: ${candidates.join(", ")}` }], aliases: [{ source, legacyId: record.id }] };
    }
    return { status: "ORPHAN", canonicalId: null, evidence: [{ tier: 5, matchedBy: "none", detail: "No exact identity evidence; no fuzzy merge attempted" }], aliases: record.id ? [{ source, legacyId: record.id }] : aliases };
  }
}
