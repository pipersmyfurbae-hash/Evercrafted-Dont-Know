import { afterEach, describe, expect, it } from "vitest";
import { MoodoorPublishingService } from "./publishing";
import { VNEXT_KEYS, VNEXT_PUBLIC_ENTRY_SCHEMA_VERSION, type MoodoorPublicEntry } from "./vnext";

const storage=new Map<string,string>();
Object.defineProperty(globalThis,"localStorage",{value:{getItem:(key:string)=>storage.get(key)||null,setItem:(key:string,value:string)=>storage.set(key,value),removeItem:(key:string)=>storage.delete(key),clear:()=>storage.clear()},configurable:true});
const entry=(slug:string,status:MoodoorPublicEntry["status"]="PUBLISHED"):MoodoorPublicEntry=>({public_entry_id:`PUB-${slug}`,schema_version:VNEXT_PUBLIC_ENTRY_SCHEMA_VERSION,content_type:"DESIGN",source_id:"D-1",source_revision:1,slug,canonical_path:`/designs/${slug}`,title:"Quiet Winter",summary:"A botanical record.",hero_asset:null,content:{public_story:""},seo:{title:"Quiet Winter | Moodoor",description:"A botanical record.",canonical_url:`http://localhost/designs/${slug}`},commerce:{price:null,currency:null,availability:null,sku:null},status,published_at:status==="PUBLISHED"?new Date().toISOString():null,revision:1,redirect_history:[],memory_mode:"DO_NOT_PUBLISH",provenance:{source_snapshot:{}}});
afterEach(()=>storage.clear());

describe("MoodoorPublishingService",()=>{
  it("keeps public entries in a dedicated canonical store",()=>{localStorage.setItem(VNEXT_KEYS.publicEntries,JSON.stringify([entry("quiet-winter")]));expect(MoodoorPublishingService.list()[0].schema_version).toBe("MOODOOR_PUBLIC_ENTRY_V1");expect(localStorage.getItem("moodoor.vnext.designs")).toBeNull();});
  it("does not publish an unapproved or unknown source",()=>{expect(()=>MoodoorPublishingService.createPublicEntry("DESIGN","missing-design")).not.toThrow();const created=MoodoorPublishingService.list()[0];expect(created.status).toBe("PREVIEW");expect(()=>MoodoorPublishingService.publish(created.public_entry_id)).toThrow(/approved/i);});
  it("resolves slug collisions without overwriting the first entry",()=>{localStorage.setItem(VNEXT_KEYS.publicEntries,JSON.stringify([entry("quiet-winter")]));expect(MoodoorPublishingService.resolveSlug("DESIGN","Quiet Winter")).toBe("quiet-winter-2");expect(MoodoorPublishingService.list()).toHaveLength(1);});
  it("marks only the published source snapshot stale",()=>{localStorage.setItem(VNEXT_KEYS.publicEntries,JSON.stringify([entry("quiet-winter"),entry("draft", "DRAFT")]));const result=MoodoorPublishingService.markStaleBySource("DESIGN","D-1");expect(result[0].status).toBe("STALE");expect(MoodoorPublishingService.list()[1].status).toBe("DRAFT");});
});
