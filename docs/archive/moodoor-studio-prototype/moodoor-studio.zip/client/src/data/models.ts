/* Moodoor Studio — Botanical Instrument Panel. Runtime-only canonical model; no persistence. */

export const EVS_AXES = ["warmth", "energy", "nostalgia", "valence", "intimacy", "restraint", "seasonal"] as const;
export type EVSAxis = (typeof EVS_AXES)[number];
export type EVSVector = Record<EVSAxis, number>;
export type IdentityStatus = "EXACT" | "RESOLVED" | "AMBIGUOUS" | "ORPHAN";

export type LegacyAlias = { source: string; legacyId: string };
export type Evidence = { tier: 1 | 2 | 3 | 4 | 5; matchedBy: string; detail: string };
export type IdentityResult = { status: IdentityStatus; canonicalId: string | null; evidence: Evidence[]; aliases: LegacyAlias[] };
export type MaterialRef = { sku: string; species?: string; canonId?: string; colorName?: string; primaryHex?: string; primaryRole?: string; qty?: number };
export type StoryRef = { storyId: string; title: string; status: "linked" | "orphan"; sourceMode: string; memory?: string; paragraphs?: string[] };
export type RenderRef = { renderId: string; type: string; status: "linked" | "missing" | "unverified"; imageReference?: string | null; imageReferenceKind?: string; observedEvs?: EVSVector | null };
export type CollectionRef = { collectionId: string; name: string; membershipStatus: "linked" | "partial"; memberCount: number; unresolvedMembers: string[] };
export type BlueprintRef = { blueprintId: string; formula?: string; canvas?: { type: string; diameterIn: number }; silenceArcs?: Array<Record<string, unknown>>; buildSpec?: Record<string, unknown> };
export type CommerceRef = { orderIds: string[]; committedSkus: Array<Record<string, unknown>> };
export type ProductionRef = { jobIds: string[]; statuses: string[] };
export type PublishingRef = { publicAliases: string[]; status: "public" | "draft" | "unknown" };

export type MoodoorDesign = {
  canonicalId: string;
  sourceKind?: "legacy" | "vnext";
  vnextMeta?: { status: string; originType: string; revision: number; createdAt: string; updatedAt: string };
  legacyAliases: LegacyAlias[];
  origin: { sources: string[]; recordCount: number; fixtureMode: boolean };
  name: string;
  status: "published" | "draft" | "unresolved";
  essence: { memory?: string; emotionalTags: string[] };
  predictedEvs: EVSVector | null;
  observedEvs: EVSVector | null;
  effectiveEvs: { vector: EVSVector | null; source: "observed" | "predicted" | "missing" };
  territory: { id: number | null; name: string | null };
  blueprint: BlueprintRef | null;
  materials: MaterialRef[];
  renders: RenderRef[];
  stories: StoryRef[];
  collections: CollectionRef[];
  commerce: CommerceRef;
  production: ProductionRef;
  publishing: PublishingRef;
  createdAt: string | null;
  updatedAt: string | null;
  schemaVersion: "studio.v1";
  identity: IdentityResult;
  rawSources: Array<{ source: string; sourceId: string | null; raw: unknown }>;
};

export type HealthSummary = {
  legacyLibraryItems: number;
  catalogRecords: number;
  stories: number;
  renders: number;
  collections: number;
  orders: number;
  exactMatches: number;
  resolvedAliases: number;
  ambiguousRecords: number;
  orphans: number;
  duplicateCandidates: number;
  missingRenderPayloads: number;
  missingStories: number;
  brokenCollectionMembership: number;
};
