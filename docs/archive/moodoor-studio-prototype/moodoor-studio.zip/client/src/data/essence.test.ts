import { afterEach, describe, expect, it } from "vitest";
import { EVS_AXES } from "./models";
import { MoodoorEssenceService } from "./essence";
import { MoodoorDesignRepository } from "./vnext";

const storage = new Map<string, string>();
const localStorageMock = { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => storage.set(key, value), removeItem: (key: string) => storage.delete(key), clear: () => storage.clear() };
Object.defineProperty(globalThis, "localStorage", { value: localStorageMock, configurable: true });
function make(memory: string) { return MoodoorDesignRepository.create({ identity: { name: "Interpretation fixture", product_type: "Finished wreath", size: "18 inch", season: "", notes: "" }, origin: { type: "memory", source_id: null, source_type: null, source_label: null, created_by_flow: "essence-test" }, essence: { memory, essence: "", emotional_tags: [] }, predicted_evs: null, observed_evs: null, effective_evs: { vector: null, source: "missing" }, territory: { id: null, name: null }, design: { blueprint: null, materials: [], renders: [], stories: [], collections: [] }, commerce: { price: null, orders: [] }, production: { jobs: [] }, publishing: { status: "draft", public_aliases: [] }, legacy_aliases: [], raw_legacy: null }); }
afterEach(() => storage.clear());

describe("MoodoorEssenceService", () => {
  it.each([
    ["warm childhood holiday memory", "Christmas morning at my grandmother's house, warm cider and laughter.", true],
    ["quiet remembrance", "The porch is empty now, but September light still returns.", true],
    ["travel memory", "A cold hotel lobby in London, dark wood and a long train home.", true],
    ["conflicting emotions", "We celebrated together while knowing the goodbye was close.", true],
    ["short fragment", "Amber porch light.", true],
    ["literal memory", "Christmas in London with Ralph Lauren, dark wood and plaid.", true],
    ["low cue memory", "I remember being there.", true],
  ])("interprets %s without downstream design decisions", (_label, memory, expected) => {
    const design = make(memory); const result = MoodoorEssenceService.interpretMemory(design);
    expect(Boolean(result.essence)).toBe(expected);
    expect(result.memory_signals.length).toBeGreaterThan(0);
    expect(Object.keys(result.predicted_evs)).toEqual([...EVS_AXES]);
    for (const axis of EVS_AXES) expect(result.predicted_evs[axis]).toBeGreaterThanOrEqual(0);
    expect(result.avoid_literalizing.length).toBeGreaterThan(0);
    expect(result.design_intent).not.toHaveProperty("flowers");
    expect(result.design_intent).not.toHaveProperty("clock_position");
    expect(design.observed_evs).toBeNull();
    expect(result.raw_response).toBeTruthy();
  });

  it("preserves emotional tension and approval through candidate regeneration", () => {
    const design = make("My family returned home for a bright celebration, with the absence of someone we loved.");
    const first = MoodoorEssenceService.interpretMemory(design);
    expect(first.emotional_tension).toContain("+");
    const current = MoodoorDesignRepository.get(design.canonical_id)!;
    const candidate = MoodoorEssenceService.regenerateEssence(current);
    expect(candidate.interpretation_revision).toBeGreaterThan(first.interpretation_revision);
    expect(MoodoorDesignRepository.get(design.canonical_id)?.interpretation_candidates?.length).toBe(1);
    const approved = MoodoorEssenceService.approveEssence(MoodoorDesignRepository.get(design.canonical_id)!, first);
    expect(approved.status).toBe("APPROVED");
    expect(MoodoorDesignRepository.get(design.canonical_id)?.downstream_stale).toBe(true);
  });
});
