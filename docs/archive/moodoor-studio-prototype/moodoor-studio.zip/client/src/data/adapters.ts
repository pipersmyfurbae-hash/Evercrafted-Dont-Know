/* Moodoor Studio — Botanical Instrument Panel. Adapters only read bundled fixtures; no legacy keys are touched. */
import catalog from "./fixtures/catalog.json";
import libraryItems from "./fixtures/library_items.json";
import stories from "./fixtures/stories.json";
import renders from "./fixtures/renders.json";
import collections from "./fixtures/collections.json";
import blueprints from "./fixtures/blueprints.json";
import featured from "./fixtures/featured_public.json";

export type AdapterRecord<T> = { source: string; sourceId: string | null; normalized: T; raw: T; errors: string[]; missingRelationships: string[] };
const wrap = <T>(source: string, sourceId: string | null, normalized: T, raw: T, missingRelationships: string[] = [], errors: string[] = []): AdapterRecord<T> => ({ source, sourceId, normalized, raw, errors, missingRelationships });

export const LegacyLibraryAdapter = { read: () => libraryItems.map((item) => wrap("library_item", item.id, item, item)) };
export const LegacyCatalogAdapter = { read: () => catalog.map((item) => wrap("moodoor_catalog", item.id, item, item)) };
export const LegacyStoriesAdapter = { read: () => stories.map((item) => wrap("moodoor_stories", item.story_id, item, item, item.library_item_id ? [] : ["library_item_id"])) };
export const LegacyRenderAdapter = { read: () => renders.map((item) => wrap("moodoor.studio.renders", item.render_id, item, item, item.library_item_id ? [] : ["library_item_id", "image_reference"])) };
export const LegacyCollectionAdapter = { read: () => collections.map((item) => wrap("moodoor_collections", item.collection_id, item, item, item.memberIds?.length || item.members?.length ? [] : ["members"])) };
export const LegacyBlueprintAdapter = { read: () => blueprints.map((item) => wrap("blueprint", item.blueprint_id, item, item, item.library_item_id ? [] : ["library_item_id"])) };
export const LegacyFeaturedAdapter = { read: () => featured.map((item) => wrap("moodoor-featured", item.featured_id, item, item, item.library_item_id ? [] : ["library_item_id"])) };

export const allLegacyAdapters = [LegacyLibraryAdapter, LegacyCatalogAdapter, LegacyStoriesAdapter, LegacyRenderAdapter, LegacyCollectionAdapter, LegacyBlueprintAdapter, LegacyFeaturedAdapter];
