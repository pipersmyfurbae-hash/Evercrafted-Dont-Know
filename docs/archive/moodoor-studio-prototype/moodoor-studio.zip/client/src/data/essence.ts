/* Moodoor Studio — Botanical Instrument Panel. Sprint 3 interpretation only; no materials, geometry, renders, or legacy writes. */
import { EVS_AXES, type EVSAxis } from "./models";
import { MoodoorActivityRepository, MoodoorDesignRepository, nowIso, type InterpretationRecord, type VNextDesign } from "./vnext";
import { MoodoorFocalService } from "./focal";

const VERSION = "essence.v1";
const MODEL = "moodoor-deterministic-interpreter";
const clamp = (value: number) => Math.max(0, Math.min(1, Number(value.toFixed(2))));
const words = (memory: string) => memory.toLowerCase().replace(/[^a-z0-9'\s-]/g, " ").split(/\s+/).filter(Boolean);
const has = (text: string, list: string[]) => list.some((item) => text.includes(item));
const unique = (items: string[]) => Array.from(new Set(items)).slice(0, 12);

function signals(memory: string) {
  const text = memory.trim(); const lower = text.toLowerCase(); const tokens = words(text);
  const memorySignals = unique(tokens.filter((token) => token.length > 3 && !["with", "from", "that", "this", "were", "always", "there", "about", "into", "have", "when", "they", "just", "very"].includes(token)));
  const sensory: Record<string, string[]> = {};
  const groups: Record<string, string[]> = { temperature: ["cold", "warm", "cool", "heat", "frost", "snow", "summer", "winter"], material: ["wood", "wool", "plaid", "stone", "linen", "screen door", "leather"], light: ["amber", "candle", "sunlight", "dark", "lamplight", "glow"], weather: ["rain", "snow", "wind", "fog", "storm", "autumn", "winter", "spring", "summer"], color: ["red", "blue", "green", "gold", "white", "black", "brown"], space: ["porch", "hotel", "room", "garden", "doorway", "kitchen", "street"] };
  for (const [category, vocabulary] of Object.entries(groups)) { const found = vocabulary.filter((item) => lower.includes(item)); if (found.length) sensory[category] = found; }
  const symbolicSignals = [
    lower.includes("door") ? { source: "doorway", interpretation: "arrival, threshold, and return" } : null,
    lower.includes("snow") || lower.includes("fog") ? { source: "weather hush", interpretation: "suspension and quiet" } : null,
    lower.includes("candle") || lower.includes("warm") || lower.includes("fire") ? { source: "interior warmth", interpretation: "protection and intimacy" } : null,
    lower.includes("grandmother") || lower.includes("grandfather") || lower.includes("family") ? { source: "inheritance", interpretation: "continuity across time" } : null,
  ].filter(Boolean) as Array<{ source: string; interpretation: string }>;
  return { text, lower, memorySignals, sensory, symbolicSignals };
}

function deriveEVS(lower: string, sensory: Record<string, string[]>) {
  const warmth = clamp(0.42 + (has(lower, ["warm", "welcome", "cider", "home", "family", "grandmother", "hotel lobby"]) ? 0.26 : 0) + (sensory.temperature?.includes("cold") ? 0.04 : 0));
  const energy = clamp(0.38 + (has(lower, ["celebration", "party", "travel", "bright", "running", "dance"]) ? 0.22 : 0) - (has(lower, ["quiet", "still", "hush", "remembrance"]) ? 0.1 : 0));
  const nostalgia = clamp(0.36 + (has(lower, ["remember", "grandmother", "childhood", "return", "old", "tradition", "always"]) ? 0.32 : 0));
  const valence = clamp(0.54 + (has(lower, ["loss", "absence", "grief", "sad", "goodbye"]) ? -0.18 : 0) + (has(lower, ["joy", "love", "welcome", "celebration"]) ? 0.16 : 0));
  const intimacy = clamp(0.38 + (has(lower, ["my", "grandmother", "family", "porch", "hotel", "small", "private"]) ? 0.25 : 0));
  const restraint = clamp(0.54 + (has(lower, ["quiet", "still", "tailored", "old-world", "simple", "hush"]) ? 0.18 : 0) - (has(lower, ["bright", "party", "crowd"]) ? 0.08 : 0));
  const seasonal = clamp(0.34 + (Object.keys(sensory).includes("weather") ? 0.26 : 0) + (has(lower, ["christmas", "september", "autumn", "winter", "summer"]) ? 0.2 : 0));
  return { warmth, energy, nostalgia, valence, intimacy, restraint, seasonal };
}

function interpret(record: VNextDesign, revision: number): InterpretationRecord {
  const memory = record.essence.memory.trim(); const { lower, memorySignals, sensory, symbolicSignals } = signals(memory);
  const loss = has(lower, ["loss", "absence", "gone", "grief", "goodbye", "missing"]); const joy = has(lower, ["joy", "celebration", "welcome", "laughter", "holiday"]); const returnCue = has(lower, ["return", "again", "home", "back", "always", "tradition"]);
  const center = loss ? (returnCue ? "quiet remembrance" : "release") : returnCue ? "belonging and return" : joy ? "shared wonder" : has(lower, ["travel", "london", "paris", "road", "hotel"]) ? "threshold and discovery" : "a feeling still becoming clear";
  const tension = loss && returnCue ? "warmth + absence" : joy && has(lower, ["old", "past", "remember", "nostalgia"]) ? "celebration + nostalgia" : has(lower, ["wonder", "quiet", "still", "hush"]) ? "wonder + stillness" : has(lower, ["travel", "home", "distance"]) ? "belonging + distance" : "presence + possibility";
  const evs = deriveEVS(lower, sensory); const reasonBase = `Derived from the memory's observed cues: ${memorySignals.slice(0, 5).join(", ") || "a short source fragment"}.`;
  const evsRationales: Record<string, string> = {}; for (const axis of EVS_AXES) evsRationales[axis] = `${axis} reflects ${axis === "warmth" ? "the degree of welcome and interior feeling" : axis === "nostalgia" ? "the pull of remembered time" : axis === "restraint" ? "the degree of quiet control" : "the emotional cues present in the source"}. ${reasonBase}`;
  const territory = has(lower, ["christmas", "winter", "snow", "old-world", "heritage"]) ? { territory_id: 2, territory_name: "Heritage Winter", confidence: 0.78, reason: "Seasonal and continuity cues point toward an inherited, winter-facing territory." } : has(lower, ["porch", "september", "cider", "autumn", "return"]) ? { territory_id: 1, territory_name: "Returning Porch", confidence: 0.82, reason: "Return, threshold, and late-season domestic cues cluster in this existing territory." } : { territory_id: null, territory_name: "Unresolved / human review", confidence: 0.42, reason: "The memory does not contain enough territory-specific evidence for a confident assignment." };
  const designIntent = { presence: evs.intimacy > 0.65 ? "quiet" : "present", movement: evs.energy > 0.65 ? "lively" : "slow", density: evs.restraint > 0.68 ? "restrained" : "balanced", restraint: evs.restraint > 0.68 ? "high" : "moderate", negative_space: evs.intimacy > 0.65 ? "significant" : "measured", visual_tension: tension, directionality: evs.energy > 0.65 ? "outward" : "ascending", hierarchy: evs.intimacy > 0.65 ? "single-dominant" : "layered", rhythm: evs.nostalgia > 0.68 ? "repeating with interruption" : "measured" };
  return { interpretation_id: `${record.canonical_id}-INT-${String(revision).padStart(3, "0")}`, interpretation_revision: revision, status: "GENERATED", generated_at: nowIso(), approved_at: null, source_memory_revision: record.revision, model: MODEL, prompt_version: VERSION, essence: memory.length < 20 ? `A small fragment carrying ${center}.` : `The emotional center is ${center}; literal details should support that feeling without replacing it.`, emotional_center: center, emotional_tension: tension, memory_signals: memorySignals, sensory_signals: sensory, symbolic_signals: symbolicSignals, avoid_literalizing: unique([...(has(lower, ["london", "paris", "new york"]) ? ["landmark replicas", "tourist shorthand"] : []), ...(has(lower, ["christmas", "holiday"]) ? ["literal themed ornaments", "repeating seasonal symbols"] : []), "do not turn the memory into a literal set decoration"]), predicted_evs: evs, evs_rationales: evsRationales, territory, design_intent: designIntent, heard_check: { value: memorySignals.length > 0, rationale: memorySignals.length ? "The interpretation retains concrete cues from the supplied memory." : "The source is too brief for a strong heard check." }, unexpected_check: { value: !has(lower, ["big ben", "polo horse", "union jack"]), rationale: "The interpretation keeps abstraction between emotional truth and literal motif." }, raw_response: { generated_from: memory, model: MODEL } };
}

export const MoodoorEssenceService = {
  interpretMemory(record: VNextDesign) { const next = interpret(record, (record.interpretation?.interpretation_revision || 0) + 1); MoodoorDesignRepository.update(record.canonical_id, { essence: { ...record.essence, essence: next.essence }, interpretation: next, predicted_evs: next.predicted_evs, territory: { id: next.territory.territory_id, name: next.territory.territory_name }, downstream_stale: true }); if (record.composition) MoodoorFocalService.markFocalStale(record);
    MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "interpretation_generated", label: "Interpretation generated", detail: `candidate ${next.interpretation_id}`, at: next.generated_at, revision: record.revision + 1 }); return next; },
  regenerateEssence(record: VNextDesign) { const next = interpret(record, (record.interpretation?.interpretation_revision || 0) + 1); const current = MoodoorDesignRepository.get(record.canonical_id); MoodoorDesignRepository.update(record.canonical_id, { interpretation_candidates: [...(current?.interpretation_candidates || []), next] }); return next; },
  reviewEssence(record: VNextDesign, candidate: InterpretationRecord) { const reviewed = { ...candidate, status: "REVIEWED" as const }; MoodoorDesignRepository.update(record.canonical_id, { interpretation_candidates: (record.interpretation_candidates || []).map((item) => item.interpretation_id === candidate.interpretation_id ? reviewed : item) }); return reviewed; },
  approveEssence(record: VNextDesign, interpretation: InterpretationRecord = record.interpretation as InterpretationRecord) { if (!interpretation) throw new Error("No interpretation available to approve"); const approved = { ...interpretation, status: "APPROVED" as const, approved_at: nowIso() }; MoodoorDesignRepository.update(record.canonical_id, { essence: { ...record.essence, essence: approved.essence }, interpretation: approved, interpretation_candidates: [], predicted_evs: approved.predicted_evs, territory: { id: approved.territory.territory_id, name: approved.territory.territory_name }, downstream_stale: true }); if (record.composition) MoodoorFocalService.markFocalStale(record);
    MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "interpretation_approved", label: "Essence approved", detail: approved.interpretation_id, at: approved.approved_at, revision: record.revision + 1 }); return approved; },
  hasApproved(record: VNextDesign) { return record.interpretation?.status === "APPROVED"; },
};
