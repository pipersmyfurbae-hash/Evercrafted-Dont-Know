/* Sprint 7: characteristic-space botanical job descriptions only. */
import { MoodoorActivityRepository, MoodoorDesignRepository, nowIso, type BotanicalFloralQualification, type BotanicalQualificationRecord, type GreeneryQualification, type VNextDesign } from "./vnext";

const ENGINE_VERSION = "botanical-qualification.v1";
const MODEL = "moodoor-characteristic-qualifier";
const FORBIDDEN = /\b(hydrangea|peony|ranunculus|rose|anemone|eucalyptus|cedar|pine|SKU|vendor)\b|\b(stem count|exact quantity|5\.5-inch)\b/i;

type Role = NonNullable<VNextDesign["floral_orchestration"]>["roles"][number];
type Zone = NonNullable<VNextDesign["greenery_architecture"]>["greenery_zones"][number];

function requireApproved(record: VNextDesign) {
  if (record.interpretation?.status !== "APPROVED") throw new Error("Approve Essence before botanical qualification");
  if (record.composition?.status !== "APPROVED") throw new Error("Approve Composition before botanical qualification");
  if (record.greenery_architecture?.status !== "APPROVED") throw new Error("Approve Greenery Architecture before botanical qualification");
  if (record.floral_orchestration?.status !== "APPROVED") throw new Error("Approve Floral Orchestration before botanical qualification");
}

function floralQualification(role: Role, variation: number, index: number): BotanicalFloralQualification {
  const primary = role.role === "PRIMARY_FOCAL";
  const bridge = role.role === "BRIDGE" || role.role === "TRANSITION";
  const directional = role.role === "DIRECTIONAL_ACCENT";
  const form = variation % 2 === 0 ? role.form_requirement : primary ? "mass" : directional ? "spray" : role.form_requirement;
  const required = {
    hard: {
      form_class: [form],
      apparent_scale: primary ? "large_to_hero" : role.scale_class,
      structural_substance: primary ? "substantial" : "moderate",
      nesting_ability: role.interweaving_intent.includes("nested") ? "medium_to_high" : "medium",
      movement: role.movement_requirement,
      stem_behavior: directional ? "flexible_or_branching" : primary ? "supportive" : "clustered",
      orientation_capability: directional ? ["outward", "lateral", "multi_directional"] : ["radial", "multi_directional"],
      faux_read_requirement: "premium_faux_naturalistic",
    },
    soft: {
      silhouette: primary ? (variation % 2 ? "rounded_irregular" : "open") : bridge ? "branching" : "compact",
      surface: primary ? "matte_textile" : "soft_matte",
      visual_density: role.visual_weight === "dominant" ? "high" : role.visual_weight === "restrained" ? "light" : "medium",
      edge_behavior: role.interweaving_intent === "exposed" ? "clean_edge" : "interruptible",
      texture_complexity: primary ? "moderate" : "low_to_moderate",
      temperature_behavior: "flexible",
      saturation_behavior: "restrained",
      color_behavior: primary ? "quiet_dominant" : bridge ? "bridge_tone" : role.role === "ACCENT" ? "accent_contrast" : "supporting",
    },
  };
  return {
    qualification_id: `${role.role_id}-BQ`,
    role_id: role.role_id,
    role: role.role,
    required,
    preferred: { hard: {}, soft: { texture_contrast_role: primary ? "anchor" : bridge ? "bridge" : role.role === "ACCENT" ? "punctuate" : "blend", faux_read_requirement: "structured_faux" } },
    avoid: { hard: primary ? ["too_delicate", "too_wispy", "too_small", "fresh_cut_read"] : directional ? ["rigid_compact_orb", "overly_dense"] : bridge ? ["overly_dense", "too_symmetrical"] : ["too_glossy", "flat"], soft: ["species_lookup", "meadow_like", "weed_like"] },
    tolerances: { family_reuse: "share only when form, depth, and hierarchy remain compatible", exact_color: "never specified", exact_quantity: "never specified" },
    reason: `Botanical job description for ${role.role.replaceAll("_", " ")} at hierarchy ${role.hierarchy}; preserve approved pocket, flow, depth, and interweaving without naming material.`,
    qualification_cluster_id: role.role === "PRIMARY_FOCAL" || role.role === "ECHO" ? "QC-01" : bridge ? "QC-02" : null,
    shared_family_eligible: role.role !== "PRIMARY_FOCAL",
  };
}

function greeneryQualification(zone: Zone, index: number): GreeneryQualification {
  return {
    qualification_id: `${zone.zone_id}-GQ`,
    zone_id: zone.zone_id,
    required: { hard: { form: zone.role === "directional_extension" ? "branching" : "branching_or_mass", movement: zone.movement, stiffness: zone.strength === "primary" ? "supportive" : "flexible_or_supportive", depth: zone.depth_behavior === "quiet" ? ["background"] : ["background", "midground"] }, soft: { leaf_scale: index % 2 ? "medium_broad" : "medium_fine", density: zone.density, silhouette_effect: zone.radial_behavior === "outward" ? "extension" : "supportive_mass", edge_behavior: "interruptible", structural_longevity: "premium_faux_structured" } },
    preferred: { hard: {}, soft: { trailing_capability: zone.movement === "descending" ? "moderate_to_high" : "low_to_moderate", directional_capability: zone.radial_behavior, visual_weight: zone.strength } },
    avoid: { hard: ["species_lookup", "meadow_like", "weed_like"], soft: ["overly_dense", "flat_pasted_on_edge"] },
    tolerances: { depth: "follow approved zone depth", exact_species: "not specified" },
    reason: `Qualify structural greenery for ${zone.role.replaceAll("_", " ")} with ${zone.movement} movement and ${zone.depth_behavior} depth.`,
    qualification_cluster_id: null,
    shared_family_eligible: true,
  };
}

export const MoodoorBotanicalQualificationValidator = {
  validate(record: BotanicalQualificationRecord) {
    const reasons: string[] = [];
    if (!record.floral_qualifications.length) reasons.push("Every active floral role must receive a qualification.");
    if (!record.greenery_qualifications.length) reasons.push("Every active greenery zone must receive a qualification.");
    for (const item of [...record.floral_qualifications, ...record.greenery_qualifications]) { if (JSON.stringify(item).match(FORBIDDEN)) reasons.push(`${item.qualification_id} contains forbidden species, material, SKU, or exact-quantity language.`); }
    const recordText = JSON.stringify({ ...record, raw_response: null });
    if (recordText.match(FORBIDDEN)) reasons.push("Qualification record contains a forbidden species, material, SKU, or disguised exact-size reference.");
    for (const item of record.floral_qualifications) if (String(item.required.hard.apparent_scale).match(/inch|cm|mm|\d/)) reasons.push(`${item.qualification_id} contains exact size language.`);
    if (record.floral_qualifications.some((item) => item.role === "PRIMARY_FOCAL" && Array.isArray(item.required.hard.form_class) && item.required.hard.form_class.includes("micro"))) reasons.push("PRIMARY_FOCAL cannot require micro form.");
    const members = record.qualification_clusters.flatMap((cluster) => cluster.member_ids);
    if (new Set(members).size !== members.length) reasons.push("Qualification clusters duplicate a member.");
    const blocked = reasons.some((reason) => /must|contains|cannot|duplicate/.test(reason));
    return { outcome: blocked ? "BLOCK" as const : reasons.length ? "WARNING" as const : "PASS" as const, reasons };
  },
};

function build(record: VNextDesign, variation: number): BotanicalQualificationRecord {
  const orchestration = record.floral_orchestration!;
  const architecture = record.greenery_architecture!;
  const at = nowIso();
  const floral_qualifications = orchestration.roles.filter((role) => !role.optional).map((role, index) => floralQualification(role, variation, index));
  const greenery_qualifications = architecture.greenery_zones.map(greeneryQualification);
  const clusters = [
    { cluster_id: "QC-01", member_ids: floral_qualifications.filter((item) => item.qualification_cluster_id === "QC-01").map((item) => item.qualification_id), compatibility_reason: "A shared focal family may satisfy the same form space at different scales.", scale_differences: ["hero versus small", "singular versus sparse repeat"] },
    { cluster_id: "QC-02", member_ids: floral_qualifications.filter((item) => item.qualification_cluster_id === "QC-02").map((item) => item.qualification_id), compatibility_reason: "Bridge and transition roles may share directional or airy behavior.", scale_differences: ["small versus micro"] },
  ].filter((cluster) => cluster.member_ids.length > 0);
  const qualification_set_id = `${record.canonical_id}-BQ-${String((record.botanical_qualification?.qualification_revision || 0) + variation + 1).padStart(3, "0")}`;
  const output: BotanicalQualificationRecord = {
    qualification_set_id,
    qualification_revision: (record.botanical_qualification?.qualification_revision || 0) + variation + 1,
    source_orchestration_id: orchestration.orchestration_id,
    source_orchestration_revision: orchestration.orchestration_revision,
    source_architecture_revision: architecture.architecture_revision,
    source_composition_revision: orchestration.source_composition_revision,
    source_interpretation_revision: orchestration.source_interpretation_revision,
    generated_at: at,
    approved_at: null,
    engine_version: ENGINE_VERSION,
    model: MODEL,
    status: "GENERATED",
    floral_qualifications,
    greenery_qualifications,
    qualification_clusters: clusters,
    floral_family_budget: { ...orchestration.material_family_budget, reason: "Inherited from approved orchestration; never expanded silently." },
    greenery_family_budget: { target: 2, minimum: 1, maximum: 3, reason: "Keep structural greenery families coherent across approved zones." },
    future_scoring_contract: { weights: { form_fit: 0.16, scale_fit: 0.14, movement_fit: 0.12, depth_fit: 0.1, nesting_fit: 0.12, texture_fit: 0.08, surface_fit: 0.08, color_behavior_fit: 0.08, hierarchy_fit: 0.08, faux_read_fit: 0.04 }, role_overrides: { PRIMARY_FOCAL: { scale_fit: 0.2, hierarchy_fit: 0.16, nesting_fit: 0.14 }, BRIDGE: { movement_fit: 0.18, depth_fit: 0.14, texture_fit: 0.1 }, DIRECTIONAL_ACCENT: { movement_fit: 0.2, form_fit: 0.16, depth_fit: 0.12 } }, note: "Weights evaluate future candidates only; no candidate is scored in Sprint 7." },
    validation: { outcome: "PASS", reasons: [] },
    rationale: `Characteristic-space qualifications for ${floral_qualifications.length} floral roles and ${greenery_qualifications.length} greenery zones. Species, color names, exact counts, and inventory references are excluded.`,
    provenance: { qualification_set_id, qualification_revision: (record.botanical_qualification?.qualification_revision || 0) + variation + 1, source_orchestration_id: orchestration.orchestration_id, source_orchestration_revision: orchestration.orchestration_revision, source_architecture_revision: architecture.architecture_revision, source_composition_revision: orchestration.source_composition_revision, source_interpretation_revision: orchestration.source_interpretation_revision, generated_at: at, approved_at: null, engine_version: ENGINE_VERSION, model: MODEL },
    raw_response: { characteristic_space_only: true, species_selected: false, inventory_queried: false, exact_quantities: false, variation },
  };
  output.validation = MoodoorBotanicalQualificationValidator.validate(output);
  return output;
}

export const MoodoorBotanicalQualificationService = {
  generateQualifications(record: VNextDesign) { requireApproved(record); const candidates = [0, 1, 2].map((variation) => build(record, variation)); const active = candidates[0]; if (active.validation.outcome === "BLOCK") throw new Error(active.validation.reasons.join("; ")); MoodoorDesignRepository.update(record.canonical_id, { botanical_qualification: active, botanical_qualification_candidates: candidates }); MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "qualification_generated", label: "Botanical qualifications generated", detail: candidates.map((item) => item.qualification_set_id).join(", "), at: active.generated_at, revision: record.revision + 1 }); return { active, candidates }; },
  generateCandidates(record: VNextDesign) { return this.generateQualifications(record).candidates; },
  regenerateQualifications(record: VNextDesign) { return this.generateQualifications(record); },
  editQualification(record: VNextDesign, qualificationId: string, patch: Partial<BotanicalFloralQualification>) { requireApproved(record); if (!record.botanical_qualification) throw new Error("Generate botanical qualifications before editing"); const floral_qualifications = record.botanical_qualification.floral_qualifications.map((item) => item.qualification_id === qualificationId ? { ...item, ...patch } : item); const edited = { ...record.botanical_qualification, floral_qualifications, qualification_revision: record.botanical_qualification.qualification_revision + 1, status: "REVIEWED" as const }; edited.validation = MoodoorBotanicalQualificationValidator.validate(edited); MoodoorDesignRepository.update(record.canonical_id, { botanical_qualification: edited }); return edited; },
  approveQualifications(record: VNextDesign) { requireApproved(record); if (!record.botanical_qualification) throw new Error("Generate botanical qualifications before approving"); if (record.botanical_qualification.validation.outcome === "BLOCK") throw new Error(record.botanical_qualification.validation.reasons.join("; ")); const at = nowIso(); const approved = { ...record.botanical_qualification, status: "APPROVED" as const, approved_at: at, provenance: { ...record.botanical_qualification.provenance, approved_at: at } }; MoodoorDesignRepository.update(record.canonical_id, { botanical_qualification: approved, botanical_qualification_candidates: [] }); MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "qualification_approved", label: "Botanical qualifications approved", detail: approved.qualification_set_id, at, revision: record.revision + 1 }); return approved; },
  markStale(record: VNextDesign) { if (!record.botanical_qualification || record.botanical_qualification.status === "STALE") return null; const stale = { ...record.botanical_qualification, status: "STALE" as const }; MoodoorDesignRepository.update(record.canonical_id, { botanical_qualification: stale }); return stale; },
};
