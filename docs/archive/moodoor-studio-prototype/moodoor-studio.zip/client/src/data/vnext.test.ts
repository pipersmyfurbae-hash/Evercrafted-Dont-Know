import { afterEach, describe, expect, it } from "vitest";
import { MoodoorDesignRepository, MoodoorActivityRepository, VNEXT_KEYS, type VNextDesign } from "./vnext";

const storage = new Map<string, string>();
const localStorageMock = { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => storage.set(key, value), removeItem: (key: string) => storage.delete(key), clear: () => storage.clear() };
Object.defineProperty(globalThis, "localStorage", { value: localStorageMock, configurable: true });

function input() {
  return { identity: { name: "Test wreath", product_type: "Finished wreath", size: "18 inch", season: "autumn", notes: "" }, origin: { type: "memory" as const, source_id: null, source_type: null, source_label: null, created_by_flow: "test" }, essence: { memory: "A porch in October", essence: "Carry a quiet threshold", emotional_tags: [] }, predicted_evs: null, observed_evs: null, effective_evs: { vector: null, source: "missing" as const }, territory: { id: null, name: null }, design: { blueprint: null, materials: [], renders: [], stories: [], collections: [] }, commerce: { price: null, orders: [] }, production: { jobs: [] }, publishing: { status: "draft" as const, public_aliases: [] }, legacy_aliases: [], raw_legacy: null };
}

afterEach(() => storage.clear());

describe("MoodoorDesignRepository write safety", () => {
  it("creates a stable canonical ID in the vNext namespace", () => {
    const record = MoodoorDesignRepository.create(input());
    expect(record.canonical_id).toBe("MD-000001");
    expect(record.status).toBe("DRAFT");
    expect(storage.has(VNEXT_KEYS.designs)).toBe(true);
    expect(storage.has("moodoor_catalog")).toBe(false);
  });

  it("edits only the targeted vNext record and increments revision/history", () => {
    const first = MoodoorDesignRepository.create(input());
    const second = MoodoorDesignRepository.create({ ...input(), identity: { ...input().identity, name: "Second" } });
    const edited = MoodoorDesignRepository.update(first.canonical_id, { essence: { ...first.essence, essence: "A held breath at dusk" } });
    expect(edited.revision).toBe(2);
    expect(MoodoorDesignRepository.get(second.canonical_id)?.revision).toBe(1);
    expect(MoodoorActivityRepository.list(first.canonical_id).map((entry) => entry.action)).toEqual(["created", "edited"]);
  });

  it("archives without deleting and restores the same canonical ID", () => {
    const record = MoodoorDesignRepository.create(input());
    const archived = MoodoorDesignRepository.transition(record.canonical_id, "ARCHIVED");
    expect(archived.status).toBe("ARCHIVED");
    expect(MoodoorDesignRepository.get(record.canonical_id)).toBeTruthy();
    const restored = MoodoorDesignRepository.transition(record.canonical_id, "DRAFT");
    expect(restored.canonical_id).toBe(record.canonical_id);
    expect(restored.status).toBe("DRAFT");
    expect(MoodoorActivityRepository.list(record.canonical_id).map((entry) => entry.action)).toEqual(["created", "archived", "restored"]);
  });

  it("rejects invalid status transitions", () => {
    const record = MoodoorDesignRepository.create(input());
    expect(() => MoodoorDesignRepository.transition(record.canonical_id, "PUBLISHED")).toThrow("Invalid Sprint 2 transition");
  });
});
