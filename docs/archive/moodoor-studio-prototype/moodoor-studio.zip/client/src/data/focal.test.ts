import { afterEach, describe, expect, it } from "vitest";
import { MoodoorEssenceService } from "./essence";
import { MoodoorFocalService, clockToAngle } from "./focal";
import { MoodoorDesignRepository } from "./vnext";
const storage = new Map<string, string>();
const localStorageMock = { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => storage.set(key, value), removeItem: (key: string) => storage.delete(key), clear: () => storage.clear() };
Object.defineProperty(globalThis, "localStorage", { value: localStorageMock, configurable: true });
function make(memory: string) { return MoodoorDesignRepository.create({ identity: { name: "Composition fixture", product_type: "Finished wreath", size: "18 inch", season: "", notes: "" }, origin: { type: "memory", source_id: null, source_type: null, source_label: null, created_by_flow: "focal-test" }, essence: { memory, essence: "", emotional_tags: [] }, predicted_evs: null, observed_evs: null, effective_evs: { vector: null, source: "missing" }, territory: { id: null, name: null }, design: { blueprint: null, materials: [], renders: [], stories: [], collections: [] }, commerce: { price: null, orders: [] }, production: { jobs: [] }, publishing: { status: "draft", public_aliases: [] }, legacy_aliases: [], raw_legacy: null }); }
function approved(memory: string) { const design = make(memory); const interpretation = MoodoorEssenceService.interpretMemory(design); return MoodoorEssenceService.approveEssence(MoodoorDesignRepository.get(design.canonical_id)!, interpretation) && MoodoorDesignRepository.get(design.canonical_id)!; }
afterEach(() => storage.clear());

describe("MoodoorFocalService", () => {
  it("blocks composition until Essence is approved", () => { const design = make("A quiet porch in September."); expect(() => MoodoorFocalService.generateFocalIntent(design)).toThrow(/Approve Essence/); });
  it.each([
    ["high warmth + nostalgia + restraint", "My grandmother's September porch, cider waiting, the screen door never quite closed."],
    ["high energy celebration", "A bright celebration with laughter, dancing, and everyone arriving at once."],
    ["warmth + absence", "We gathered for a warm holiday while feeling the absence of someone we loved."],
    ["wonder + stillness", "Snow outside, candlelight inside, and the quiet wonder of staying still."],
    ["high intimacy", "A small private room where my family kept the same ritual every winter."],
    ["low seasonal signal", "I remember being there with someone I loved."],
  ])("generates a valid composition for %s", (_label, memory) => {
    const design = approved(memory); const result = MoodoorFocalService.generateFocalIntent(design);
    expect(result.candidates).toHaveLength(3); expect(result.active.primary_focal.start_clock).toMatch(/^([1-9]|1[0-2]):\d{2}$/); expect(result.active.primary_focal.end_clock).toMatch(/^([1-9]|1[0-2]):\d{2}$/); expect(result.active.silence_zone.start_clock).toBeTruthy(); expect(result.active.eye_entry.clock).toBeTruthy(); expect(result.active.eye_rest.clock).toBeTruthy(); expect(result.active.secondary_movement.strength).not.toBe("dominant"); expect(result.active.raw_response).toMatchObject({ no_materials: true }); expect(design.design.materials).toHaveLength(0); });
  it("uses a stable clock convention and supports multiple valid solutions", () => { expect(clockToAngle("12:00")).toBe(0); expect(clockToAngle("3:00")).toBe(90); expect(clockToAngle("6:00")).toBe(180); expect(clockToAngle("9:00")).toBe(270); const first = approved("A dark wood hotel lobby in London, tailored warmth and old-world quiet."); const second = approved("My grandmother's porch in September, cider and a screen door."); const a = MoodoorFocalService.generateFocalIntent(first); const b = MoodoorFocalService.generateFocalIntent(second); expect(a.candidates.map((item) => item.composition_family)).not.toEqual(b.candidates.map((item) => item.composition_family)); });
  it("approves composition without changing the design lifecycle status", () => { const design = approved("A quiet remembrance held beside a warm interior light."); const generated = MoodoorFocalService.generateFocalIntent(design); const chosen = MoodoorFocalService.chooseFocalCandidate(MoodoorDesignRepository.get(design.canonical_id)!, generated.candidates[1]); expect(chosen.status).toBe("REVIEWED"); const approvedComposition = MoodoorFocalService.approveFocalIntent(MoodoorDesignRepository.get(design.canonical_id)!); expect(approvedComposition.status).toBe("APPROVED"); expect(MoodoorDesignRepository.get(design.canonical_id)?.status).toBe("DRAFT"); expect(MoodoorDesignRepository.get(design.canonical_id)?.design.blueprint).toBeNull(); });
  it("marks composition stale when Essence is revised", () => { const design = approved("A quiet remembrance held beside a warm interior light."); MoodoorFocalService.generateFocalIntent(design); MoodoorFocalService.approveFocalIntent(MoodoorDesignRepository.get(design.canonical_id)!); const before = MoodoorDesignRepository.get(design.canonical_id)!; expect(before.composition?.status).toBe("APPROVED"); MoodoorEssenceService.interpretMemory(before); const after = MoodoorDesignRepository.get(design.canonical_id)!; expect(after.composition?.status).toBe("STALE"); expect(after.composition?.composition_id).toBe(before.composition?.composition_id); });
});
