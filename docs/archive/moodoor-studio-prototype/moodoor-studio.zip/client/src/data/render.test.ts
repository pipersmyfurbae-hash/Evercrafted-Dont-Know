import { describe, expect, it, afterEach } from "vitest";
import { MoodoorRenderBridge, MoodoorReferenceMockAdapter } from "./render";
import { MoodoorDesignRepository } from "./vnext";
const storage = new Map<string, string>();
Object.defineProperty(globalThis, "localStorage", { value: { getItem: (key: string) => storage.get(key) ?? null, setItem: (key: string, value: string) => storage.set(key, value), clear: () => storage.clear() }, configurable: true });

const make = (overrides: any = {}) => ({
  canonical_id: "MD-000001", schema_version: "vnext.design.v1", created_at: "2026-01-01T00:00:00.000Z", updated_at: "2026-01-01T00:00:00.000Z", status: "DRAFT", identity: { name: "Render fixture" }, origin: { type: "blank" }, legacy_aliases: [],
  revision: 1,
  blueprint: {
    blueprint_id: "BP-1", blueprint_revision: 1, status: "APPROVED",
    placements: [{ placement_id: "P-1" }], greenery_sweeps: [], silence_zones: [], negative_space_zones: [],
  },
  ecr: {
    ecr_id: "ECR-1", ecr_revision: 1, status: "APPROVED", validation: { outcome: "PASS", reasons: [] },
    objects: [{ object_id: "ECR-P-1", type: "botanical", source_placement_id: "P-1", sku: "SKU-1", family: "focal", angle_deg: 30, radius_norm: .8, depth_plane: "foreground" }],
    relationships: [], canvas: { type: "polar", outer_diameter_in: 24 }, foundation: { type: "grapevine" }, render_constraints: { preserve_silence: true },
  },
  ...overrides,
});

afterEach(() => localStorage.clear());

describe("MoodoorRenderBridge", () => {
  it("blocks missing input approvals", () => {
    expect(() => MoodoorRenderBridge.prepareRender(make({ ecr: { status: "COMPILED", ecr_id: "ECR-1", ecr_revision: 1, validation: { outcome: "PASS", reasons: [] } } }))).toThrow("ECR is not APPROVED");
    expect(() => MoodoorRenderBridge.prepareRender(make({ ecr: { status: "STALE", ecr_id: "ECR-1", ecr_revision: 1, validation: { outcome: "PASS", reasons: [] } } }))).toThrow("ECR is not APPROVED");
  });
  it("creates a structured package without mutating ECR", () => {
    const d = make(); const source = JSON.stringify(d.ecr); const pkg = MoodoorReferenceMockAdapter.compile(d.ecr, MoodoorRenderBridge.getPresentationProfile());
    expect(MoodoorReferenceMockAdapter.validate(pkg).outcome).toBe("PASS"); expect(pkg.design_contract.objects[0]).toBeTruthy(); expect(pkg.negative_constraints.length).toBeGreaterThan(0); expect(JSON.stringify(d.ecr)).toBe(source); expect(pkg.provenance.qc_status).toBe("NOT_STARTED");
  });
  it("submits honestly through the mock boundary and defers QC", async () => {
    const d = make(); const pkg = MoodoorReferenceMockAdapter.compile(d.ecr, MoodoorRenderBridge.getPresentationProfile()); const saved = MoodoorReferenceMockAdapter.normalizeResult(await MoodoorReferenceMockAdapter.submit(pkg), pkg);
    expect(saved.status).toBe("FAILED"); expect(saved.image_uri).toBeNull(); expect(saved.qc_status).toBe("NOT_STARTED"); expect(String((saved.raw_result as any).note)).toContain("No external image renderer");
  });
  it("marks packages and results stale together", () => {
    const d: any = make(); d.render_package = { ...MoodoorReferenceMockAdapter.compile(d.ecr, MoodoorRenderBridge.getPresentationProfile()), status: "VALIDATED" }; d.render_result = { render_result_id: "RR-1", render_package_id: d.render_package.render_package_id, renderer: d.render_package.renderer, adapter_version: d.render_package.adapter_version, status: "NORMALIZED", external_submission_id: null, image_uri: null, received_at: "", normalized_at: "", source_ecr_id: "ECR-1", source_ecr_revision: 1, provenance: {}, qc_status: "NOT_STARTED", raw_result: null };
    MoodoorDesignRepository.saveAll([d as any]); const stale = MoodoorRenderBridge.markStale(d); expect(stale.render_package?.status).toBe("STALE"); expect(stale.render_result?.status).toBe("STALE");
  });
});
