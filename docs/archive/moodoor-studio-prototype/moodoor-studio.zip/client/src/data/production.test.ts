import { describe, expect, it, beforeEach } from "vitest";
import { MoodoorProductionInventoryService, MoodoorProductionService } from "./production";
import { VNEXT_KEYS, MoodoorDesignRepository } from "./vnext";

const storage = new Map<string,string>();
(globalThis as typeof globalThis & { localStorage: Storage }).localStorage = { clear:()=>storage.clear(), getItem:(key:string)=>storage.get(key) ?? null, setItem:(key:string,value:string)=>{storage.set(key,value)}, removeItem:(key:string)=>{storage.delete(key)}, key:(index:number)=>Array.from(storage.keys())[index] ?? null, get length(){return storage.size}};

describe("Sprint 19 production boundary", () => {
  beforeEach(() => { localStorage.clear(); });
  it("keeps reservation separate from consumption and blocks overcommit", () => {
    MoodoorProductionInventoryService.receive({ sku:"stem-1", quantity:10, source:"fixture", reason:"opening stock" });
    const first = MoodoorProductionInventoryService.createReservation({ order_id:"ORD-1", line_item_id:"ORD-1-01", requirements:{"stem-1":6} });
    expect(first.ok).toBe(true);
    expect(MoodoorProductionInventoryService.getAvailability("stem-1")).toMatchObject({ on_hand:10, reserved:6, available:4 });
    const second = MoodoorProductionInventoryService.createReservation({ order_id:"ORD-2", line_item_id:"ORD-2-01", requirements:{"stem-1":6} });
    expect(second.ok).toBe(false);
    expect(second.shortages[0].shortage).toBe(2);
  });
  it("releases unconsumed reservation on cancellation", () => {
    MoodoorProductionInventoryService.receive({ sku:"stem-2", quantity:4, source:"fixture", reason:"opening stock" });
    const reservation = MoodoorProductionInventoryService.createReservation({ order_id:"ORD-3", line_item_id:"ORD-3-01", requirements:{"stem-2":3} });
    expect(reservation.ok).toBe(true);
    MoodoorProductionInventoryService.releaseReservation("ORD-3");
    expect(MoodoorProductionInventoryService.getAvailability("stem-2")).toMatchObject({ reserved:0, available:4 });
  });
  it("does not write to legacy storage", () => {
    expect(localStorage.getItem("moodoor.orders")).toBeNull();
    expect(localStorage.getItem(VNEXT_KEYS.orders)).toBeNull();
  });
  it("keeps a production order tied to an exact design revision and Blueprint revision", () => {
    const design = MoodoorDesignRepository.list().find(d=>d.status === "APPROVED");
    if (!design || !design.blueprint) return;
    const result = MoodoorProductionService.createProductionOrder({ designId:design.canonical_id, quantity:2 });
    expect(result.order.line_items[0].design_revision).toBe(design.revision);
    expect(result.order.line_items[0].blueprint_revision).toBe(design.blueprint.blueprint_revision);
    expect(result.order.line_items[0].total_requirements).toBeDefined();
  });
});
