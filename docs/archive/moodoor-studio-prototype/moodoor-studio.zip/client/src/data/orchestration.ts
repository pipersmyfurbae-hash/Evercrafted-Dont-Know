/* Moodoor Studio — role-first floral orchestration. No botanical identity, inventory, SKU, or blueprint behavior. */
import {
  MoodoorActivityRepository,
  MoodoorDesignRepository,
  nowIso,
  type FloralOrchestrationRecord,
  type FloralRole,
  type OrchestrationValidation,
  type VNextDesign,
} from "./vnext";

const ENGINE_VERSION = "orchestration.v1";
const MODEL = "moodoor-role-orchestrator";

type Architecture = NonNullable<VNextDesign["greenery_architecture"]>;
type Pocket = Architecture["greenery_pockets"][number];
type RoleRecord = FloralOrchestrationRecord["roles"][number];

const hash = (value: string) => Array.from(value).reduce((sum, char) => (sum * 31 + char.charCodeAt(0)) % 997, 17);

function requireApproved(record: VNextDesign) {
  if (record.interpretation?.status !== "APPROVED") throw new Error("Approve Essence before generating floral orchestration");
  if (record.composition?.status !== "APPROVED") throw new Error("Approve Composition before generating floral orchestration");
  if (record.greenery_architecture?.status !== "APPROVED") throw new Error("Approve Greenery Architecture before generating floral orchestration");
}

function isEligible(pocket: Pocket, role: FloralRole) {
  const roles = pocket.eligible_roles.map((item) => item.toLowerCase());
  if (roles.includes(role.toLowerCase())) return true;
  if (["SUPPORTING_FLORAL", "SECONDARY_FOCAL", "ECHO"].includes(role)) return roles.includes("secondary_floral");
  if (["ACCENT", "TEXTURAL_ACCENT", "DIRECTIONAL_ACCENT", "BRIDGE", "TRANSITION"].includes(role)) return roles.includes("accent") || roles.includes("secondary_floral");
  return false;
}

function selectRole(index: number, count: number, energy: number, restraint: number, hasSecondary: boolean): FloralRole {
  if (index === 0) return "PRIMARY_FOCAL";
  if (index === 1 && hasSecondary) return "SECONDARY_FOCAL";
  if (index === 1) return "SUPPORTING_FLORAL";
  if (index === 2) return energy > 0.65 ? "DIRECTIONAL_ACCENT" : "BRIDGE";
  if (index === 3 && count > 3) return restraint > 0.68 ? "ECHO" : "TRANSITION";
  return "ACCENT";
}

function shapeFor(role: FloralRole, pocket: Pocket, variation: number) {
  const shapes: Record<FloralRole, Pick<RoleRecord, "scale_class" | "quantity_intent" | "visual_weight" | "form_requirement" | "movement_requirement" | "interweaving_intent">> = {
    PRIMARY_FOCAL: { scale_class: "hero", quantity_intent: "singular_or_tight_group", visual_weight: "dominant", form_requirement: variation % 2 ? "cluster" : "mass", movement_requirement: "contained", interweaving_intent: "deeply_nested" },
    SECONDARY_FOCAL: { scale_class: "large", quantity_intent: "singular", visual_weight: "strong", form_requirement: "cup", movement_requirement: "nest", interweaving_intent: "nested" },
    SUPPORTING_FLORAL: { scale_class: "medium", quantity_intent: "small_group", visual_weight: "moderate", form_requirement: "cluster", movement_requirement: "frame", interweaving_intent: "nested" },
    BRIDGE: { scale_class: "small", quantity_intent: "sparse_repeat", visual_weight: "restrained", form_requirement: "line", movement_requirement: "separate", interweaving_intent: "edge_interwoven" },
    ACCENT: { scale_class: "small", quantity_intent: "singular", visual_weight: "punctual", form_requirement: "orb", movement_requirement: "punctuate", interweaving_intent: "exposed" },
    TEXTURAL_ACCENT: { scale_class: "micro", quantity_intent: "sparse_repeat", visual_weight: "punctual", form_requirement: "airy", movement_requirement: "soften", interweaving_intent: "lightly_interwoven" },
    DIRECTIONAL_ACCENT: { scale_class: "small", quantity_intent: "sparse_repeat", visual_weight: "restrained", form_requirement: "spray", movement_requirement: "directional", interweaving_intent: "edge_interwoven" },
    ECHO: { scale_class: "small", quantity_intent: "singular", visual_weight: "restrained", form_requirement: "disc", movement_requirement: "repeat", interweaving_intent: "lightly_interwoven" },
    TRANSITION: { scale_class: "small", quantity_intent: "sparse_repeat", visual_weight: "restrained", form_requirement: "airy", movement_requirement: "release", interweaving_intent: "edge_interwoven" },
  };
  const shaped = shapes[role];
  const depth_behavior: RoleRecord["depth_behavior"] = role === "PRIMARY_FOCAL" ? "foreground_midground" : role === "BRIDGE" ? "midground_background" : pocket.depth_plane;
  const radial_behavior: RoleRecord["radial_behavior"] = pocket.radial_band === "middle_outer" ? "core" : pocket.radial_band === "extension" ? "extension" : pocket.radial_band === "outer" ? "outer" : "inner";
  return {
    ...shaped,
    depth_behavior,
    radial_behavior,
    occlusion_intent: {
      greenery_behind: role !== "ACCENT",
      greenery_between: ["PRIMARY_FOCAL", "BRIDGE", "SUPPORTING_FLORAL"].includes(role),
      greenery_in_front: role === "PRIMARY_FOCAL" ? "selective" as const : role === "ACCENT" ? "none" as const : "selective" as const,
    },
  };
}

export const MoodoorFloralOrchestrationValidator = {
  validate(orchestration: FloralOrchestrationRecord, architecture: Architecture): OrchestrationValidation {
    const reasons: string[] = [];
    const roles = orchestration.roles.filter((role) => !role.optional);
    const primary = roles.find((role) => role.role === "PRIMARY_FOCAL");
    if (!primary) reasons.push("A PRIMARY_FOCAL role is required when floral presence is intended.");
    const pocketMap = new Map(architecture.greenery_pockets.map((pocket) => [pocket.pocket_id, pocket]));
    for (const role of roles) {
      if (!role.pocket_id) { reasons.push(`${role.role} has no pocket assignment.`); continue; }
      const pocket = pocketMap.get(role.pocket_id);
      if (!pocket) { reasons.push(`${role.role} references a missing pocket.`); continue; }
      if (!isEligible(pocket, role.role)) reasons.push(`${role.role} is not eligible for ${role.pocket_id}.`);
      if (role.role === "PRIMARY_FOCAL" && !["hero", "large"].includes(pocket.capacity)) reasons.push("PRIMARY_FOCAL exceeds pocket capacity.");
      if (role.role === "SECONDARY_FOCAL" && ["accent", "small"].includes(pocket.capacity)) reasons.push("SECONDARY_FOCAL exceeds pocket capacity.");
    }
    if (roles.filter((role) => role.visual_weight === "dominant").length > 1) reasons.push("More than one dominant floral role is active.");
    if (new Set(roles.map((role) => role.depth_behavior)).size < 2 && roles.length > 2) reasons.push("All active floral roles occupy one depth relationship.");
    if (new Set(roles.map((role) => role.radial_behavior)).size < 2 && roles.length > 2) reasons.push("All active floral roles occupy one radial relationship.");
    if (roles.length > 3 && !roles.some((role) => role.role === "BRIDGE" || role.role === "TRANSITION")) reasons.push("Role map risks bouquet behavior without a bridge or transition.");
    if (roles.filter((role) => ["ACCENT", "TEXTURAL_ACCENT", "DIRECTIONAL_ACCENT"].includes(role.role)).length > 3) reasons.push("Role map risks confetti behavior through accent overload.");
    const forbidden = JSON.stringify(orchestration).match(/hydrangea|peony|ranunculus|rose|anemone|eucalyptus|cedar|pine|dusty miller|SKU|vendor|inventory quantity/i);
    if (forbidden) reasons.push("Botanical, vendor, SKU, or inventory data entered the role contract.");
    const blocking = reasons.some((reason) => /required|missing|not eligible|exceeds|dominant|bouquet|confetti|entered/.test(reason));
    return { outcome: blocking ? "BLOCK" : reasons.length ? "WARNING" : "PASS", reasons };
  },
};

function buildCandidate(record: VNextDesign, index: number): FloralOrchestrationRecord {
  const interpretation = record.interpretation!;
  const architecture = record.greenery_architecture!;
  const composition = record.composition!;
  const seed = hash(`${record.canonical_id}:${interpretation.emotional_center}:${composition.composition_family}:${architecture.architecture_id}:${index}`);
  const restraint = interpretation.predicted_evs.restraint;
  const energy = interpretation.predicted_evs.energy;
  const pockets = architecture.greenery_pockets;
  const activeCount = restraint > 0.7 ? Math.min(3, pockets.length) : Math.min(4, pockets.length);
  const candidatePockets = index === 0 ? pockets : index === 1 ? [pockets[0], ...pockets.slice(2), pockets[1]].filter(Boolean) : [pockets[0], ...pockets.slice(1).reverse()];
  const hasSecondary = composition.secondary_movement.type !== "none" && energy > 0.45;
  const roles: RoleRecord[] = candidatePockets.slice(0, activeCount).map((pocket, pocketIndex) => {
    let role = selectRole(pocketIndex, activeCount, energy, restraint, hasSecondary);
    if (!isEligible(pocket, role)) role = pocketIndex === 0 ? "PRIMARY_FOCAL" : pocket.eligible_roles.some((item) => item.toLowerCase() === "accent") ? "ACCENT" : "SUPPORTING_FLORAL";
    const shaped = shapeFor(role, pocket, index + seed);
    return {
      role_id: `${record.canonical_id}-FR-${String(index * 10 + pocketIndex + 1).padStart(2, "0")}`,
      role,
      pocket_id: pocket.pocket_id,
      hierarchy: pocketIndex + 1,
      ...shaped,
      reason: role === "PRIMARY_FOCAL" ? "Give the approved emotional center one dominant, materially unresolved job." : role === "BRIDGE" ? "Relate separated design events without filling protected negative space." : `Let this ${role.toLowerCase().replaceAll("_", " ")} support the focal hierarchy without becoming a second focal event.`,
      optional: ["ACCENT", "TEXTURAL_ACCENT"].includes(role),
    };
  });
  const budget = restraint > 0.72 ? { target: 2, minimum: 2, maximum: 3, reason: "Restraint calls for a tight future material-family budget." } : energy > 0.7 ? { target: 4, minimum: 2, maximum: 5, reason: "Energy can tolerate a wider family budget while preserving role hierarchy." } : { target: 3, minimum: 2, maximum: 4, reason: "A measured budget separates major jobs without manufacturing fullness." };
  const at = nowIso();
  const orchestration: FloralOrchestrationRecord = {
    orchestration_id: `${record.canonical_id}-ORCH-${String((record.floral_orchestration?.orchestration_revision || 0) + index + 1).padStart(3, "0")}`,
    orchestration_revision: (record.floral_orchestration?.orchestration_revision || 0) + index + 1,
    source_architecture_id: architecture.architecture_id,
    source_architecture_revision: architecture.architecture_revision,
    source_composition_revision: composition.composition_revision,
    source_interpretation_revision: interpretation.interpretation_revision,
    generated_at: at,
    approved_at: null,
    model: MODEL,
    engine_version: ENGINE_VERSION,
    status: "GENERATED",
    roles,
    material_family_budget: budget,
    hierarchy_summary: { primary_role_id: roles.find((role) => role.role === "PRIMARY_FOCAL")?.role_id || null, secondary_role_ids: roles.filter((role) => role.role === "SECONDARY_FOCAL").map((role) => role.role_id), active_role_count: roles.filter((role) => !role.optional).length, optional_role_count: roles.filter((role) => role.optional).length },
    depth_distribution: roles.reduce<Record<string, string[]>>((out, role) => { (out[role.depth_behavior] ||= []).push(role.role_id); return out; }, {}),
    radial_distribution: roles.reduce<Record<string, string[]>>((out, role) => { (out[role.radial_behavior] ||= []).push(role.role_id); return out; }, {}),
    interweaving_summary: { nested_count: roles.filter((role) => role.interweaving_intent.includes("nested")).length, exposed_count: roles.filter((role) => role.interweaving_intent === "exposed").length, bridge_count: roles.filter((role) => ["BRIDGE", "TRANSITION"].includes(role.role)).length, reason: "Role placement describes how future floral masses relate to structural greenery without compiling geometry." },
    validation: { outcome: "PASS", reasons: [] },
    rationale: `A role-first map for ${composition.composition_family.replaceAll("_", " ")} that keeps ${interpretation.emotional_center} concentrated, separates events through greenery, and leaves botanical identity for a later qualified-material engine.`,
    provenance: { source_architecture_id: architecture.architecture_id, source_architecture_revision: architecture.architecture_revision, source_composition_revision: composition.composition_revision, source_interpretation_revision: interpretation.interpretation_revision, generated_at: at, approved_at: null, model: MODEL, engine_version: ENGINE_VERSION },
    raw_response: { candidate_index: index, seed, role_first: true, material_agnostic: true, inventory_queried: false },
  };
  orchestration.validation = MoodoorFloralOrchestrationValidator.validate(orchestration, architecture);
  return orchestration;
}

export const MoodoorFloralOrchestrationService = {
  generateOrchestration(record: VNextDesign) {
    requireApproved(record);
    const candidates = [0, 1, 2].map((index) => buildCandidate(record, index));
    const active = candidates[0];
    if (active.validation.outcome === "BLOCK") throw new Error(active.validation.reasons.join("; "));
    MoodoorDesignRepository.update(record.canonical_id, { floral_orchestration: active, floral_orchestration_candidates: candidates });
    MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "orchestration_generated", label: "Floral role candidates generated", detail: candidates.map((item) => item.orchestration_id).join(", "), at: active.generated_at, revision: record.revision + 1 });
    return { active, candidates };
  },
  regenerateOrchestration(record: VNextDesign) { return this.generateOrchestration(record); },
  generateCandidates(record: VNextDesign) { return this.generateOrchestration(record).candidates; },
  chooseCandidate(record: VNextDesign, candidate: FloralOrchestrationRecord) {
    requireApproved(record);
    if (candidate.validation.outcome === "BLOCK") throw new Error(candidate.validation.reasons.join("; "));
    const reviewed = { ...candidate, status: "REVIEWED" as const };
    MoodoorDesignRepository.update(record.canonical_id, { floral_orchestration: reviewed, floral_orchestration_candidates: (record.floral_orchestration_candidates || []).map((item) => item.orchestration_id === candidate.orchestration_id ? reviewed : item) });
    return reviewed;
  },
  editRoleAssignment(record: VNextDesign, roleId: string, patch: Partial<RoleRecord>) {
    requireApproved(record);
    if (!record.floral_orchestration) throw new Error("Generate floral orchestration before editing");
    const roles = record.floral_orchestration.roles.map((role) => role.role_id === roleId ? { ...role, ...patch } : role);
    const edited = { ...record.floral_orchestration, roles, orchestration_revision: record.floral_orchestration.orchestration_revision + 1, status: "REVIEWED" as const };
    edited.validation = MoodoorFloralOrchestrationValidator.validate(edited, record.greenery_architecture!);
    MoodoorDesignRepository.update(record.canonical_id, { floral_orchestration: edited });
    return edited;
  },
  approveOrchestration(record: VNextDesign) {
    requireApproved(record);
    if (!record.floral_orchestration) throw new Error("Generate floral orchestration before approving");
    if (record.floral_orchestration.validation.outcome === "BLOCK") throw new Error(record.floral_orchestration.validation.reasons.join("; "));
    const at = nowIso();
    const approved = { ...record.floral_orchestration, status: "APPROVED" as const, approved_at: at, provenance: { ...record.floral_orchestration.provenance, approved_at: at } };
    MoodoorDesignRepository.update(record.canonical_id, { floral_orchestration: approved, floral_orchestration_candidates: [] });
    MoodoorActivityRepository.append({ design_id: record.canonical_id, action: "orchestration_approved", label: "Floral orchestration approved", detail: approved.orchestration_id, at, revision: record.revision + 1 });
    return approved;
  },
  markStale(record: VNextDesign) {
    if (!record.floral_orchestration || record.floral_orchestration.status === "STALE") return null;
    const stale = { ...record.floral_orchestration, status: "STALE" as const };
    MoodoorDesignRepository.update(record.canonical_id, { floral_orchestration: stale });
    return stale;
  },
};
