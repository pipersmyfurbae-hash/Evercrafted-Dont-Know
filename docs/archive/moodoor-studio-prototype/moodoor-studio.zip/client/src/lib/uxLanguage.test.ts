import { describe, expect, it } from "vitest";
import { MoodoorUXLanguage as UX } from "./uxLanguage";
describe("MoodoorUXLanguage",()=>{
 it("maps internal concepts to creator language",()=>{expect(UX.humanConcept("floral_orchestration")).toBe("Flower structure");expect(UX.humanConcept("inventory_resolution")).toBe("Materials");expect(UX.humanConcept("silence_zone")).toBe("Quiet space");expect(UX.concepts.ecr).toBeNull();});
 it("maps statuses without exposing enum syntax",()=>{expect(UX.humanStatus("NOT_STARTED")).toBe("Not started");expect(UX.humanStatus("GENERATED")).toBe("Ready to review");expect(UX.humanStatus("STALE")).toBe("Needs review");expect(UX.humanStatus("BLOCK")).toBe("Needs your attention");});
 it("provides human progress and action language",()=>{expect(UX.progress.interpretation).toBe("Understanding your memory");expect(UX.actions.render).toBe("Render design");expect(UX.actions.uploadRender).toBe("Upload existing render");});
 it("keeps technical details available as an advanced boundary",()=>{expect(UX.sections.advanced).toBe("Advanced details");expect(UX.navigation.migration).toBe("Legacy review");});
});
