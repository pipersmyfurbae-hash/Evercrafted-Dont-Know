import { describe, expect, it } from "vitest";
import { pathForLocation, paths } from "./PathArchitecture";
describe("Sprint 25 path architecture",()=>{
 it("maps the creator entry points to explicit journeys",()=>{expect(pathForLocation("/studio/create")).toEqual({path:"memory",current:0});expect(pathForLocation("/studio/reverse-intake")).toEqual({path:"reverse",current:0});expect(pathForLocation("/studio/collections")).toEqual({path:"collection",current:1});expect(pathForLocation("/studio/orders")).toEqual({path:"production",current:1});});
 it("keeps continuation targets concrete",()=>{expect(paths.memory.steps.map(s=>s.label)).toEqual(["Memory","Design","Render","QC","Publish"]);expect(paths.reverse.steps[0].href).toBe("/studio/reverse-intake");expect(paths.production.steps[2].href).toBe("/studio/inventory");});
 it("maps public customer work without exposing internal routes",()=>{expect(paths.customer.steps.map(s=>s.href)).toEqual(["/","/find-your-wreath","/find-your-wreath","/designs","/stories"]);expect(paths.customer.steps.every(s=>!s.href.startsWith("/studio"))).toBe(true);});
 it("keeps all six required journey labels understandable on mobile",()=>{for(const key of ["memory","reverse","collection","production","customer"] as const){expect(paths[key].label.length).toBeGreaterThan(2);expect(paths[key].steps.length).toBeGreaterThan(3);}});
});
