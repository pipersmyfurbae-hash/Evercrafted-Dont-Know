import { describe, expect, it } from "vitest";
import { continuationHref } from "./CreatorFlow";

describe("CreatorFlow continuation", () => {
  it("does not request a no-op navigation when orchestration remains on the same route", () => {
    expect(continuationHref("/studio/design/MD-000001/design", "/studio/design/MD-000001/design")).toBeNull();
  });

  it("returns the next route when orchestration advances the creator", () => {
    expect(continuationHref("/studio/design/MD-000001/design", "/studio/design/MD-000001/visualize")).toBe("/studio/design/MD-000001/visualize");
  });
});
