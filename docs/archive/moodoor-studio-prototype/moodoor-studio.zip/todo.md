# Sprint 11 Implementation Checklist

- [ ] Read the complete Sprint 11 specification and define the renderer-agnostic ECR contract.
- [ ] Extend vNext persistence with structured ECR records, lifecycle, validation, fidelity scorecard, and provenance.
- [ ] Implement approved-Blueprint gating and deterministic ECR compilation.
- [ ] Preserve canvas, foundation, placements, clusters, pockets, sweeps, silence, negative space, depth, radial, orientation, insertion, interweaving, extensions, and asset references.
- [ ] Add hard/soft render constraints and configurable geometry tolerances.
- [ ] Add Blueprint-to-ECR diff with MATCH/WARNING/ERROR outcomes.
- [ ] Add ECR validation for completeness, fidelity, relationships, constraints, and no unexplained objects.
- [ ] Add deterministic recompilation, review, approval, JSON export, and stale propagation.
- [ ] Build the ECR inspector and Blueprint/ECR schematic visualization.
- [ ] Add Sprint 11 fixtures and regression tests for standard compile, silence, relationships, depth, sweeps, missing objects, drift, extra objects, deterministic recompile, and stale Blueprint.
- [ ] Write Sprint 11 ECR, schema, object, relationship, constraint, diff, validation, versioning, and findings documentation.
- [ ] Run TypeScript check, all regression suites, production build, visual verification, and save a verified checkpoint.

# Sprint 12 Implementation Checklist

- [ ] Define Render Bridge, renderer adapter, package, submission, result, and provenance boundaries.
- [ ] Add canonical Render Package and Moodoor Render Record schemas to vNext persistence.
- [ ] Enforce Blueprint APPROVED, ECR APPROVED, ECR PASS, and no-diff-error input gates.
- [ ] Implement structured design-contract extraction from ECR, preserving geometry, assets, relationships, silence, foundation, depth, and identity.
- [ ] Implement presentation profile separate from ECR geometry.
- [ ] Implement generic adapter interface and one honest deterministic/mock reference adapter; do not fabricate external rendering.
- [ ] Compile structured adapter payload and trace prompt fragments to ECR objects, relationships, constraints, presentation settings, or render canon.
- [ ] Validate package completeness, source revisions, hard/soft constraints, and renderer boundary compliance.
- [ ] Implement prepare, create package, submit, record result, retry, and stale lifecycle operations.
- [ ] Add Render Package / Render Result inspector UI and provenance navigation.
- [ ] Add Sprint 12 regression tests for every input gate, package fidelity, no ECR mutation, mock submission, normalization, retry, stale package/result, and QC deferral.
- [ ] Write Sprint 12 findings and renderer-choice documentation.
- [ ] Run TypeScript, all tests, production build, visual verification, and save a checkpoint.

# Sprint 13 Implementation Checklist

- [ ] Define the QC result contract, accessible-image gate, uncertainty vocabulary, decision policy, and no-design-rewrite boundary.
- [ ] Add QCResult, observed EVS, drift, effective EVS, structural, botanical, composition, Essence, North Star, violation, warning, and provenance schemas.
- [ ] Implement image-access validation and prohibit fabricated image-analysis results when no image is available.
- [ ] Implement deterministic/proxy observations plus explicit observation overrides for real image-model/manual analysis inputs.
- [ ] Preserve predicted EVS and compute observed EVS separately across all seven canonical axes.
- [ ] Compute signed drift, absolute drift, severity, configurable thresholds, and effective EVS fallback semantics.
- [ ] Implement structural, botanical, composition, anti-symmetry, anti-bouquet, anti-flat, interweaving, silence, foundation, unauthorized/missing object, color, faux-material, greenery, and quantity checks with uncertainty.
- [ ] Implement PASS / REVIEW / FAIL decisions and approve, request review, fail, stale, and provenance lifecycle operations.
- [ ] Add QC Inspector UI with EVS comparison, drift table, fidelity scorecards, violations, warnings, evidence, uncertainty, and decision controls.
- [ ] Add Sprint 13 fixtures and regression tests for no-image blocking, complete observed EVS, drift, effective EVS, hard silence failure, missing/unauthorized objects, uncertain recognition, approval/review/fail, and stale propagation.
- [ ] Write Sprint 13 findings and document that image-model/manual observations are inputs, not fabricated outputs.
- [ ] Run TypeScript, all tests, production build, visual verification, and save a verified checkpoint.

# Missing Design Diagnostic

- [ ] Trace Library filters and vNext localStorage origin/key usage.
- [ ] Trace Create and approval writes for memory-origin designs.
- [ ] Check archived/status handling and detail-route visibility.
- [ ] Determine whether the design is recoverable in the active browser origin or requires user session/origin confirmation.
- [ ] Repair only the smallest visibility or persistence defect, then verify the flow.

# Design Tab Downstream Visibility Repair

- [ ] Trace existing DesignDetail stage components and vNext downstream fields.
- [ ] Add visible Selection, Inventory, Blueprint, ECR, Render Bridge, and QC status sections.
- [ ] Add direct inspector links without changing stored records.
- [ ] Verify Laurens on the published origin and run full regression/build checks.
- [ ] Save and publish the repair checkpoint.

# Blueprint Workflow Repair

- [ ] Trace Blueprint compiler gates and current DesignDetail controls.
- [ ] Add a visible beginning-to-Blueprint stage path with gate explanations.
- [ ] Add Blueprint generate, review, edit, validate, and approve actions.
- [ ] Fix any stale-record or missing-upstream feedback that blocks clicks without explanation.
- [ ] Add regression coverage and browser-verify Laurens’s Blueprint flow.
- [ ] Publish the verified repair checkpoint.

# Blueprint-to-ECR Handoff Clarification

- [ ] Trace ECR gate copy and Blueprint/ECR compiler APIs.
- [ ] Add explicit Blueprint status/location and compile-ECR action messaging.
- [ ] Add direct navigation from Blueprint workflow to ECR Inspector after compile.
- [ ] Verify browser flow, tests, build, and publish.

# Immediate Laurens Blueprint-to-ECR Completion

- [ ] Inspect Laurens Blueprint and ECR state.
- [ ] Complete or expose the handoff action and show resulting status.
- [ ] Verify the screen and publish the completed state.

# Sprint 13.5 Creator Flow Consolidation

- [ ] Define creator-facing routes, stage language, orchestration state, human decisions, and prompt-export boundary.
- [ ] Implement MoodoorDesignOrchestrator over existing engines with automatic dependency-order progression.
- [ ] Build Create → Design → Visualize → Refine → Finish screens and keep Advanced Inspector secondary.
- [ ] Add direct Story, Copy Render Prompt, Download Render Package, Render Design, upload-render, and Render Again actions.
- [ ] Add end-to-end new-memory orchestration tests through render-ready state.
- [ ] Browser-verify no dead ends, readable progress, obvious render prompt/action, technical inspector fallback, and no legacy writes.
- [ ] Document Sprint 13.5, run full checks/build, and publish the checkpoint.

# Sprint 13.5 Active Implementation

- [ ] Implement orchestrator over existing engines.
- [ ] Add creator-facing Create, Design, Visualize, Refine, Finish flow.
- [ ] Expose direct Story, Copy Render Prompt, Download Render Package, Render Design, Upload Existing Render, and Render Again actions.
- [ ] Preserve Advanced Inspector access and creator-friendly status/error language.
- [ ] Add automated one-memory orchestration test and run browser verification.
- [ ] Document and publish Sprint 13.5.

# Sprint 14 Collection Creator Engine

- [ ] Define canonical vNext collection schema and lifecycle
- [ ] Implement collection Essence and emotional architecture
- [ ] Generate differentiated design slots and directions
- [ ] Reuse existing design orchestrator for slot designs
- [ ] Add anti-clone and family-resemblance validation
- [ ] Build creator-first collection screens
- [ ] Add collection regression tests and documentation
- [ ] Run full verification, visual review, and publish checkpoint

# Sprint 15 Collection Curator

- [ ] Read the complete brief and finalize curator boundaries and models.
- [ ] Add non-mutating curation profiles, relationships, candidates, roles, gaps, bridge/outlier evidence, and effective-EVS handling.
- [ ] Implement discovery modes over canonical Library designs and existing Sprint 14 collections.
- [ ] Build creator-first Curator entry, candidate review board, member controls, Advanced Inspector, and save-as-collection.
- [ ] Add regression tests for safeguards, candidate diversity, human review, stale lifecycle, and legacy safety.
- [ ] Document, visually verify, run full checks/build, and publish Sprint 15.

# Sprint 16 Story & Campaign Studio

- [ ] Read the complete Sprint 16 brief and lock narrative hierarchy and campaign boundaries.
- [ ] Add canonical MOODOOR_CAMPAIGN_V1 records and campaign repository fields.
- [ ] Implement story-world, narrative, visual, copy, scene, sequence, product-story, validation, and stale services.
- [ ] Support approved design, approved collection, curated collection, and existing-campaign revision entry points.
- [ ] Build creator-first Campaign Studio create, direction, review/refine, approval, story, and Advanced Inspector screens.
- [ ] Add memory-fidelity, anti-literalization, narrative separation, stale, and approval regression tests.
- [ ] Document Sprint 16, run full checks/build, visually verify, and publish with Sprint 17 explicitly deferred.

# Sprint 17 Lifestyle Scene Generator & Lookbook Studio

- [ ] Read the complete brief and lock scene/render/lookbook contracts.
- [ ] Add MOODOOR_SCENE_V1 and scene-render-package persistence with provenance and stale lifecycle.
- [ ] Implement product identity contract, reference hierarchy, scene compiler, structured prompt sections, and validation.
- [ ] Reuse Sprint 12 Render Bridge for generate/import/regenerate/review/approve/reject/lock flows.
- [ ] Implement lookbook persistence, page architecture, scene selection, reorder/replace, validation, approval, and export.
- [ ] Build creator-first Campaign → Scenes → Generate → Review → Lookbook workflow with Advanced Inspector.
- [ ] Add Sprint 17 tests for gates, locks, continuity, scene types, QC, lookbook, and legacy safety.
- [ ] Document, visually verify, run full checks/build, and publish Sprint 17.

# Sprint 18 Launch Planner & Experience Orchestration

- [ ] Read the complete brief and define launch, channel, asset, audience, CTA, commerce, scarcity, and review contracts.
- [ ] Add MOODOOR_LAUNCH_V1 persistence, launch arc, moments, channel plan, assignments, validation, provenance, and stale lifecycle.
- [ ] Implement deterministic Launch Planner derivation over approved Campaign Packages without duplicating source records.
- [ ] Add channel-specific adaptation, asset-quality/diversity rules, product-presence mapping, waitlist mode, and scarcity-safe truth.
- [ ] Build creator-first Launch Planner create, timeline review, moment adjustment, assignment, and Advanced Inspector screens.
- [ ] Add Sprint 18 regression tests for gates, strategy/arc, channels, assets, product presence, commerce truth, scarcity, waitlist, stale, and legacy safety.
- [ ] Document, visually verify, run full checks/build, and publish Sprint 18.

# Sprint 19 Production, Orders & Build Execution

- [ ] Define canonical order, line-item, build-requirements, build-job, production-QC, and shortage contracts.
- [ ] Extend vNext persistence keys and schema versions without reusing legacy order storage.
- [ ] Implement controlled production inventory availability, reservation, release, consume, adjustment, and shortage operations.
- [ ] Implement approved-design readiness gates, exact revision locks, unit/order BOM compilation, cost snapshots, and provenance.
- [ ] Implement build queue, build guide, job lifecycle, production QC, and close-order flow.
- [ ] Build creator-first Orders, Production, Inventory, and Advanced Inspector screens.
- [ ] Add reservation-safety, revision-lock, build-fidelity, shortage, stale, and legacy-safety tests.
- [ ] Document and fully verify Sprint 19 before publishing.

# Sprint 20 Public Moodoor + Publishing Layer

- [ ] Define canonical public entry, public content package, content type, privacy, asset, SEO, commerce, slug, canonical URL, publication status, and stale contracts.
- [ ] Add canonical public-entry persistence without changing source Design, Collection, Campaign, Story, Lookbook, or legacy records.
- [ ] Implement public-readiness validation, approved-source gates, QC asset gates, conservative Memory publication controls, and snapshot revisions.
- [ ] Implement deterministic slug collision handling, canonical paths, redirect metadata, preview, publish, unpublish, republish, and stale workflows.
- [ ] Build unified public Moodoor navigation and customer-facing Design, Collection, Story, Lookbook, and Campaign templates.
- [ ] Build creator publishing controls and a public-readiness review surface.
- [ ] Add privacy, QC, slug, snapshot, stale, preview/publish, and legacy-safety regression tests.
- [ ] Document Sprint 20, visually verify public and creator workflows, run full checks/build, and publish the checkpoint.

# Sprint 21 Customer Memory Matching

- [ ] Define canonical Memory Match session, interpretation, matching profile, candidate, explanation, preference, availability, privacy, and no-match contracts.
- [ ] Add isolated MOODOOR_MEMORY_MATCH_V1 persistence with private-by-default session lifecycle and no legacy/public source mutation.
- [ ] Implement deterministic safe interpretation from ordinary-language memory and anti-literalized matching signals.
- [ ] Restrict candidates to approved and published public Designs; keep emotional fit separate from availability.
- [ ] Implement explainable ranking, hard exclusions, lightweight preference refinements, configurable meaningful thresholds, and honest no-match outcomes.
- [ ] Build the public Find Your Wreath entry, optional guided prompts, match cards, explanations, restart flow, and custom-design handoff.
- [ ] Add privacy copy and memory retention controls without exposing EVS, vectors, territories, confidence math, Blueprint, ECR, or engine terminology.
- [ ] Add Sprint 21 tests for privacy, eligibility, no forced match, exclusions, preferences, deterministic ranking, explanation safety, and legacy/public safety.
- [ ] Document Sprint 21, visually verify customer/public workflows, run full checks/build, and publish the checkpoint.

# Sprint 22 Existing Render Reverse Intake

- [ ] Define reverse-intake source, evidence, confidence, unknown, observation, inference, declaration, and human-edit contracts.
- [ ] Add isolated MOODOOR_RENDER_INTAKE_V1 persistence with source-image metadata, declared context, reconstruction, blueprint candidate, provenance, and revision lifecycle.
- [ ] Implement visible-evidence render analysis with wreath detection, product/background segmentation, composition, focal estimate, silence, botanicals, palette, materials, greenery, roles, and unresolved unknowns.
- [ ] Implement bounded blueprint-candidate generation without fake precision, exact SKU claims, hidden insertion paths, or unsupported original truth.
- [ ] Build creator-first Upload Render, Review What Moodoor Found, correction, approval/rejection, blueprint candidate, and library-candidate handoff screens.
- [ ] Keep technical evidence in Advanced Inspector and preserve legacy read-only boundaries.
- [ ] Add Sprint 22 tests for evidence-state separation, provenance, partial/not-found handling, botanical ambiguity, protected unknowns, human edits, approval gates, stale propagation, and legacy safety.
- [ ] Document Sprint 22, visually verify reverse-intake workflows, run full checks/build, and publish the checkpoint.

# Sprint 23 Legacy Migration, Reconciliation & Retirement

- [ ] Inventory actual legacy files, storage keys, assets, pages, runtime paths, and historically missing sources.
- [ ] Classify every source by data/runtime/public/operator/reference/duplicate/obsolete role and retirement disposition.
- [ ] Implement MOODOOR_LEGACY_MIGRATION_V1 manifest, immutable logical snapshot, source inventory, checksums, and lifecycle status.
- [ ] Implement persistent identity crosswalk with deterministic resolution, review-required ambiguity, duplicate detection, orphan detection, and conflict reporting.
- [ ] Implement clone-based dry-run mappings for catalog, LibraryItems, Stories, renders, collections, orders, inventory, prompts, public artifacts, and campaign/lookbook artifacts.
- [ ] Route unresolved render identity to Sprint 22 Reverse Intake and keep private Story/Memory content behind Sprint 20 privacy review.
- [ ] Build operator migration review, parity, rollback, and guarded retirement surfaces without destructive deletion.
- [ ] Add Sprint 23 regression tests for snapshot immutability, dry-run safety, identity resolution, conflict/orphan/duplicate detection, privacy, parity, rollback, and legacy safety.
- [ ] Document Sprint 23, visually verify migration workflows, run full checks/build, and publish the checkpoint.

# Sprint 24 Humanization, UX Canon & Final Studio Simplification

- [ ] Audit every current Studio route for purpose, user, actions, terminology, duplication, navigation, technical leakage, mobile issues, and disposition.
- [ ] Create centralized MoodoorUXLanguage mappings for internal concepts, statuses, progress, errors, actions, and creator-facing section labels.
- [ ] Simplify top-level navigation to Home, Create, Library, Collections, Campaigns, Production, Publishing, with Inventory secondary where needed.
- [ ] Preserve technical power behind an explicit Advanced mode or inspector and keep routine creator work in Standard mode.
- [ ] Humanize Create, Design, Visualize, Refine, Finish, Collections, Campaigns, Production, Publishing, Reverse Intake, and Legacy Review surfaces.
- [ ] Audit approval visibility and classify approvals as automatic, human-required, advanced-only, or removed without changing canonical contracts.
- [ ] Replace enum/error/progress language in creator surfaces with readable, actionable copy and improve empty/loading/attention states.
- [ ] Improve responsive navigation and mobile action hierarchy without adding new engines or product systems.
- [ ] Add Sprint 24 UX regression tests and document UX_ROUTE_AUDIT.md plus Sprint 24 findings.
- [ ] Visually verify representative creator workflows, run full checks/build, and publish the checkpoint.

# Sprint 25 Path Architecture & Mobile Reachability

- [ ] Audit the six required paths against current routes, entry points, continuation links, dead ends, and mobile action visibility.
- [ ] Define a shared canonical path map and path-step language without changing engine contracts.
- [ ] Add explicit creator entry/continuation links for Memory-first, Existing-render-first, Collection, and Production.
- [ ] Add explicit customer links from Public Home through Find Your Wreath, Memory Match, Design, Story, Collection, and Lookbook.
- [ ] Add shared path progress, back/next escape routes, and mobile-first action grouping to critical screens.
- [ ] Add Sprint 25 reachability and mobile-action regression tests.
- [ ] Document the path architecture, verify all six journeys at desktop/mobile widths, run full checks/build, and publish the checkpoint.

# Release Fix 25.1 — Standard Auto-Advance + Render Prompt Completeness

- [ ] Audit every Standard-mode approval gate and classify it as AUTO_ADVANCE, HUMAN_DECISION_REQUIRED, or ADVANCED_ONLY.
- [ ] Define and persist one creator continuation state with next action, waiting reason, current Design ID/revision, current render context, and human-interruption state.
- [ ] Add safe automatic continuation through existing canonical orchestration without removing internal approval/status architecture.
- [ ] Ensure every Standard creator action resolves to NEXT_STEP, WAITING_FOR_MOODOOR, NEEDS_CREATOR_INPUT, or COMPLETE with one obvious primary action.
- [ ] Make path ribbons functional and preserve Design context through all continuation links.
- [ ] Trace material survival across the complete Design-to-copied-prompt pipeline with a diagnostic matrix.
- [ ] Locate the first confirmed boundary where greenery, secondary/support roles, quantities, negative space, depth, interweaving, or source references disappear.
- [ ] Fix only the confirmed boundary; do not hardcode greenery or alter valid peony placement geometry.
- [ ] Surface inventory-driven monoculture or other material constraints honestly in Standard Mode.
- [ ] Add Release Fix 25.1 tests for auto-advance, human stops, context persistence, functional ribbons, material survival, prompt completeness, geometry preservation, and legacy safety.
- [ ] Document the release correction, verify the Standard golden path and provenance matrix, run full checks/build, and publish the checkpoint.

# Prompt Provenance Drawer

- [ ] Define readable prompt-section provenance categories and canonical source stages.
- [ ] Expose provenance metadata from the existing orchestrator without changing prompt text or canonical records.
- [ ] Build an expandable Standard Visualize drawer with source labels, evidence counts, and missing-source states.
- [ ] Add regression coverage and documentation for prompt provenance mapping.
- [ ] Run full checks/build, visually verify Visualize at desktop/mobile widths, and publish the checkpoint.

# Release Fix 25.2 — Canonical Design Completeness & Conflict Validation

- [ ] Audit MD-000001 role, material, inventory, Blueprint, ECR, and silence-collision evidence.
- [ ] Identify the first canonical stage where Peony role collapse and SECONDARY loss occur.
- [ ] Add canonical completeness validation with intentional/accidental monobotanical distinction.
- [ ] Add hard silence collision validation and dependency-aware greenery reflow.
- [ ] Block false readiness states and expose natural Standard-mode resolution copy.
- [ ] Add catalog-backed renderer botanical descriptions without inventing attributes.
- [ ] Add MD-000001, golden multi-role, intentional monobotanical, and silence tests.
- [ ] Document findings, run full verification, visually verify, publish, and stop before Sprint 26.

# Continuation Button Repair

- [ ] Trace the rendered “Continue creating the design” button and its route/context.
- [ ] Repair navigation or resume behavior with visible missing-context feedback.
- [ ] Add regression coverage for the button target and blocked state.
- [ ] Run checks/build and visually verify desktop/mobile behavior.
