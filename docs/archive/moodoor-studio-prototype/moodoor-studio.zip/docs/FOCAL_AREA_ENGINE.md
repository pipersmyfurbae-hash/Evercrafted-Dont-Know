# Moodoor Focal Area Engine

Sprint 4 is the first native compositional decision layer. It accepts only a native vNext design with an approved Essence interpretation. It decides where the emotional center should live and how the eye should encounter it, without selecting flowers, greenery, materials, inventory, stems, SKUs, blueprint geometry, ECR, prompts, or renders.

`MoodoorFocalService` provides `generateFocalIntent`, `regenerateFocalIntent`, `chooseFocalCandidate`, `editFocalIntent`, `approveFocalIntent`, `compareFocalCandidates`, and `markFocalStale`.

## Structured output

Each candidate includes a focal zone, radial bias, visual weight, composition family, focal dominance, optional subordinate movement, eye entry, eye rest, flow, negative-space intent, silence zone, rationale, provenance, and raw debugging metadata. Candidate output never contains materials or product instructions.

## Candidate behavior

Up to three deterministic candidates are generated. Candidate diversity is constrained by the approved interpretation, EVS, emotional tension, product type, stable source signals, recent approved compositions, and controlled variation. Recent approved focal centers are shifted away from rather than silently repeated. Similar EVS profiles therefore remain capable of multiple valid solutions.

## Gating

If the interpretation is absent or not `APPROVED`, generation throws and the UI presents the approval gate. Composition approval does not transition the design to `DESIGNED` in Sprint 4 because that status is reserved for the existing lifecycle semantics and later design work.

## References

[1]: ../client/src/data/focal.ts "MoodoorFocalService implementation"
[2]: ../client/src/data/vnext.ts "CompositionRecord contract"
[3]: ../client/src/pages/DesignDetail.tsx "Focal/Composition review UI"

[1] [2] [3]
