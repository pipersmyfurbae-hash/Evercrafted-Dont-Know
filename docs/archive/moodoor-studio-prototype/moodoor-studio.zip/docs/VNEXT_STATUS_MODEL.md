# vNext Status Model

## Schema states

The contract reserves the full lifecycle: `DRAFT`, `DESIGNED`, `RENDER_READY`, `RENDERED`, `QC_REVIEW`, `APPROVED`, `COLLECTION_READY`, `CAMPAIGN_READY`, `PUBLISHED`, and `ARCHIVED`.

## Sprint 2-manageable states

The UI can create and manually transition only `DRAFT`, `DESIGNED`, and `ARCHIVED`.

| Current | Allowed next states |
|---|---|
| `DRAFT` | `DESIGNED`, `ARCHIVED` |
| `DESIGNED` | `DRAFT`, `ARCHIVED` |
| `ARCHIVED` | `DRAFT` |
| Later lifecycle states | No manual transitions in Sprint 2. |

Transitions happen through `MoodoorStatusService` and repository methods. The UI never edits `status` as an arbitrary form field. Archive retains the record, increments revision, and writes an activity entry. Restore preserves the canonical ID and writes a restore activity entry.

## Visual treatment

Native records show `VNEXT / EDITABLE`, status badges, archive/restore controls, and an activity History tab. Legacy records show `LEGACY / READ ONLY` and never expose native edit controls.

## References

[1]: ../client/src/data/vnext.ts "Status transition implementation"
[2]: ../client/src/pages/DesignDetail.tsx "Status controls and activity history"

[1] [2]
