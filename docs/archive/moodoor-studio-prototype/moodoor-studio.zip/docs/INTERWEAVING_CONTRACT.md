# Interweaving Contract

Each role declares how future floral mass relates to structural greenery: `deeply_nested`, `nested`, `edge_interwoven`, `lightly_interwoven`, or `exposed`. It also declares whether greenery should appear behind, between, or selectively in front of the future role. These are architectural relationships, not render geometry.

Roles intentionally distribute across Sprint 5 depth planes and radial bands. A primary role may span foreground and midground; a bridge may span midground and background; accents remain restrained. The contract prevents a flat floral decal and preserves the stem-built relationship established by the greenery architecture.

## References

[1]: ../client/src/data/orchestration.ts "Interweaving and occlusion generation"
[2]: ../client/src/data/vnext.ts "Interweaving, depth, and radial fields"

[1] [2]
