# Composition Contract

| Field | Sprint 4 contract |
|---|---|
| `composition_family` | asymmetric_crescent, broken_crescent, offset_cluster, sweeping_arc, distributed_asymmetry, or full_with_interruption |
| `primary_focal` | Focal zone with human-facing clock range, angular center/span, radial bias, weight, and reason |
| `focal_dominance` | quiet, clear, strong, or commanding |
| `secondary_movement` | none, echo, counterweight, continuation, or release; always subordinate |
| `eye_entry` | Clock and immediate, invited, gradual, or discovered behavior |
| `eye_rest` | Zone, clock, and reason for visual settling |
| `flow` | Direction and behavior with start/release clocks |
| `negative_space_intent` | Importance, target exposure, preferred zone, and purpose |
| `silence_zone` | Start/end clocks, intensity, and purpose |
| `rationale` | Human-readable explanation tied to approved interpretation and EVS evidence |
| `status` / `revision` | Independent composition lifecycle and revision number |
| `provenance` | Source interpretation, engine/model, timestamps, and approval |

The contract is architectural intent, not blueprint geometry. No exact percentage exposure, stem assignment, flower role, inventory query, or render prompt is represented.

## Status lifecycle

Composition status is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`. Approval freezes a composition revision for Sprint 5. A later Essence interpretation revision marks the existing composition `STALE` without deleting or regenerating it.

## References

[1]: ../client/src/data/vnext.ts "CompositionRecord type"
[2]: ../client/src/data/focal.ts "Composition generation and lifecycle"

[1] [2]
