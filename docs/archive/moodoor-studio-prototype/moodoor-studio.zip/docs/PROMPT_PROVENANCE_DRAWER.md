# Prompt Provenance Drawer

The Standard Visualize screen now offers an expandable creator-facing source ledger beside the copied render prompt. The drawer explains where each visible prompt section came from without exposing internal engine operation as the primary workflow.

| Prompt section | Canonical source stage | Evidence shown |
|---|---|---|
| Product identity | Design identity | Canonical Design ID |
| Foundation | ECR → Blueprint | Foundation object count and source IDs |
| Primary florals | Blueprint → ECR | Primary/focal object count |
| Secondary florals | Blueprint → ECR | Secondary object count |
| Support and accent botanicals | Blueprint → ECR | Support, bridge, transition, accent, filler, and echo count |
| Greenery architecture | Blueprint → ECR | Greenery sweep count |
| Composition contract | Blueprint | Placement count and Blueprint ID |
| Interweaving and depth | ECR → Blueprint | Object relationship/depth evidence count |
| Quiet space | ECR → Blueprint | Silence and negative-space boundary count |
| Material character | Inventory → ECR | Family, SKU, or asset evidence count |
| Presentation | Render Package | Presentation-profile evidence |
| Prohibitions | ECR → Render Package | Render-constraint evidence |

Each row has a readable label, a short explanation, source-stage label, source identifiers where available, and an evidence count. `SOURCE_PRESENT` means evidence and a canonical source ID are present. `SOURCE_PARTIAL` means evidence exists but no source identifier is recorded. `SOURCE_MISSING` means no evidence is available for that section.

The drawer is a presentation layer only. It does not mutate the Design, Blueprint, ECR, Render Package, inventory, or legacy records, and it does not change the copied prompt text or renderer adapter payload.
