# Legacy Fork Behavior

## Operator action

A legacy design detail page exposes `Create editable vNext draft`. The action routes to `/studio/create?source=<legacy-canonical-id>` and preloads only documented safe fields. The Create page visibly explains:

> This creates a new editable Moodoor design based on the legacy record. The original legacy item will remain unchanged.

## Safe copy

The fork copies the legacy display name, memory text, territory reference, blueprint-derived size when available, and explicit legacy aliases. It records `origin.type = legacy_fork`, `source_id`, `source_type`, and raw source evidence. Unknown fields remain inside `raw_legacy`; they are not guessed into canonical locations.

## Result

The fork receives a new `MD-######` ID, status `DRAFT`, revision one, a create activity entry, and a separate vNext persistence record. The original legacy adapter output and fixture payload are never passed to a write method. A future unified Library view displays both records with `source_kind` set to `legacy` or `vnext`.

## References

[1]: ../client/src/pages/DesignDetail.tsx "Legacy detail fork action"
[2]: ../client/src/pages/Create.tsx "Explicit fork creation form"
[3]: ../client/src/data/vnext.ts "Native repository create behavior"

[1] [2] [3]
