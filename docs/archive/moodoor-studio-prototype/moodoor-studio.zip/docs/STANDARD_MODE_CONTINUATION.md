# Release Fix 25.1 — Standard Mode Continuation

Standard Mode is the creator-facing path through an already-built deterministic architecture. It does not remove canonical approval records, provenance, validation, or Advanced inspectors. It decides which safe transitions Moodoor can perform automatically and which decisions still belong to a person.

| Stage family | Standard behavior | Reason |
|---|---|---|
| Memory | Human input required | The creator supplies the source memory or idea. |
| Essence through Render Package | Automatic continuation when gates and validators pass | These stages are deterministic design and render preparation artifacts; they do not publish, reserve production stock, or write legacy data. |
| Ambiguous curation, unresolved feasibility, conflicting evidence, or human-authored correction | Stop with a readable decision | The creator must resolve a real ambiguity rather than accept an invisible assumption. |
| Blueprint, ECR, Render Package inspectors | Advanced only in routine Standard Mode | Technical detail remains available without making the creator operate internal engines. |

`MoodoorDesignOrchestrator.getNextCreatorAction` returns one primary action with the current Design ID, revision, destination context, and human-readable detail. The action is one of `NEXT_STEP`, `WAITING_FOR_MOODOOR`, `NEEDS_CREATOR_INPUT`, or `COMPLETE`.

The Design-context path ribbon uses the same canonical Design ID for Design, Visualize, Refine, and Finish. A creator can enter through Library and still receive the same next action through the Standard continuation handoff on DesignDetail.

The safe golden path is therefore:

> Create Design → automatic internal orchestration → Design Ready → Visualize my design → Render Design / Copy Render Prompt.

If a render is externally unavailable, the interface says so directly. It does not claim that an image was generated.
