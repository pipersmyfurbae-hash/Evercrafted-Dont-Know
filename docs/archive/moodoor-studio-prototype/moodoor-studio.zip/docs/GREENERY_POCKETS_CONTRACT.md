# Greenery Pockets Contract

A greenery pocket is an intentional reserved room within or adjacent to the structural greenery architecture where a future floral role may be inserted. It is not an accidental gap and it is not a material assignment.

| Field | Meaning |
|---|---|
| `center_clock` / `angular_span` | Human-facing location and structural room size |
| `radial_band` | inner, middle_outer, outer, or extension |
| `depth_plane` | background, midground, or foreground |
| `capacity` | hero, large, medium, small, or accent; room capacity only |
| `openness` | clear, framed, or reserved |
| `orientation` | outward-left, outward-right, inward, or tangent |
| `relationship` | focal, secondary, between masses, extension, or eye rest relation |
| `eligible_roles` | Abstract future role classes; Sprint 6 decides occupancy |
| `reason` | Structural rationale |

Pocket hierarchy prevents five equivalent floral landing pads. Major pockets are separated through angular distance plus radial or depth distinction, intervening greenery, and hierarchy. The architecture supports greenery passing between, behind, and partly in front of future floral masses so later florals can read as interwoven rather than pasted onto a continuous base.

No capacity maps to a species, SKU, stem count, or inventory item.

## References

[1]: ../client/src/data/vnext.ts "Greenery pocket fields"
[2]: ../client/src/data/greenery.ts "Pocket generation and validation"

[1] [2]
