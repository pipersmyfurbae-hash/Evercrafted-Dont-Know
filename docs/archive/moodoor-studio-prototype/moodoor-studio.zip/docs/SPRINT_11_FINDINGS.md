# Moodoor Studio — Sprint 11 Findings

## Outcome

Sprint 11 adds the first renderer-agnostic **Evercrafted Render Specification (ECR) v1.0** layer. ECR is compiled only from an approved `MOODOOR_BP_V1` Blueprint. It is a structured scene specification rather than prompt prose, a species recommender, an inventory resolver, an image renderer, or a QC system.

## Schema and fidelity contract

An ECR record carries a stable scene identifier, schema and revision metadata, source Blueprint identity and revision, compiler provenance, lifecycle status, polar canvas, foundation, silence zones, negative-space zones, scene objects, relationships, renderer-neutral hard and soft constraints, validation output, fidelity scorecard, and provenance. All scene geometry remains explicit. Floral placements preserve their source SKU, family, cluster, angle, clock coordinate, normalized radius, depth plane, rotation, tilt, facing, insertion depth, insertion direction, interweaving intent, and build phase. Greenery is represented as an explicit sweep with its source SKU, zone, angular arc, step, radius, depth, flow, and hard stop.

| Blueprint concept | ECR representation | Rule |
|---|---|---|
| Polar canvas | `canvas` | Preserve diameter, opening, depth target, clock zero, and upright orientation. |
| Grapevine base | `foundation` plus `BASE-01` | The foundation remains an explicit scene object. |
| Floral placement | `type: botanical` object | One object per explicit Blueprint placement; no substitution. |
| Greenery architecture | `type: greenery_sweep` object | Preserve arc, step, radius, plane, flow, and hard stop. |
| Silence | `silence_zones` | Hard zones remain hard and forbid dense material classes. |
| Negative space | `negative_space_zones` | Preserve the Blueprint’s declared breathing and opening zones. |
| Interweaving | `relationships` and object insertion fields | Retain structured intent; never reinterpret it as prose. |

## Compiler behavior

`MoodoorECRCompiler.compileECR` rejects any design whose Blueprint is not approved. Compilation is deterministic for the same Blueprint revision and uses a versioned compiler identifier. Recompilation creates a new timestamped record with the same stable ECR identity for that Blueprint revision, without creating any legacy writes. The canonical vNext repository stores the active ECR and candidate history under `moodoor.vnext.designs`.

## Validation and diffing

The validator currently checks for an empty object graph and weakened silence constraints. The Blueprint-to-ECR diff reports missing explicit placements, unexplained botanical objects, and a match/error outcome. The inspector presents this status beside the fidelity scorecard. Approval is permitted only after validation passes; upstream edits can mark the ECR `STALE`, preventing silent reuse of a scene compiled from an older Blueprint.

## UI

The ECR inspector is available at `/studio/library/:canonicalId/ecr`. It provides a circular schematic, object graph, structured metadata, fidelity scorecard, hard-constraint summary, Blueprint diff summary, and JSON export. It is read-only with respect to geometry: the inspector exposes scene truth but does not reinterpret or edit it.

## Explicit exclusions

Sprint 11 does not reserve or decrement inventory, substitute species, invent missing objects, emit renderer prompts, render imagery, perform visual QC, or write to legacy stores. These remain later-stage concerns and must consume the approved ECR without modifying its semantic geometry.

## Regression coverage

The Sprint 11 suite covers unapproved-Blueprint gating, structured object and sweep compilation, hard silence preservation, relationship creation, deterministic recompilation after normalizing timestamps, missing-object diff failures, JSON export, ECR approval, and stale propagation.
