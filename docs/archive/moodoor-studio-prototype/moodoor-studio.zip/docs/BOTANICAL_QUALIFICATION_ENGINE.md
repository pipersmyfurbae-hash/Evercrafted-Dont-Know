# Botanical Qualification Engine

Sprint 7 converts approved Floral Orchestration into botanical job descriptions. It specifies characteristics required to perform each role while deliberately stopping before species, color, family, SKU, inventory, exact quantity, blueprint, ECR, or render selection.

The service requires approved Essence, Composition, Greenery Architecture, and Floral Orchestration. It produces floral qualifications, greenery zone qualifications, qualification clusters, inherited family budgets, a future scoring contract, rationale, validation, lifecycle, and provenance.

The governing rule is: **specify the botanical job before hiring the botanical**.
