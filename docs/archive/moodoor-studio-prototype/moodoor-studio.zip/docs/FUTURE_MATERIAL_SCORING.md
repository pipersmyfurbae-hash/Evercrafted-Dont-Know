# Future Material Scoring

Sprint 7 defines an evaluation contract only. Configurable dimensions include form fit, scale fit, movement fit, depth fit, nesting fit, texture fit, surface fit, color-behavior fit, hierarchy fit, and faux-read fit. Role overrides can prioritize scale and hierarchy for a primary focal, movement and depth for a bridge, or movement and form for a directional accent.

No botanical candidate is scored, selected, or looked up in Sprint 7. The contract exists so a future qualified-material engine can evaluate verified assets without treating every preference as mandatory.
