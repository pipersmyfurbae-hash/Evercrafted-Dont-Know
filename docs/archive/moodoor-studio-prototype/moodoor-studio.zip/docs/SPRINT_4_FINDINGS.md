# Moodoor Sprint 4 Findings

## Summary

Sprint 4 adds Moodoor's first native compositional decision layer. Approved emotional interpretation now informs where the emotional center should live and how the eye encounters it. The implementation stops before flowers, greenery, materials, inventory, blueprint compilation, ECR, rendering, QC, collections, campaigns, and production.

## Focal service

`MoodoorFocalService` requires an approved native Essence and generates up to three deterministic composition candidates. Each candidate includes a focal zone, composition family, dominance, subordinate secondary movement, eye entry, eye rest, flow, negative-space intent, silence zone, rationale, provenance, and revision metadata.

## Clock and architectural model

The canonical clock system is fixed at 12:00 = 0 degrees with clockwise-positive angles. The primary human-facing system is clock language, while internal degrees are limited to conversion, validation, and the circular instrument. The composition is treated like an architectural room: focal area is the dominant feature, secondary movement supports it, negative space is circulation, silence is intentionally unfurnished space, and flow is eye movement through the ring.

## Contextual influence and diversity

Emotional tension and predicted EVS influence focal span, silence strength, radial bias, direction, movement, interruption, and visual weight contextually. Candidate selection is not a one-to-one emotion lookup. Memory-signal hashes and controlled variation produce multiple valid solutions; recent approved focal centers are shifted away from rather than silently repeated.

## Review UI

The native Design tab now becomes Focal / Composition. It presents an architectural circular instrument with 12/3/6/9 markers, focal arc, secondary arc, silence arc, flow indicator, eye entry, and eye rest. Operators can generate, regenerate, compare, choose, and approve composition candidates. The UI explicitly says no materials are involved.

## Lifecycle and stale behavior

Composition status is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`. Manual edits are represented by revisioned records and do not regenerate Essence or EVS. If Essence changes after composition exists, the composition is marked stale and retained. Composition approval does not transition MoodoorDesign from DRAFT to DESIGNED because later design work is not yet present.

## Tests

The Sprint 4 suite adds six approved-interpretation profiles plus a similar-profile diversity check. It verifies Essence gating, valid focal zones, silence, eye entry/rest, subordinate secondary movement, fixed clock conversion, multiple candidate solutions, no material selection, composition approval, unchanged DRAFT lifecycle status, and no blueprint creation. Together with Sprint 2 and Sprint 3, 21 tests pass.

## Validation

`pnpm check` passes with zero TypeScript errors. The vNext, Essence, and focal suites pass. The production build is the final release gate. Existing non-blocking warnings remain limited to the prior asset URL and chunk-size notices.

## Safety boundary

No inventory, material, ECR, render prompt, render image, blueprint geometry, QC, collection, campaign, production, or legacy write path was introduced. Existing legacy pages, prompts, storage, and public behavior remain untouched.

## Sprint 5 recommendation

Sprint 5 may consume an approved composition as a structured architectural constraint for greenery pockets or flower-role reasoning. It should preserve the clock convention, silence primitive, candidate provenance, stale propagation, and no-silent-regeneration rule. Do not compile blueprints or query inventory until the next input contract is reviewed.

## References

[1]: FOCAL_AREA_ENGINE.md "Focal area engine"
[2]: COMPOSITION_CONTRACT.md "Composition contract"
[3]: CLOCK_COORDINATE_SYSTEM.md "Clock coordinate system"
[4]: SILENCE_ZONE.md "Silence zone"
[5]: COMPOSITION_VERSIONING.md "Composition versioning"
[6]: ../client/src/data/focal.test.ts "Sprint 4 fixture tests"

[1] [2] [3] [4] [5] [6]
