# Moodoor Studio UX Route Audit

Sprint 24 treats the internal architecture as stable and simplifies only the presentation layer. The central question for every creator route is: **where am I, what has Moodoor done, what needs my attention, and what do I do next?**

| Route area | Primary purpose | Primary user action | Disposition | Humanization decision |
|---|---|---|---|---|
| Home | Orient the creator and expose the next useful workspace | Open Library or Create | KEEP / SIMPLIFY | Present Studio as a calm workbench, not an engine dashboard. |
| Create | Start a design from a memory or idea | Tell Moodoor the memory, then create | KEEP / SIMPLIFY | Hide engine choices and use “What Moodoor heard” language. |
| Library | Find and open designs | Search, filter, open a record | KEEP | Keep evidence rails, replace internal source wording in standard view. |
| Design | Understand the design and continue work | Review the current decision and next step | KEEP / SIMPLIFY | Use Design, Materials, Story, Visualize, Build, and Publish sections. |
| Visualize | Produce or provide a visual | Render, copy prompt, upload existing render, render again | KEEP / SIMPLIFY | Renderer transport remains Advanced. |
| Refine | Make common creator adjustments | Choose a human-language direction | KEEP / SIMPLIFY | Use “Make it quieter”, “Make it warmer”, and similar intent actions. |
| Finish | Gather downstream outputs | Review story, build plan, public readiness, publish | MERGE INTO DESIGN | Reduce hunting across separate technical surfaces. |
| Collections | Coordinate related designs | Create, arrange, and review a collection | KEEP | Use collection/world/board language; keep curator evidence secondary. |
| Campaigns | Build narrative launch context | Create campaign and scenes | KEEP | Keep Story World and Lookbook as human-facing labels. |
| Production | Convert approved design into a maker workflow | Open order/build queue/build guide | KEEP | Use Materials, Build Queue, and Build Guide rather than internal job terms. |
| Inventory | Inspect real material availability | Review shortages and material state | MOVE_TO_SECONDARY | Operationally useful, but not a default creative navigation destination. |
| Publishing | Review and publish approved public snapshots | Preview, publish, unpublish, review stale source | KEEP | Publishing is a real human decision and stays prominent. |
| Reverse Intake | Understand an existing render | Upload, review findings, correct, approve | KEEP | “What Moodoor found” is the standard entry; evidence details stay Advanced. |
| Legacy Review | Reconcile old sources | Snapshot, dry run, resolve conflicts | MOVE_TO_SECONDARY | Present as Legacy review and never as ordinary creator work. |
| Advanced inspectors | Inspect schemas, provenance, validators, diffs, and technical evidence | Open only when needed | MOVE_TO_ADVANCED | Preserve capability, remove from the standard path. |

## UX language canon

The internal names remain stable in code and persistence. Creator-facing copy uses the `MoodoorUXLanguage` layer. `floral_orchestration` becomes **Flower structure**, `inventory_resolution` becomes **Materials**, `observed_evs` becomes **How the finished design reads**, `silence_zone` becomes **Quiet space**, and `blueprint` becomes **Build plan**. ECR is intentionally hidden from standard mode.

Statuses are translated consistently: `NOT_STARTED` becomes **Not started**, `GENERATED` becomes **Ready to review**, `APPROVED` becomes **Ready**, `STALE` becomes **Needs review**, `BLOCK` becomes **Needs your attention**, and `FAILED` becomes **Couldn’t complete**. Progress follows the creator’s mental model: **Understanding your memory**, **Shaping the design**, **Choosing botanicals**, **Building the plan**, **Preparing your visual**, and **Checking the result**.

## Standard and Advanced mode

Standard mode contains the creator’s decisions, human-language explanations, visible required approvals, and the next action. Advanced mode contains validators, EVS/ECR details, schemas, provenance, migration manifests, raw legacy payloads, renderer transport, diffs, and internal scores. Technical tools remain available; they no longer block routine work by appearing as the default navigation or primary page hierarchy.

## Approval policy

Human approval remains only where ambiguity, subjective design judgment, privacy exposure, publishing, inventory mutation, or production commitment exists. Internal engine completion alone is not a reason to show a creator-facing approval gate. Any approval that remains in the standard path must be visible next to the human explanation of what will become true after the action.

## Current known follow-up

The repository contains many older technical labels inside advanced and mixed-purpose components. Sprint 24 introduces the presentation layer and simplifies the shared shell and primary Design workflow first. Remaining high-value follow-up is to replace mixed labels in specialized page components with the centralized mapping, then complete a dedicated mobile pass over long inspector-heavy routes.
