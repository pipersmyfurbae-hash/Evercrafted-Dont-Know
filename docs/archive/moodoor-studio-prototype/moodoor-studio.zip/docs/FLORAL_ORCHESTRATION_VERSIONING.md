# Floral Orchestration Versioning

The orchestration lifecycle is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`. Candidate choice, controlled role edits, regeneration, and approval create native revisions. Approval freezes the role map for the next engine.

If Greenery Architecture changes, orchestration is retained and marked `STALE`. Essence and Composition changes propagate through the existing dependency chain so no approved role map is silently reused against a different upstream architecture. Provenance records orchestration ID and revision, source architecture ID and revision, source composition revision, source interpretation revision, timestamps, engine version, and model/provider.

## References

[1]: ../client/src/data/orchestration.ts "Orchestration lifecycle"
[2]: ../client/src/data/greenery.ts "Architecture-to-orchestration stale propagation"
[3]: ../client/src/data/vnext.ts "Native persistence and activity history"

[1] [2] [3]
