# Sprint 17 Findings — Lifestyle Scene Generator & Lookbook Studio

## Scope

Sprint 17 adds a creator-facing bridge from an approved `MOODOOR_CAMPAIGN_V1` Campaign Package to structured lifestyle scenes, scene render packages, manual or renderer-backed image intake, and an editorial Lookbook. It does not redesign approved wreaths, replace campaign direction with prose prompts, or fabricate renderer success.

## Scene Contract

Each `MOODOOR_SCENE_V1` record preserves the Campaign scene direction and carries a Product Identity Contract when a product is present. The contract records the source design revision, Blueprint and ECR revisions, botanical families, approved palette, composition and focal evidence, silence and negative-space boundaries, outer silhouette, dimensions, approved product render references, and hard locks.

The scene environment is separate from product identity. It can describe a door, interior, detail, atmospheric, transition, or collection context, but it cannot override the approved Blueprint, ECR, botanical identity, palette, focal structure, or negative-space treatment. Three scenes can therefore share one product contract while varying place, camera, lighting, scale, and mounting conditions.

## Reference Authority

Scene render packages expose a reference manifest with explicit authority levels. Product Identity and Geometry outrank Botanical Material, Campaign Continuity, Architecture, Environment, Lighting, and Style. The prompt payload remains structured by section rather than becoming an uncontrolled prose prompt. Negative constraints include identity-preservation rules such as no ribbon, ornaments, berries, lights, unapproved florals, symmetrization, hybridization, or filling of silence zones.

## Lifecycle and Renderer Boundary

Scene progression is `DRAFT → COMPILED → PREPARED/VALIDATED → GENERATING or MANUAL REVIEW → APPROVED/LOCKED`, with `REJECTED`, `NEEDS_REVIEW`, and `STALE` states available. The reference adapter returns `UNAVAILABLE` when no live renderer is connected. Manual image intake records the declared renderer, image URI, import time, and review requirement; it does not claim that the image passed QC.

## Lookbook Contract

`MOODOOR_LOOKBOOK_V1` is separate from Scene assets. A Lookbook contains page architecture, scene references, copy placement, design-system direction, asset and copy manifests, validation, provenance, and approval status. Page operations include scene selection, replacement, page locking, copy editing, reordering, architecture regeneration, validation, approval, and structured package export. A failed or missing asset cannot silently enter an approved Lookbook.

## Creator Workflow

The primary creator path is Campaign → Scenes → Compile Campaign Scenes → Prepare Scene Package → Generate or Import Image → Review → Create Lookbook → Validate → Approve → Export. The Advanced Scene Inspector exposes the Product Identity Contract and Scene Render Package for technical review without making the technical contract the primary creator experience.

## Verification

Sprint 17 adds four scene/lookbook regression tests covering shared product identity across Product Hero, Door, and Interior scenes, distinct environment contracts, authority order, hard negative constraints, honest renderer transport, manual intake provenance, approval gating, campaign gating, and Lookbook creation. The full suite passes with 91 tests across 17 files; TypeScript and production build also pass.

## Explicit Boundary

A live image provider, visual scene QC, and a fully rendered marketing lookbook remain dependent on a renderer and image evidence. The application now prepares the exact structured handoff and review state without inventing image outputs.
