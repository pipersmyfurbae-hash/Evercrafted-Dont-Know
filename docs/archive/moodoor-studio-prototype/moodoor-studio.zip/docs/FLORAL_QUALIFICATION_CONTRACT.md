# Floral Qualification Contract

Each active floral role receives `required`, `preferred`, `avoid`, and `tolerances`. Hard requirements are true performance constraints; soft requirements are stylistic preferences that a future material selector may negotiate. Avoid lists identify fragile, glossy, wispy, flat, overly dense, too-small, overly symmetrical, meadow-like, or fresh-cut behaviors when they conflict with the role.

Qualifications preserve the approved role, pocket, hierarchy, scale, movement, depth, radial, interweaving, and faux-read intent. They do not disguise species selection through exact measurements or narrow named-material descriptions.
