# Sprint 2 Write Architecture

## Boundary

Sprint 2 adds the first controlled write path to Moodoor Studio. Legacy records remain adapter-readable and read-only. Native records are written only to the canonical vNext repository in the new app.

> Legacy data is read through adapters. New Moodoor data is written through the canonical vNext repository.

## Stores

| Namespace | Role | Status |
|---|---|---|
| `moodoor.vnext.designs` | Native vNext design records | Implemented. |
| `moodoor.vnext.schema_version` | Schema marker | Implemented. |
| `moodoor.vnext.identity_map` | Reserved for future reversible identity crosswalks | Reserved, not written in Sprint 2. |
| `moodoor.vnext.activity` | Immutable activity entries | Implemented. |
| Legacy keys | Existing source records | Never written by Studio. |

The repository is the only module that calls `localStorage` for vNext writes. UI pages use repository and service methods rather than direct persistence calls.

## Repository surface

`MoodoorDesignRepository` implements `list`, `get`, `create`, `update`, and controlled `transition`. Archive and restore are status changes; there is no hard-delete method. `MoodoorActivityRepository` stores simple immutable entries for creation, edit, archive, and restore. Full event sourcing is intentionally out of scope.

## UI boundary

The Create route supports memory, idea, blank, and explicit legacy-fork starts. Native detail routes expose editable Overview and Essence tabs, while Design, Render, Story, Collections, Commerce, and Raw Legacy remain read-only or placeholders. Legacy detail pages show `LEGACY / READ ONLY` and an explicit fork action.

## References

[1]: ../client/src/data/vnext.ts "Canonical vNext repository and status services"
[2]: ../client/src/pages/Create.tsx "Draft creation flow"
[3]: ../client/src/pages/DesignDetail.tsx "Native editing and legacy fork controls"
[4]: ../client/src/data/service.ts "Unified legacy plus vNext read service"

[1] [2] [3] [4]
