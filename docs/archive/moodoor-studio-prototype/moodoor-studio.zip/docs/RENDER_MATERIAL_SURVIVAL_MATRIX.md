# Release Fix 25.1 — Render Material Survival Matrix

This matrix records the material-bearing information available at each canonical boundary. It is generated from the current Design state by `MoodoorDesignOrchestrator.getMaterialSurvivalMatrix` and does not infer missing materials.

| Stage | Floral role counts | Greenery | Families | Quantities / placements | Structural instructions | Source references |
|---|---:|---:|---|---:|---|---|
| Floral Orchestration | Primary, secondary, support, accent role counts | Abstract greenery zones | Not yet concrete | Role intent only | Role hierarchy and interweaving intent | Orchestration revision |
| Botanical Selection | Same role counts | Greenery selections | Selected floral and greenery families | No exact SKU quantities | Qualification fit, family usage, palette | Selection set |
| Inventory Resolution | Same role counts | Resolved greenery assets | Resolved families/SKUs | Required quantities and feasibility | Availability warnings and source evidence | Resolution revision |
| Blueprint | Role-linked placements | Greenery sweeps and zones | Placement/sweep families | BOM quantities and placement count | Angles, depth, orientation, insertion, interweaving, silence, negative space | Blueprint ID |
| ECR | Render objects and relationships | `greenery_sweep` objects | Object family/SKU references | Render object count | Depth, insertion, interweaving, silence, negative space, render constraints | ECR ID and source Blueprint |
| Render Package | Structured ECR contract | ECR greenery objects | Asset context families/SKUs | Structured object contract | Relationships, constraints, silence, presentation profile | Render package ID |
| Copied Prompt | Renderer-oriented prose | Explicit greenery lines where ECR contains them | Explicit family/SKU references where supported | Per-object density plus supported BOM context | Foundation, roles, placement, depth, interweaving, silence, prohibitions, presentation | ECR-derived prompt |

## Release finding

The pre-fix copied prompt only listed ECR botanical objects as `family at angle, depth`. It did not explicitly communicate role, quantity/density, greenery zone and sweep direction, or the structured negative-space boundary in renderer-oriented sections. The first confirmed loss in the reported path was therefore **Prompt Compiler / copied-prompt formatting**, after the ECR and Render Package retained structured object and constraint data. The correction enriches the prompt from canonical ECR and Blueprint evidence without inventing botanicals or altering placement geometry.

The matrix also keeps upstream causes visible. If a role or greenery family is absent from Selection, Inventory, Blueprint, or ECR, the prompt compiler does not create it; the missing category must be reported as an upstream issue.
