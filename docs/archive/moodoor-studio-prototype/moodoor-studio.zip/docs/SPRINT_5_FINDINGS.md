# Moodoor Sprint 5 Findings

## Summary

Sprint 5 translates approved compositional architecture into material-agnostic structural greenery architecture. The layer creates meaningful rooms for future floral roles while preserving silence, negative space, eye rest, and approved flow. It stops before species, flowers, inventory, blueprint compilation, ECR, render prompting, rendering, QC, collections, campaigns, and production.

## Architecture service

`MoodoorGreeneryArchitectureService` requires approved Essence and approved Composition. It generates up to three candidates containing greenery mass, structural zones, first-class pockets, extensions, radial behavior, depth planes, silence protection, negative-space validation, eye-rest preservation, flow validation, rationale, validation, and provenance.

Greenery is represented as structure rather than filler. Zones carry role, density, movement, radial behavior, depth behavior, strength, and reason. Pockets carry hierarchy, capacity, role eligibility, depth plane, radial band, orientation, relationship, and reason. No pocket capacity maps to a species or SKU.

## Protection and validation

`MoodoorGreeneryArchitectureValidator` returns PASS, WARNING, or BLOCK. It checks focal support, hero-pocket conflict with silence, pocket separation through angular plus radial/depth distinction, hierarchy, negative space, eye rest, approved flow, and forbidden material/species data. Silence may remain exposed, touch the edge, or be lightly framed, but is not filled because coverage looks incomplete.

## Review UI

The Design tab now continues from Composition into Greenery Architecture. The existing circular instrument is extended with structural zone arcs, reserved pocket markers labeled as future rooms, extensions, and protected silence. The surface supports generation, regeneration, candidate selection, and approval while explicitly stating that no species, inventory, or blueprint is involved.

## Lifecycle and stale behavior

Architecture status is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`. Manual edits are revisioned. When an approved composition changes, the existing architecture is retained and marked stale; it is never silently replaced. Approval does not transition the design to `DESIGNED` because downstream floral and blueprint work remains outside the sprint.

## Tests and validation

The Sprint 5 suite includes restrained crescent, sweeping arc, remembrance/silence, offset cluster, full interruption, similar-profile diversity, approval isolation, and stale-propagation cases. Across vNext, Essence, Focal, and Greenery suites, 31 tests pass. TypeScript checks and production build pass. No material, species, SKU, inventory, blueprint, ECR, render, or legacy write path was introduced.

## Sprint 6 recommendation

Sprint 6 may consume approved greenery architecture to orchestrate abstract flower-role placement into eligible pockets. It should preserve material agnosticism until role selection is explicitly introduced, maintain pocket hierarchy and interweaving, and treat stale architecture as a hard gate for downstream role orchestration.

## References

[1]: GREENERY_ARCHITECTURE_ENGINE.md "Greenery architecture engine"
[2]: GREENERY_POCKETS_CONTRACT.md "Greenery pockets contract"
[3]: STRUCTURAL_ZONE_MODEL.md "Structural zone model"
[4]: DEPTH_PLANE_MODEL.md "Depth-plane model"
[5]: GREENERY_ARCHITECTURE_VERSIONING.md "Architecture versioning"
[6]: ../client/src/data/greenery.test.ts "Sprint 5 architecture tests"

[1] [2] [3] [4] [5] [6]
