# Studio Route Map

## Operator frame

Every Studio route is wrapped in a persistent operator frame:
- **Left rail:** Identity, brand mark, fixture-mode label, and workbench navigation.
- **Top bar:** Internal breadcrumbs, read-only status chip, and search/settings placeholders.
- **Main frame:** Evidence-first content canvas.

## Active routes

| Route | Purpose | Evidence shown |
|---|---|---|
| `/studio` | Home / Observatory | Health summary, architecture overview, source inventory. |
| `/studio/library` | Library | Normalized design list, identity filters, EVS dots, relationship health. |
| `/studio/library/:id` | Design Detail | Overview, Essence, Design, Render, Story, Collections, and Raw Legacy. |
| `/studio/dev/data-health` | Data Health | Diagnostic metrics, relationship risks, unresolved dependencies. |

## Feature placeholders

The following routes are intentionally present in the navigation rail but display a “Coming in future sprint” placeholder. No legacy engine code has been ported to these routes.

- `/studio/create`
- `/studio/collections`
- `/studio/campaigns`
- `/studio/production`

## References

[1]: ../client/src/App.tsx "Route and shell implementation"
[2]: ../client/src/pages/ "Page components"

[1] [2]
