# Compatibility Layer

## Contract

The compatibility layer has one job: make legacy-shaped records readable through normalized runtime models while keeping source identity and raw payloads attached. It is not a migration layer and it is not a second writer.

Each adapter returns `{ source, sourceId, normalized, raw, errors, missingRelationships }`. The resolver then assigns identity status using the approved hierarchy. The service composes only resolved or explicitly flagged records into `MoodoorDesign` objects.

## Fixture isolation

This Sprint 1 implementation runs in explicit **DEVELOPMENT FIXTURE MODE**. The fixture JSON files are copied into the Studio source tree and imported as static modules. No `localStorage.getItem`, `localStorage.setItem`, or `MoodoorData` call exists in the Studio application. Because there is no real-store adapter in this sprint, fixtures cannot accidentally mix with real legacy data.

## Identity statuses

| Status | Meaning | UI treatment |
|---|---|---|
| `EXACT` | Explicit LibraryItem or foreign-key evidence resolved. | Lichen green continuity badge. |
| `RESOLVED` | Stable blueprint or known legacy alias resolved. | Lichen green continuity badge with evidence tier. |
| `AMBIGUOUS` | More than one candidate or conflicting evidence. | Clay warning; never auto-merged. |
| `ORPHAN` | No exact evidence exists. | Clay warning; source record remains visible. |

## Read-only guarantee

The service exposes only `get*` methods. UI routes expose filters, tabs, and raw record inspection, but no edit, delete, migrate, or persistence controls. Future write paths must be introduced as a separate reviewed module and must not be added to this foundation.

## References

[1]: ../client/src/data/adapters.ts "Adapter return contract"
[2]: ../client/src/data/resolver.ts "Identity status implementation"
[3]: ../client/src/data/service.ts "Read-only service methods"
[4]: ../client/src/data/fixtures "Development fixture source"

[1] [2] [3] [4]
