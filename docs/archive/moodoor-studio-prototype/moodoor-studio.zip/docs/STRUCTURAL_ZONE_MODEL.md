# Structural Zone Model

Structural greenery zones describe botanical architecture without botanical identity. Roles include focal support, secondary support, transition, directional extension, frame, counterweight, bridge, and quiet support. Each zone carries a clock range, density, movement, radial behavior, depth behavior, strength, and reason.

Radial behavior distinguishes inward, balanced, and outward structure. Depth behavior distinguishes layered, stepped, and quiet structure. Extensions add upward, lateral, downward, architectural, or contained movement beyond the core ring, with their own origin clock, direction, length class, strength, purpose, radial band, and depth plane.

The primary focal support must remain structurally stronger than the secondary support. Quiet support may touch a silence boundary, but it may not turn protected silence into another focal event.

## References

[1]: ../client/src/data/vnext.ts "Structural zone and extension fields"
[2]: ../client/src/data/greenery.ts "Structural architecture generation"

[1] [2]
