# Silence Zone

A silence zone is the intentional place where composition stops speaking. It is not a generic empty segment and it is not a promise that the base will remain completely bare.

The Sprint 4 contract stores a start clock, end clock, intensity, and purpose. The zone is derived from restraint, intimacy, emotional tension, and the approved interpretation. It may later become exposed grapevine, restrained greenery, or visual breathing room, but it cannot host a competing focal event in this sprint.

Silence is a compositional resource. It allows warmth to feel remembered rather than continuous, lets the eye settle after a focal encounter, and prevents a circular design from demanding uninterrupted visual activity around the full ring.

## References

[1]: ../client/src/data/focal.ts "Silence-zone generation"
[2]: COMPOSITION_CONTRACT.md "Structured silence-zone contract"

[1] [2]
