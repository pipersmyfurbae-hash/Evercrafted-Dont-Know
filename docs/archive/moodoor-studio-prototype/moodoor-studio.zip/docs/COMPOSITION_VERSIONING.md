# Composition Versioning

Composition lifecycle is independent from MoodoorDesign status. `GENERATED` candidates can be reviewed and compared; the selected candidate becomes `REVIEWED`; approval freezes the current composition revision for Sprint 5. Manual edits increment the composition revision and do not regenerate Essence or EVS.

When the approved Essence changes, the existing composition is retained and marked `STALE`. Sprint 4 does not silently destroy or regenerate it. The operator must explicitly generate or regenerate a new candidate set from the new approved interpretation.

Provenance records the composition ID, revision, source interpretation ID and revision, generated and approved timestamps, model/provider, and engine version. Composition approval does not transition the design to `DESIGNED` because later floral/blueprint work is still outside the Sprint 4 boundary.

## References

[1]: ../client/src/data/focal.ts "Composition lifecycle implementation"
[2]: ../client/src/data/essence.ts "Essence-to-composition stale propagation"
[3]: ../client/src/data/vnext.ts "Composition and activity persistence"

[1] [2] [3]
