# Moodoor Essence Engine

## Mission

Sprint 3 interprets what a memory means emotionally before any material, floral, greenery, focal, blueprint, render, or production decision. `MoodoorEssenceService` accepts a native vNext record and returns structured interpretation rather than prose that the UI must parse.

## Output sections

| Section | Purpose |
|---|---|
| `essence` | Emotional meaning that should survive translation into design. |
| `emotional_center` | Dominant emotional truth. |
| `emotional_tension` | Coexisting feelings such as warmth + absence. |
| `memory_signals` | Evidence found in the supplied memory. |
| `sensory_signals` | Categorized cues for temperature, material, light, weather, color, and space. |
| `symbolic_signals` | Source cue plus non-factual interpretation. |
| `avoid_literalizing` | Explicit guardrails against themed craft translation. |
| `predicted_evs` and rationales | All seven established EVS axes with operator-readable reasons. |
| `territory` | Existing territory semantics with confidence and reason. |
| `design_intent` | Controlled visual intent without materials or geometry. |
| `heard_check` / `unexpected_check` | Internal North Star checks, not customer scores. |

The current implementation is deterministic and fixture-safe. It is intentionally not a flower lookup table and does not call legacy prompts or downstream engines.

## Service API

`MoodoorEssenceService` provides `interpretMemory`, `regenerateEssence`, `reviewEssence`, `approveEssence`, and `hasApproved`. Generated interpretations retain model/provider and prompt-version provenance, source memory revision, raw response evidence, and interpretation revision.

## Safety boundary

Observed EVS is never populated by interpretation. The engine does not choose materials, assign clock positions, create blueprint geometry, generate renders, run QC, or write legacy records.

## References

[1]: ../client/src/data/essence.ts "MoodoorEssenceService implementation"
[2]: ../client/src/data/vnext.ts "Interpretation record and persistence contract"
[3]: ../client/src/data/models.ts "Established EVS axes"

[1] [2] [3]
