# Release Fix 25.1 Findings

## Outcome

The Standard creator path now runs safe internal stages automatically and exposes one canonical continuation action. The copied render prompt now projects the approved wreath as renderer-oriented prose rather than a compressed family/angle/depth list.

The supported golden path is:

> Design idea → Create Design → automatic orchestration → Design Ready → Visualize my design → Copy Render Prompt.

Routine internal approval clicks are not required in Standard Mode. Advanced inspectors and canonical approval records remain available for expert review.

## Exact first-loss boundary

The first confirmed loss of expected render detail was the **Prompt Compiler / copied-prompt formatter**. ECR and Render Package retained structured botanical objects, greenery sweeps, relationships, depth, interweaving, silence, negative space, and asset references. The old copied prompt reduced those objects to family, angle, and depth phrases, so role hierarchy, greenery sweep context, density, and explicit space language became difficult or absent in the final renderer instruction.

This release corrects that boundary. It does not claim that upstream diversity is always present: selection and inventory may legitimately produce repeated families or limited greenery when fixture availability requires it. The compiler reports missing canonical categories instead of inventing replacements.

## Geometry finding

The peony-like Blueprint geometry was not defective based on the available regression evidence. The correction does not modify placement angles, radius, depth, rotation, tilt, facing, insertion, or interweaving. Tests capture placement angles before and after prompt compilation and confirm they remain unchanged.

## Standard continuation

`MoodoorDesignOrchestrator` now exposes stage policies, `getNextCreatorAction`, material-survival rows, and prompt validation. `CreatorFlow` and `DesignDetail` use the continuation result to keep the current Design ID and revision in context. The Design-specific path ribbon links Design, Visualize, Refine, and Finish without routing the creator through generic navigation.

## Verification

The release verification passed with 128 tests across 25 suites, TypeScript, and the production build. The browser verification pass captured Standard Studio, Create, Library, and Public Home at mobile width; the critical navigation and path ribbon remain visible and reachable. The external image renderer remains explicitly unavailable in the existing mock adapter, so no render image is fabricated.

## Stop boundary

This release stops at Release Fix 25.1. It does not begin Sprint 26, add a new design engine, integrate another repository, invent botanicals, alter valid placement geometry, or claim external rendering success.
