# Floral Role Orchestration Engine

Sprint 6 decides what each eligible greenery pocket must do before any botanical is selected. `MoodoorFloralOrchestrationService` requires approved Essence, approved Composition, and approved Greenery Architecture. It generates up to three constrained role maps, validates them, and persists the selected map separately from all legacy records.

The engine uses emotional center, tension, predicted EVS, composition, greenery pocket map, and recent orchestration history as context. It does not use direct species lookup, inventory, SKU, stem count, blueprint geometry, ECR, or render prompting. The result is a role contract for a later qualified-material engine.

## References

[1]: ../client/src/data/orchestration.ts "Sprint 6 orchestration service"
[2]: ../client/src/data/vnext.ts "Orchestration persistence contract"
[3]: ../client/src/data/orchestration.test.ts "Sprint 6 orchestration tests"

[1] [2] [3]
