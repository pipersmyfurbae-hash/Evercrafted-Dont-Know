# Release Fix 25.1 — Render Fidelity Trace

## First confirmed loss point

The first confirmed loss was the **Prompt Compiler / copied-prompt formatter**, not placement geometry. Before this fix, `promptFor` read `ECR.objects` but reduced each botanical to a short family/angle/depth phrase. It omitted role language, greenery sweep context, useful density, and explicit negative-space prose even though the ECR and Render Package retained those structures.

| Boundary | Evidence retained | Evidence now traced |
|---|---|---|
| Floral Orchestration | Abstract role hierarchy, support roles, bridge/interweaving intent | Matrix row records role counts and source revision. |
| Botanical Selection | Concrete floral/greenery families and family usage | Matrix row records selected families and greenery families. |
| Inventory Resolution | Resolved assets, required quantities, feasibility warnings | Matrix row records quantity totals and source resolution. |
| Blueprint | Placements, sweeps, BOM, angles, depth, insertion, silence, negative space | Matrix row records placement count, quantity, depth, interweaving, and space constraints. |
| ECR | Foundation, botanical objects, greenery sweeps, relationships, constraints | Prompt compiler reads these objects without changing them. |
| Render Package | Structured ECR contract, asset context, relationships, constraints, presentation profile | Existing package contract remains intact; copied prompt is now a readable projection of it. |
| Copied prompt | Previously compressed and incomplete | Now includes approved materials, role, quantity/density, greenery zone/arc/flow, placement, depth, interweaving, silence, negative space, foundation, and presentation constraints. |

## Geometry finding

The peony-like placement geometry was not changed. `Blueprint` remains the source of angle, radius, depth, rotation, tilt, facing, insertion, and interweaving. ECR compilation continues to copy that geometry explicitly, and the prompt correction only adds descriptive renderer language around it.

## Inventory finding

A fixture inventory can legitimately narrow material diversity when only certain families are available or feasible. That is an inventory-driven constraint, not permission for the prompt compiler to invent a missing family. The new completeness validator reports supported categories and prevents a false “ready” claim when a required canonical category is absent.
