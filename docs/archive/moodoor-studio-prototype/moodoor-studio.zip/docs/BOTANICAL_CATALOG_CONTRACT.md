# BOTANICAL CATALOG CONTRACT

Sprint 8 implements a deterministic, catalog-capability-based botanical selection layer gated on approved Botanical Qualification. It selects botanical families and color families only, explains qualification fit, respects hard constraints, family budgets, role sharing, exclusions, palette restraint, and anti-repetition, and preserves reviewable provenance.

The layer does not query inventory, select SKUs or vendors, assign exact quantities, compile blueprints, generate ECR or render prompts, or mutate legacy data.
