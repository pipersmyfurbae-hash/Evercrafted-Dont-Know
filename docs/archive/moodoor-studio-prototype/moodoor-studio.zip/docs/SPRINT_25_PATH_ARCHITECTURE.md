# Sprint 25 Path Architecture

Sprint 25 turns six product expectations into visible navigation grammar. The architecture does not introduce new design intelligence; it makes the existing routes and services legible as journeys.

| Journey | Visible sequence | Entry points |
|---|---|---|
| Memory-first | Memory → Design → Render → QC → Publish | Studio Home, Create, Design workflow, Publishing |
| Existing-render-first | Upload Render → Reconstruct → Create Design → Story → Publish | Studio Home, Reverse Intake, Campaigns, Publishing |
| Collection | Designs → Collection → Campaign → Scenes → Lookbook → Launch | Library, Collections, Campaigns, Launches |
| Production | Approved Design → Order → Inventory → Build Guide → QC → Complete | Library, Orders, Inventory, Production |
| Customer | Public Home → Find Your Wreath → Memory Match → Design → Story / Collection / Lookbook | Public header, Home, Find Your Wreath, public catalog |
| Mobile | Every critical creator and customer action remains visible, grouped, and horizontally reachable | Responsive path ribbon and action layouts |

## Shared path ribbon

`client/src/components/PathArchitecture.tsx` defines the path labels, step order, continuation targets, and current-step mapping. Internal Studio routes receive the creator journey through the Standard-mode shell. Public routes receive the Customer journey through the public shell. The ribbon is deliberately compact: it shows where the person is, what the route belongs to, and which direct links are safe to use next.

## Entry points

Studio Home now exposes Memory-first through **Start with a memory**, Existing-render-first through **Upload an existing render**, and direct Collection and Production entry cards. The primary rail continues to expose Create, Library, Collections, Campaigns, Production, and Publishing. Inventory, Legacy review, and Data health remain secondary operational destinations.

The public shell continues to expose Wreaths, Collections, Stories, Lookbooks, Find Your Wreath, How Moodoor Works, and Studio. The Customer ribbon connects these without exposing internal paths or production systems.

## Mobile rule

The path ribbon is horizontally scrollable, uses short labels, and keeps step numbers visible. Primary action groups remain stacked or wrapped in existing responsive layouts. The six journeys are tested at mobile width for labels, direct targets, and critical action reachability; full-page screenshots are part of the release verification pass.

## Boundary

Path links do not imply that a downstream record exists. A continuation target may open a creator workspace with a guarded empty state, an approval requirement, or a no-record message. That is intentional: the path is visible, while the system remains honest about what has and has not been created. Legacy data remains read-only, public pages remain separate from Studio, and the path ribbon does not bypass canonical lifecycle gates.
