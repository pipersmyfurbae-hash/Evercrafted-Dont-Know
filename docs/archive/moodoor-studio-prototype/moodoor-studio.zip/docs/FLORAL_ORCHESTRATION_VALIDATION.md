# Floral Orchestration Validation

`MoodoorFloralOrchestrationValidator` returns `PASS`, `WARNING`, or `BLOCK`. It checks the primary focal gate, pocket existence, eligibility, capacity, hierarchy, depth and radial diversity, bridge/transition presence, accent overload, and prohibited material data.

The validator is designed against three failure modes. **Anti-bouquet** rejects maps that collapse into one undifferentiated cluster without a bridge or transition. **Anti-clump** requires major roles to differ through angular, radial, depth, greenery, or scale separation. **Anti-confetti** warns or blocks excessive small equal-weight accents. A material-family budget limits how many future families may be used without selecting any family or species now.

Silence and eye-rest protection remain upstream responsibilities represented by the approved Greenery Architecture and are not silently overwritten by orchestration.

## References

[1]: ../client/src/data/orchestration.ts "Floral orchestration validator"
[2]: ../client/src/data/orchestration.test.ts "Validation regression tests"

[1] [2]
