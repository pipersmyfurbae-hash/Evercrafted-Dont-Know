# Predicted EVS

Sprint 3 preserves the established seven-axis vocabulary exactly: `warmth`, `energy`, `nostalgia`, `valence`, `intimacy`, `restraint`, and `seasonal`.[1]

## Contract

Every generated interpretation contains all seven numeric values in the range 0.0–1.0 and a short rationale per axis. Numeric values remain directly accessible for computation; rationales exist for operator review and debugging. `predicted_evs` is written to the native vNext record. `observed_evs` remains untouched and null for pre-render native drafts.

## Derivation posture

The current fixture implementation uses contextual cue groups rather than one-to-one material or emotion mappings. Memory cues adjust the axes in combination, and the resulting values inform territory and visual intent. The service does not select flowers, colors as product instructions, greenery, focal positions, stems, or geometry.

## Effective EVS

Native pre-render designs use predicted EVS as the effective runtime vector. Observed EVS remains a future post-render signal and may supersede predicted EVS only in a later reviewed workflow.

## References

[1]: ../client/src/data/models.ts "Canonical EVS axes"
[2]: ../client/src/data/essence.ts "Predicted EVS derivation and rationales"

[1] [2]
