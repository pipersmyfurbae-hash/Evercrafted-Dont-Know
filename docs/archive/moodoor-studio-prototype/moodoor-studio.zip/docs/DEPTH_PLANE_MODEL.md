# Depth Plane Model

Sprint 5 uses three controlled depth planes: `background`, `midground`, and `foreground`. Depth is structural, not a material-rendering instruction. A restrained architecture uses multiple planes selectively rather than assigning every zone to every plane.

Depth supports interweaving: a future pocket can be foreground while structural greenery passes behind it in midground, or a quieter background zone can create visual separation near the eye-rest area. The depth plan is stored as references to zone, pocket, and extension IDs so later blueprint work can consume an auditable architecture rather than re-infer depth from prose.

## References

[1]: ../client/src/data/vnext.ts "Depth-plan contract"
[2]: ../client/src/data/greenery.ts "Depth-plan generation"

[1] [2]
