# MOODOOR_CAMPAIGN_V1

Campaign records are persisted under `moodoor.vnext.campaigns`. A record references exactly one approved Design, approved Collection, saved curated Collection, or an existing campaign revision. It stores source revision, Story World, Narrative Architecture, Visual Direction, Copy Direction, Scene Architecture, Campaign Sequence, Product Stories, Campaign Copy, Continuity Contract, validation, candidate directions, lifecycle, and provenance.

Campaign Package is intentionally separate from Render Package. Campaign Package defines the world and scene directions for Sprint 17; Render Package remains the renderer-specific handoff for one image.

Source records are immutable from Campaign Studio. A campaign edit creates a campaign revision, and a material source revision marks the campaign `NEEDS_REVIEW` rather than deleting it.
