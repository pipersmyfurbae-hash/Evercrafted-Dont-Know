# Moodoor Sprint 23 Findings

## Mission and migration boundary

Sprint 23 adds a controlled migration, reconciliation, compatibility, and retirement layer between the legacy Moodoor source surface and the canonical Studio architecture. The active sequence is source inventory, immutable snapshot, classification, identity resolution, canonical mapping, dry run, conflict and orphan review, human approval, migration, parity validation, rollback readiness, and only then guarded retirement.

The migration layer does not casually reshape Sprints 1–22 contracts. It adapts legacy evidence to those contracts, preserves original IDs and payloads, and records unresolved gaps instead of inventing canonical fields. No live legacy storage or source file is modified by the implemented workflow.

## Actual source inventory

The current project contains committed fixture representations for catalog, LibraryItems, Stories, renders, collections, and blueprints under `client/src/data/fixtures`. The shared project also contains legacy fixture data, legacy HTML pages, support JavaScript, prompt sources, and prior migration evidence under `/home/ubuntu/projects/evercrafted-55924692`. The Sprint 23 inventory records these source locations and explicitly marks the historical `image-slot.js` source as requiring review because it was not recovered.

The current verification environment has fixture coverage only. A production browser `localStorage` export was not available, so production parity cannot be claimed from these fixtures. The manifest communicates `FIXTURE_ONLY` coverage rather than presenting fixture migration as proof of live-data migration.

## Canonical manifest and persistence

`MoodoorLegacyMigrationManifest` uses `MOODOOR_LEGACY_MIGRATION_V1` under isolated `moodoor.vnext.legacy_migrations` storage. It preserves immutable snapshot metadata, checksums, source inventory, identity crosswalk, migration records, conflicts, orphans, duplicates, unresolved records, validation results, rollback metadata, status, revision, and provenance history. Crosswalk entries are persisted separately under `moodoor.vnext.legacy_crosswalk`.

Source classes include data source, active runtime, public page, operator tool, shared dependency, generated artifact, reference only, duplicate, obsolete, and unknown. Retirement dispositions include archive, migrate data, replace or redirect to vNext, remove from active runtime, and human review. Retirement cannot proceed until parity validation returns `VALIDATED`.

## Identity and dry-run semantics

Identity resolution follows a deterministic order: existing crosswalk, exact stable legacy ID, confirmed relationship, and then unresolved candidate. Names alone do not prove identity. Duplicate names create `POSSIBLE_DUPLICATE` conflicts rather than automatic merges. Records without stable identity are marked orphaned or review-required. Renders with missing image evidence or no stable Design relationship route to Sprint 22 Reverse Intake instead of attaching to a guessed Design.

The dry-run operates over cloned fixture inputs and creates migration records with source payload, intended target, action, review status, conflict references, orphan and duplicate flags, and parity status. It does not mutate canonical Design storage or legacy inputs. Story records always receive a privacy conflict requiring public/private review before any use as public Memory or Story content. Prompt artifacts are preserved-only evidence by default.

## Migration and rollback

Actual migration is human-gated. A migration record must be explicitly approved, and blocked conflict records cannot migrate. Catalog and LibraryItem candidates may create native vNext Designs with `legacy_fork` origin, original legacy aliases, source path, raw legacy payload, and only the canonical fields supported by legacy evidence. The record remains traceable to the migration manifest.

Parity can be checked record-by-record and at the manifest level. The current parity model distinguishes PASS, WARNING, and BLOCK outcomes, including preserved-only records and records routed to Reverse Intake. Rollback marks the migration run `ROLLED_BACK` and preserves the immutable snapshot; it does not delete source evidence.

## Creator/operator surface

The internal route `/studio/migration` provides source inventory, immutable snapshot creation, dry-run, parity validation, rollback, manifest status, conflict counts, source checksums, destination labels, and review records. It makes the no-live-legacy-write boundary and guarded retirement visible. The interface follows the Botanical Instrument Panel grammar with calibrated readouts, brass provenance labels, clay-red guarded states, a diagnostic rail, and compact archive ledgers.

## Verification

Sprint 23 focused verification passes TypeScript and five migration tests. Full verification passes 23 test files with 117 tests and the production build. The operator visual review covers the migration console and Studio home. Existing non-blocking notices remain limited to the known runtime asset resolution warning and bundle-size warning from the project build.
