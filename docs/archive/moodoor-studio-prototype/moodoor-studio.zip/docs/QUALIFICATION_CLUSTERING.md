# Qualification Clustering

Qualification clusters group roles whose characteristic requirements are compatible enough to share a future material family while retaining distinct scale, quantity, hierarchy, and placement behavior. Sprint 7 creates small explicit clusters such as focal/echo and bridge/transition.

Incompatibility rules include hero mass versus micro airy material, directional accent versus rigid compact orb, and deeply nested focal versus fragile non-interruptible form. Clustering never selects a family; it only narrows future reuse opportunities.
