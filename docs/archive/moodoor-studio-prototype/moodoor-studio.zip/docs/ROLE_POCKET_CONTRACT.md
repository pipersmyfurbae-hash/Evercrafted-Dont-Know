# Role–Pocket Contract

Every active floral role references an existing Sprint 5 pocket or remains explicitly unassigned when restraint benefits from leaving the room open. Role assignment respects pocket eligibility and capacity. A hero or large pocket may support `PRIMARY_FOCAL`; small or accent pockets may not carry a dominant hero job. Manual overrides are allowed only as visible reviewed edits and produce validation warnings or blocks when hierarchy or eligibility is compromised.

The orchestration layer never rewrites Greenery Architecture to make an invalid assignment fit. It chooses another eligible pocket, generates another candidate, or surfaces a review outcome.

## References

[1]: ../client/src/data/orchestration.ts "Role-to-pocket assignment and validation"
[2]: ../client/src/data/vnext.ts "Pocket and role fields"

[1] [2]
