# Moodoor Studio — Sprint 13 Findings

## Outcome

Sprint 13 adds `MoodoorRenderQCService`, a strict evaluation layer over an accessible Render Result. It preserves the approved Blueprint and ECR as authoritative design truth while evaluating how a completed render reads visually. The service never fabricates image observations and never silently rewrites composition, material identity, geometry, or Essence.

## Input gate

QC requires a non-stale Render Result, Render Package, approved ECR, approved Blueprint, and an accessible image payload or reference. Supported evidence modes are `image_model`, `manual`, and `fixture`. A mock or unavailable Render Result with no image cannot enter QC; the service raises an explicit no-accessible-image error instead of inventing observations.

## EVS and drift

Observed EVS uses the same seven canonical axes as Sprint 3: warmth, energy, nostalgia, valence, intimacy, restraint, and seasonal. Predicted EVS is preserved unchanged. QC computes observed EVS separately, then stores signed drift, absolute drift, and configurable severity for every axis. The effective EVS rule is implemented as `observed → predicted → missing`, without overwriting the prediction used for drift analysis.

| Drift state | Default absolute range | Meaning |
|---|---:|---|
| `ALIGNED` | ≤ 0.10 | Observed reading remains within minor variation. |
| `MINOR_DRIFT` | > 0.10 to 0.20 | Noticeable but limited difference. |
| `MEANINGFUL_DRIFT` | > 0.20 to 0.35 | Design interpretation has materially shifted. |
| `SEVERE_DRIFT` | > 0.35 | Strong divergence requiring attention. |

Thresholds are centralized and configurable; the comparison is never reduced to one opaque number.

## Fidelity layers

The QC result stores structural, botanical, composition, Essence, North Star, violation, warning, scorecard, and provenance sections independently. Structural checks can represent focal location, silence, foundation, negative space, hierarchy, depth, radial distribution, flow, and silhouette. Botanical checks preserve uncertainty between `CONFIRMED`, `LIKELY`, `UNCERTAIN`, `MISMATCH`, and `MISSING`. Composition and Essence checks distinguish reviewable uncertainty from direct failure.

A critical violation or failing scorecard produces `FAIL`. Unresolved warnings, uncertain observations, or partial Essence alignment produce `REVIEW`. A clean evidence set can produce `PASS`. The `HEARD` and `UNEXPECTED` North Star checks remain internal QC signals and are not customer-facing scores.

## Effective EVS and lifecycle

On successful analysis, the canonical vNext record receives observed EVS, effective EVS sourced from observed values, the QC result, and QC candidate history. Approval is allowed only for `PASS`; review and fail transitions remain explicit. A QC result can be marked `STALE` when its source render or design truth changes. No QC method changes Blueprint, ECR, Render Package, predicted EVS, or legacy records.

## UI

The QC Inspector is available at `/studio/library/:canonicalId/qc`. It exposes the predicted-to-observed EVS table, signed drift and severity, effective-EVS source, decision basis, Essence alignment, violations, warnings, uncertainty, North Star checks, and source provenance. It is read-only with respect to design truth.

## Regression coverage

Sprint 13 adds four tests covering no-image blocking, complete observed EVS and drift, predicted-EVS preservation, effective-EVS update, critical hard-silence failure, review/fail lifecycle, uncertain botanical evidence, and stale propagation. The full application passes 73 tests across 12 suites, TypeScript checking, and production build verification.

## Explicit exclusions

Sprint 13 does not claim exact visual recognition without evidence, does not perform psychological diagnosis, does not fabricate image-model results, does not rewrite the design to make a render pass, and does not replace later human or model-assisted render analysis. Supplied observations are evidence inputs with visible uncertainty.
