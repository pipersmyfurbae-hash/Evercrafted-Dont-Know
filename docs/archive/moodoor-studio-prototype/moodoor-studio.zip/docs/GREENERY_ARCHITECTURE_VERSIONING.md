# Greenery Architecture Versioning

Greenery architecture is gated on approved Essence and approved Composition. Its lifecycle is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`.

Candidate choice, manual edits, regeneration, and approval create revisioned native records. Approval freezes the architecture revision for Sprint 6. If approved Essence or Composition changes, the architecture is retained but marked `STALE`; it is never silently overwritten or regenerated.

Provenance records the architecture ID and revision, source composition ID and revision, source interpretation revision, timestamps, engine version, model/provider, and approval metadata. Design status remains DRAFT because `DESIGNED` is not weakened to represent unfinished downstream floral or blueprint work.

## References

[1]: ../client/src/data/greenery.ts "Architecture lifecycle implementation"
[2]: ../client/src/data/focal.ts "Composition-to-architecture stale propagation"
[3]: ../client/src/data/vnext.ts "Native persistence contract"

[1] [2] [3]
