# Moodoor Sprint 6 Findings

## Summary

Sprint 6 adds a role-first floral orchestration layer. It determines what each eligible greenery pocket should do before any qualified botanical-material engine is allowed to select what can perform that job. Roles remain abstract and are stored separately from legacy data.

## Implementation

`MoodoorFloralOrchestrationService` requires approved Essence, approved Composition, and approved Greenery Architecture. It creates up to three constrained candidates with first-class roles, pocket assignments, hierarchy, form requirements, relative scale, quantity intent, depth and radial behavior, interweaving and occlusion intent, material-family budget, rationale, validation, and provenance.

The controlled taxonomy includes `PRIMARY_FOCAL`, `SECONDARY_FOCAL`, `SUPPORTING_FLORAL`, `BRIDGE`, `ACCENT`, `TEXTURAL_ACCENT`, `DIRECTIONAL_ACCENT`, `ECHO`, and `TRANSITION`. The service never selects species, greenery species, vendor, SKU, inventory quantity, exact stems, blueprint geometry, ECR, or render prompts.

## Safety and validation

Pocket eligibility and capacity are enforced without rewriting Greenery Architecture. The validator addresses focal hierarchy, secondary subordination, depth/radial diversity, bridge/transition presence, anti-bouquet, anti-clump, anti-confetti, family budget, and prohibited material data. Approved architecture changes mark orchestration stale while retaining the previous record.

## Review UI

The Design tab now progresses from Composition to Greenery Architecture to Floral Orchestration. The new surface uses abstract role markers such as PF, SF, BR, and AC on the circular instrument. A role inspector exposes pocket, hierarchy, scale, form, quantity, depth, radial behavior, interweaving, occlusion, and reason without rendering flowers.

## Tests and build

Five suites pass with 40 tests covering all earlier layers plus orchestration gates, restrained role counts, secondary hierarchy, strong silence, multi-depth maps, candidate diversity, approval isolation, stale propagation, and prohibited material rejection. TypeScript check and production build pass. Legacy records and downstream generation boundaries remain untouched.

## Sprint 7 recommendation

The next safe boundary is a qualified-material mapping layer that consumes approved role requirements and approved greenery architecture. It should resolve abstract form, scale, quantity intention, and material-family budget against verified assets only after explicit approval, while preserving role assignments, interweaving, silence, and stale-state gates.

## References

[1]: FLORAL_ROLE_ORCHESTRATION_ENGINE.md "Role orchestration engine"
[2]: FLORAL_ROLE_TAXONOMY.md "Floral role taxonomy"
[3]: ROLE_POCKET_CONTRACT.md "Role-pocket contract"
[4]: INTERWEAVING_CONTRACT.md "Interweaving contract"
[5]: FLORAL_ORCHESTRATION_VALIDATION.md "Orchestration validation"
[6]: FLORAL_ORCHESTRATION_VERSIONING.md "Orchestration versioning"
[7]: ../client/src/data/orchestration.test.ts "Sprint 6 tests"

[1] [2] [3] [4] [5] [6] [7]
