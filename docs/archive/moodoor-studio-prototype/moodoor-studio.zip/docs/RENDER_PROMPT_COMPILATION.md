# Release Fix 25.1 — Render Prompt Compilation

The copied prompt is a human-readable renderer instruction, not raw JSON. It is compiled from the approved ECR and Blueprint context while preserving the existing Render Package contract.

## Prompt hierarchy

The compiler presents product identity first, then approved foundation, materials and role structure, composition contract, quiet space, and hard constraints. Each material line carries only canonical evidence: family or SKU when available, role or build phase, cluster or zone, quantity/density as supported, angle or arc, depth, and interweaving.

Greenery is represented as a distinct renderer section with family/SKU, zone, arc, flow, and depth. Negative space is represented through the approved silence and negative-space boundaries. Presentation remains near-frontal, full-wreath, neutral-background, soft-editorial, square output because those values come from the render presentation profile.

## Completeness behavior

`validatePrompt` compares the final prompt against ECR categories including foundation, primary florals, secondary/support botanicals, greenery architecture, negative space, and depth/interweaving. The validator returns evidence counts and missing categories. Standard Mode must not call an incomplete prompt ready; missing canonical material is reported rather than invented.

The compiler does not add new flowers, greenery, colors, quantities, or stories. If upstream data is incomplete, the incomplete category remains visible in the validation result and requires an upstream correction or human review.

## Boundary preserved

This change does not alter Blueprint geometry, ECR object positions, render-package design contracts, legacy data, inventory availability, or external renderer claims. It only improves the final prose projection and makes prompt readiness honest.
