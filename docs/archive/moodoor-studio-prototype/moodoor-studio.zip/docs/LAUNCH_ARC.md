# Launch Arc

Launch strategies derive the smallest coherent sequence for Campaign depth. Supported arcs include Signal, Discovery, Deepening, Reveal, Consideration, Last Look where justified, and Settle.

Relative timing is used by default: T-21, T-14, T-7, T-3, T-1, Launch, and T+7. Absolute dates remain optional and are never invented.

Each moment has a purpose, channel list, asset references, copy references, product references, CTA, dependencies, timing, lock, and human-readable status.
