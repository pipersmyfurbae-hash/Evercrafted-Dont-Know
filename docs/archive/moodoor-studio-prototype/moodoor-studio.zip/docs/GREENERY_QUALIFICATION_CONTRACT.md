# Greenery Qualification Contract

Each approved Sprint 5 structural greenery zone receives a job description for form, leaf-scale behavior, movement, stiffness, directional capability, density, depth, edge interruption, trailing capability, structural longevity, and visual weight. The contract never names greenery species.

The greenery family budget defaults to a small controlled range and remains separate from the inherited floral family budget. Future selectors may reuse a qualified family only when form, depth, movement, and hierarchy remain compatible.
