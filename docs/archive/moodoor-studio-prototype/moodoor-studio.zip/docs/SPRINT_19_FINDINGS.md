# Sprint 19 Findings — Production, Orders & Build Execution

## Scope

Sprint 19 introduces the operational bridge between an approved Moodoor design and a physical build. Production consumes exact Design and Blueprint revisions, compiles deterministic material requirements, checks controlled inventory, creates attributable reservations, produces build jobs, generates maker-facing Build Guides, and records human production QC. It does not redesign the product, publish a storefront, implement checkout, migrate legacy orders, or claim carrier integration.

> Production executes the approved design. Production does not redesign it.

## Canonical operational records

| Record | Storage key | Authority | Purpose |
|---|---|---|---|
| `MOODOOR_ORDER_V1` | `moodoor.vnext.orders` | Order | Locks source, line items, Design revisions, Blueprint revisions, status, and fulfillment separation. |
| `MOODOOR_BUILD_JOB_V1` | `moodoor.vnext.build_jobs` | Build Job | Tracks the maker queue, exact Blueprint revision, material plan, guide, progress, observations, and physical QC. |
| Reservation ledger | `moodoor.vnext.reservations` | Reservation | Separates committed stock from physical stock and records release/consumption lifecycle. |
| Inventory history | `moodoor.vnext.inventory_history` | Ledger | Records receiving, reservation, release, consumption, damage, and adjustment events with reason/source/time. |

Legacy order and operator records remain read-only. No Sprint 19 service writes to legacy keys.

## Production flow

The current service path is:

`Approved Design + passing Approved Blueprint → Production Order → deterministic unit/order requirements → controlled reservation → Build Job → Build Guide → Start Build → human Production QC → completion`.

Production readiness is blocked when the Design is not approved, the Blueprint is missing or not approved, Blueprint validation is not `PASS`, or required inventory is unavailable. Unknown inventory returns a verification state rather than being treated as zero.

## Inventory semantics

`ON_HAND` is physical known stock. `RESERVED` is committed but not consumed. `AVAILABLE = ON_HAND - RESERVED`. Reservations are reversible before consumption, attributable to an Order and Line Item, and represented as explicit ledger records. The current implementation prevents double reservation through an availability check and records reservation/release/consumption events rather than silently subtracting quantities.

Shortages are human-readable and distinguish `BLOCK` from `VERIFY`. Production does not silently substitute a material. Approved-equivalent substitution and design review escalation remain explicit follow-up actions for the next operational refinement.

## Maker workflow

The creator-facing UI now exposes four operational surfaces: **Production**, **Orders**, **Inventory**, and the **Open Build** maker cockpit. The Production screen shows queue counts and job cards. Orders show operational status separately from fulfillment status. Inventory presents On Hand, Reserved, and Available values and supports reasoned receiving. Open Build presents material preparation, clock orientation, build phases, protected silence zones, negative space, and human QC actions.

The Build Guide translates Blueprint geometry into practical language. It preserves structural authority, greenery sweeps, focal placement, pocket protection, interweaving, depth, silence zones, negative space, and phase checkpoints. Exact geometry remains available through the advanced data layer rather than being required for ordinary making.

## Verification

The following checks passed during implementation:

| Check | Result |
|---|---|
| TypeScript (`pnpm run check`) | Passed |
| Production build (`pnpm run build`) | Passed |
| Sprint 19 regression file | 4 tests passed |
| Legacy safety test | Passed; no legacy order key writes |
| Reservation overcommit test | Passed; second reservation is blocked |
| Cancellation release test | Passed; unconsumed reservation returns to available |
| Revision lock test | Passed for exact Design and Blueprint revisions |

The existing development log contains an earlier stale Vite parser message for `DesignDetail.tsx`; a fresh production build completed successfully after Sprint 19 changes. The build still reports the existing unresolved `/manus-storage/moodoor-paper-grid_7c915cb8.png` warning and a bundle-size advisory; neither blocks compilation.

## Deliberate boundaries and remaining work

Sprint 19 stops before public Moodoor publishing and checkout. It also does not claim computer-vision precision for build-photo QC, autonomous learning from production observations, full warehouse management, purchase-order management, carrier integration, or customer CRM. Those boundaries are intentional and preserve the distinction between design truth and operational truth.
