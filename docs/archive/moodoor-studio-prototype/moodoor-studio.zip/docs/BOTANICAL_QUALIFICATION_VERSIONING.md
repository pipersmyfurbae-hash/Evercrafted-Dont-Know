# Botanical Qualification Versioning

The lifecycle is `NOT_STARTED`, `GENERATED`, `REVIEWED`, `APPROVED`, or `STALE`. Candidate generation, manual edits, selection, and approval create revisions. If Floral Orchestration changes, the existing qualification is retained and marked `STALE`; it is never silently regenerated.

Provenance records qualification-set ID and revision, source orchestration and revision, source architecture revision, source composition revision, source interpretation revision, timestamps, engine version, and model/provider.
