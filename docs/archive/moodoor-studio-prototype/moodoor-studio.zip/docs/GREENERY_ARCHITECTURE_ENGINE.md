# Greenery Architecture Engine

Sprint 5 translates an approved composition into structural botanical architecture. Greenery is treated as the system that establishes silhouette, directional movement, dimensional depth, transition, support, framing, separation, and negative space. It is not filler and it is not selected by covering the remaining ring.

`MoodoorGreeneryArchitectureService` requires approved Essence and approved Composition. It generates up to three deterministic candidates with structural zones, pockets, extensions, greenery mass, depth plan, silence protection, negative-space validation, eye-rest preservation, flow validation, rationale, validation, and provenance.

The engine responds to composition family without collapsing every family into one crescent template. A broken crescent preserves interruption, a sweeping arc supports longer extensions, an offset cluster concentrates mass, and full-with-interruption allows broader coverage while still protecting silence.

The output is material-agnostic. No species, SKU, stem count, inventory query, blueprint compilation, ECR, prompt, render, or legacy write path exists in the service.

## References

[1]: ../client/src/data/greenery.ts "MoodoorGreeneryArchitectureService and validator"
[2]: ../client/src/data/vnext.ts "GreeneryArchitectureRecord contract"
[3]: ../client/src/data/greenery.test.ts "Sprint 5 architecture fixtures"

[1] [2] [3]
