# Moodoor Sprint 15 Findings

## Mission

Sprint 15 introduces **Collection Curator**, an analytical layer that discovers families already latent in the canonical Library. It differs from Sprint 14 Collection Creator: Curator does not invent new wreaths or redesign existing work. It proposes explainable membership relationships for human review.

## Canonical boundaries

Curator reads native vNext designs and any structured evidence already present: Essence, effective EVS, territory, composition, botanical selection, Blueprint, render/QC state, story, season, and status. Existing designs are never silently mutated. Legacy evidence remains read-only and is not promoted into canonical records by Curator. Image-only or incomplete records receive reduced confidence rather than invented Blueprint, ECR, Essence, or EVS fields.

Curation candidates are persisted separately under `moodoor.vnext.curation_candidates`. They are analytical records, not competing collections. Saving an accepted candidate calls the Sprint 14 Collection model and records curation provenance on the candidate and canonical collection.

## Curation profiles and effective EVS

`MoodoorCurationProfile` normalizes each eligible design into emotional, EVS, territory, palette, material, composition, movement, silhouette, negative-space, story, seasonal, and data-confidence fields. Effective EVS uses observed EVS when valid and otherwise predicted EVS. Predicted and observed vectors remain preserved independently in the source design.

The profile explicitly records available and missing evidence. A high-confidence profile contains most canonical stages; a limited profile can still be manually reviewed but cannot create false certainty.

## Relationship model

Curator compares multiple dimensions rather than color or season alone. Pairwise relationships are classified as `KINSHIP`, `COMPLEMENT`, `CONTRAST`, `ECHO`, `BRIDGE`, or `OUTLIER`. Each relationship includes human-readable evidence, conflicts, confidence, and explanation. Shared palette or season can support a relationship, but neither can independently establish collection membership.

The candidate model tracks coherence and differentiation separately. Coherence considers emotional territory, material language, movement, and related evidence. Differentiation considers composition families, focal diversity, density variation, and silhouette/movement variation. Clone-like groups are marked `NEEDS_EDITING` rather than recommended as strong collections, and unrelated but individually strong designs are not forced together.

## Discovery modes

The creator-facing Curator supports four entry points: exploring the whole canonical Library, curating selected designs, building around one anchor design, and completing an existing Sprint 14 Collection. The service also supports human review actions, including keep, remove, lock, add, recurate, missing-role suggestion, replacement suggestion, and save-as-collection.

Proposed removals do not archive or delete designs. A `KEEP_ANYWAY` or locked decision remains authoritative across recuration. A saved candidate becomes a canonical Sprint 14 Collection in `REVIEW`; it does not automatically approve or generate new designs.

## Creator experience

Curator is exposed beneath Collections at `/studio/collections/curator`. The default experience presents four simple discovery choices, proposed collection cards, a visual review board, member roles, relationship explanations, and a gap panel titled **What This Collection Is Missing**. Technical profiles, pairwise evidence, confidence, and provenance remain in Advanced Inspector.

Collection Creator remains the handoff for missing design gaps. Sprint 15 may describe a desired Quiet, Resolution, Contrast, or Bridge design, but does not execute new design creation automatically.

## Completion boundary

Sprint 15 stops at relationship discovery, candidate review, and canonical Collection save. It does not begin Campaign Studio, lookbooks, lifestyle scenes, launch planning, production, public publishing, customer-memory matching, reverse-render reconstruction, legacy migration, or final humanization.

## Verification target

Sprint 15 verification covers non-mutation, effective EVS semantics, season and color traps, multiple candidate discovery, incomplete-data confidence, manual keep/remove/lock, save-as-collection, and canonical-only persistence. The complete project verification must include TypeScript, all Vitest suites, production build, browser route checks, and visual review of Curator entry and review surfaces.
