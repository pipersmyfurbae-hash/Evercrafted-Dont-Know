# Moodoor Sprint 21 Findings

## Mission and boundary

Sprint 21 introduces the first customer-facing use of Moodoor's emotional intelligence. A visitor can describe a memory, feeling, place, season, person, ritual, or fragment in ordinary language. Moodoor interprets what matters emotionally and compares that private session profile against a small pool of approved and published public Design entries.

Customer Memory is private by default. It is stored only in the isolated `moodoor.vnext.memory_matches` session store, is marked with the `PRIVATE_CUSTOMER_MEMORY` provenance boundary, and is deleted when the visitor chooses Start over or Delete this session. It does not become a public Story, Design Story, marketing copy, training content, public profile, Collection, or permanent customer identity.

The public interface never exposes EVS scores, territories, vectors, confidence math, Blueprint, ECR, qualification, or engine terminology. Explanations use ordinary language such as warmth, quiet, botanical detail, familiarity, and atmosphere.

## Canonical record and service

`MoodoorMemoryMatchSession` uses the versioned `MOODOOR_MEMORY_MATCH_V1` schema. It records the memory input, safe interpretation, internal matching profile, eligible candidate IDs, public-safe match results, no-match outcome, customer preferences, revision, and privacy provenance. The service supports session creation, interpretation, deterministic matching, preference refinement, restart, and custom-design handoff.

The interpretation boundary reuses the existing Moodoor emotional vocabulary without creating a second public emotional model. It produces emotional center, tension, atmosphere, sensory, temporal, place, material, color, movement, warmth, restraint, familiarity, signals, and explicit avoids. Matching remains deterministic where the canonical public snapshot provides structured evidence.

## Eligibility and matching behavior

Only public entries whose content type is `DESIGN` and whose publication status is `PUBLISHED` enter the candidate pool. Drafts, previews, unpublished, stale, archived, legacy-only, and private designs are excluded. Emotional alignment and availability are kept separate: an emotionally meaningful design can still be sold out, made to order, or available by request.

Candidate ranking is anti-literalized. Signals such as warmth, nostalgia, winter, quiet, ritual, botanical character, threshold structure, and contrast contribute to a broader score across public-safe title, summary, story, territory, foundation, and essence evidence. Explicit customer exclusions, including natural phrasing such as “I do not want it to feel Christmasy,” remove contradicted candidates rather than merely lowering them.

The public result set is limited to three meaningful matches. Match explanations state why a design belongs and what feeling it carries forward, without exposing numerical scores. If no candidate reaches the configurable meaningful threshold, the service returns `NO_MATCH` with the honest message that Moodoor does not have a design that carries the memory closely enough yet, followed by a Start a custom design handoff.

## Customer experience

The public entry is available at `/find-your-wreath` and is linked from the public navigation and home hero. The first screen is intentionally simple: one large natural-language field, optional example memories, privacy copy, and a single listening action. After interpretation, the visitor can refine lightly with warmer, cooler, quieter, more restrained, more botanical, or more unexpected preferences.

Results distinguish private memory from public design content. Each match includes the design name, summary, availability label, why it belongs, and a link to the already-published public Design page. The no-match state remains calm and honest rather than filling the page with weak recommendations.

## Verification

Sprint 21 verification includes TypeScript, the full Vitest suite, production build, and visual review of the public home and Find Your Wreath entry. The suite contains 21 test files and 108 passing tests. Coverage includes private-session separation, published-only eligibility, deterministic ranking, explanation safety, hard exclusions, honest no-match handling, restart deletion, and public-content preservation. Existing non-blocking asset-resolution and bundle-size build notices remain unchanged.
