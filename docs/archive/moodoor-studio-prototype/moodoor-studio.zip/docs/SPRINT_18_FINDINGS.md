# Sprint 18 Findings — Launch Planner & Experience Orchestration

Sprint 18 adds a canonical `MOODOOR_LAUNCH_V1` planning layer over approved Campaign Packages. The Launch Planner proposes what happens next, in what order, through which supported or exportable channel, while keeping Campaign, Design, Collection, Blueprint, ECR, and Scene records authoritative.

## Creator Workflow

The creator path is **Campaigns → Launch Planner → Create Launch → Proposed Rollout → Timeline → Assets → Copy → Readiness → Approval → Export**. The primary action creates a plan from an approved Campaign and its valid Campaign Package. Advanced Inspector exposes the complete structured record.

## Strategy and Arc

The planner supports Quiet Release, Editorial Drop, Collection Reveal, Story First, Product First, Limited Release, and Evergreen Introduction. Each strategy derives a bounded sequence from Signal, Discovery, Deepening, Reveal, Consideration, Last Look, and Settle. Timing is relative by default so the system never invents dates.

## Truth Boundaries

The planner does not reserve stock, decrement inventory, create orders, schedule posts, publish pages, create calendar events, or claim connected channel capabilities. Scarcity is disabled unless a supported limited-release mode and creator-provided evidence are present. Availability, capacity, and release dates remain explicit unknowns until confirmed.

## Review and Lifecycle

Plan readiness is distinct from release readiness. Human review can adjust moments, lock a moment, regenerate an unlocked moment, revalidate against the source Campaign, approve the Launch Plan, or mark it stale after upstream changes. Export produces structured JSON; it does not publish.

## Verification

Sprint 18 verification passed TypeScript, 18 test files / 95 tests, and the production build. The Launch Planner creator entry and setup views were visually checked at desktop width. Legacy data remains read-only.
