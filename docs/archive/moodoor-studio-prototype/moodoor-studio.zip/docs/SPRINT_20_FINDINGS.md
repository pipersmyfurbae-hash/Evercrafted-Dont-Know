# Moodoor Sprint 20 Findings

## Public boundary

Sprint 20 introduces the public Moodoor publishing layer. It consumes approved canonical records and creates separate `MOODOOR_PUBLIC_ENTRY_V1` snapshots. Public pages do not expose EVS, ECR, Blueprint, orchestration, inventory resolution, QC, production, campaign inspection, or raw private Memory.

The public layer supports five content types: Design, Collection, Story, Lookbook, and Campaign. Journal, About, and Memory Match remain architectural placeholders only. Checkout, payment processing, customer accounts, reverse-render reconstruction, legacy migration, and the final humanization pass remain outside this sprint.

## Canonical public records

`MoodoorPublicEntry` is stored under the isolated `moodoor.vnext.public_entries` key. Each record preserves its content type, source ID, source revision, public slug, canonical path, public-safe content snapshot, SEO metadata, commerce facts where canonical, publication status, memory publication mode, redirect history, and provenance. Source records are never rewritten to fit public templates.

The publishing service provides preview creation, readiness validation, publish, unpublish, republish, stale marking, slug collision handling, canonical path resolution, and dedicated public-entry lookup. Publishing is always explicit; approval of a backstage source does not auto-publish it.

## Safety and privacy semantics

A Design source must be approved and its Blueprint must be approved before it may publish. Design imagery enters the public package only when it carries an approved QC `PASS`; absent imagery remains a readiness warning and cannot be silently released. Source failures block publishing. Memory publication defaults to `DO_NOT_PUBLISH`, with explicit `EDITED_EXCERPT` and `FULL_APPROVED_MEMORY` modes available on the preview form.

Slug collisions receive deterministic numeric suffixes rather than overwriting an existing public entry. A published source revision is preserved in the entry snapshot. Source changes can be marked `STALE`, requiring review before a new snapshot is republished.

## Customer experience

The public layer has a separate shell from Studio with public navigation for Wreaths, Collections, Stories, Lookbooks, and How Moodoor Works. Public templates include the Home, index/catalog, content detail, method, and publishing-review surfaces. Public pages show editorial product and story content only; creator publishing controls stay under `/studio/publishing`.

Public empty states are evidence states rather than generic placeholders. They identify absence, publication state, approval boundary, and protected source status. Public headers retain a compact field-note index showing record count, approved-snapshot source, and read-only boundary without exposing internal engineering vocabulary.

## Verification

Sprint 20 verification includes TypeScript, the complete Vitest suite, and the production build. The current suite contains 20 test files and 103 passing tests. Build output completes successfully; the existing asset-resolution and bundle-size notices remain non-blocking. The public and Studio shells were visually reviewed at desktop width, with the accepted revision adding field-note metadata, semantic empty states, and stronger evidence grammar to the public pages.
