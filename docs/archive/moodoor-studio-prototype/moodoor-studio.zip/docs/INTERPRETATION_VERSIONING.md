# Interpretation Versioning

Interpretation lifecycle is separate from MoodoorDesign status. A native design may remain `DRAFT` while its interpretation is `NOT_STARTED`, `GENERATED`, `REVIEWED`, or `APPROVED`.

| Action | Result |
|---|---|
| Interpret memory | Creates a generated interpretation revision, updates native Essence and predicted EVS, and marks downstream state stale. |
| Regenerate | Creates a candidate revision without silently replacing the current interpretation. |
| Review | Marks a candidate `REVIEWED` for operator comparison. |
| Approve Essence | Freezes the selected interpretation revision and records approval time. |
| Edit after approval | Must create a new interpretation revision in a future reviewed workflow; downstream derived decisions are represented by the existing `downstream_stale` flag. |

Every interpretation records its ID, revision, generated and approved timestamps, source memory revision, model/provider, prompt version, and raw response evidence. The canonical structured interpretation is always used for UI and computation; raw response content is debugging provenance only.

## Current UI

The native Essence tab shows Memory, interpreted Essence, emotional center, tension, predicted EVS, territory, design intent, candidates, and review actions. Legacy details remain read-only and never expose interpretation writes.

## References

[1]: ../client/src/data/essence.ts "Interpretation lifecycle service"
[2]: ../client/src/data/vnext.ts "Persisted interpretation metadata"
[3]: ../client/src/pages/DesignDetail.tsx "Essence review UI"

[1] [2] [3]
