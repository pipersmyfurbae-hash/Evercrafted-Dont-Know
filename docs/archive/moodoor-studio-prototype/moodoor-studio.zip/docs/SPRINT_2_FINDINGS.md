# Moodoor Sprint 2 Findings

## Summary

Sprint 2 adds a controlled canonical write layer to Moodoor Studio while preserving the Sprint 1 boundary. New native designs are persisted in `moodoor.vnext.designs`; legacy records continue to be read through adapters and remain read-only.

## Implemented stores and schema

The `VNextDesign` contract is implemented with structured identity, origin, memory, Essence, predicted and observed EVS, effective EVS, design relationships, commerce, production, publishing, legacy aliases, raw legacy provenance, timestamps, revision, and status. The repository also reserves the schema-version and identity-map namespaces and writes immutable activity entries to `moodoor.vnext.activity`.

## Stable IDs and lifecycle

`MoodoorIdService` creates deterministic sequence IDs such as `MD-000001`. IDs are generated once and remain stable through edit, archive, restore, and unified-library reads. `MoodoorStatusService` enforces the Sprint 2 state boundary: DRAFT can become DESIGNED or ARCHIVED, DESIGNED can become DRAFT or ARCHIVED, and ARCHIVED can become DRAFT. Hard delete is not implemented.

## Create and edit flows

`/studio/create` supports memory, idea, blank, and explicit legacy-fork entry points. It requires a working name and stores Memory and Essence separately. Native vNext detail pages make Overview and Essence editable, increment revision, update timestamps, and log activity. Design, Render, Story, Collections, Commerce, and later pipeline states remain read-only or placeholders.

## Legacy fork

Legacy detail pages now provide an explicit `Create editable vNext draft` action. The fork copies only documented safe fields, records the origin and alias, preserves raw evidence, creates a new canonical ID, and leaves the source record untouched.

## Unified Library

The Library service now returns legacy compatibility views and native vNext views through one interface. Every result exposes `sourceKind` as `legacy` or `vnext`. Library filters include All, vNext, Legacy, Draft, Designed, Archived, and the existing identity-health filters. Native records are visibly marked `VNEXT / <STATUS>`; legacy records remain `LEGACY / READ ONLY`.

## Archive, restore, and history

Archive changes status to ARCHIVED and retains the record. Restore changes it back to DRAFT and preserves the same canonical ID. Both actions increment revision and append immutable activity records. The History tab is available for native records.

## Tests and validation

The vNext regression suite contains four passing tests covering stable ID creation, vNext-only writes, targeted edits, revision/activity behavior, archive/restore retention, and invalid transition rejection. `pnpm check` passes with zero TypeScript errors. `pnpm build` passes. Representative Create, Library, and Data Health screenshots were captured successfully.

## Safety verification

No legacy localStorage namespace is written by the new repository. Legacy HTML pages, prompts, public routes, render flows, Story flows, Collections, Orders, Campaigns, and Production workflows remain outside the Sprint 2 implementation. Fixture mode remains explicit, and the new write path is isolated to vNext keys.

## Known limitations

The current browser session starts with an empty vNext store, so the visual Library initially shows legacy fixtures until the operator creates a draft. There is no real-store adapter or authentication yet. `moodoor.vnext.identity_map` is reserved but not populated. The project still emits a non-blocking chunk-size warning and a runtime asset URL warning for the paper texture. No downstream interpretation, rendering, ECR, QC, collection, campaign, production, or public-site work was started.

## Sprint 3 recommendation

The next safe increment is to add a controlled real-store read adapter and explicit live/fixture source switch with cloned exports and tests. After that, review whether a separate Memory-to-Essence interpretation workflow should be introduced. Do not begin render intake, blueprint generation, QC, collections, campaigns, production, or public refactoring until the write boundary is reviewed.

## References

[1]: SPRINT_2_WRITE_ARCHITECTURE.md "Sprint 2 write architecture"
[2]: VNEXT_STORE_CONTRACT.md "vNext store contract"
[3]: VNEXT_STATUS_MODEL.md "vNext status model"
[4]: LEGACY_FORK_BEHAVIOR.md "Legacy fork behavior"
[5]: ../client/src/data/vnext.test.ts "Sprint 2 regression tests"

[1] [2] [3] [4] [5]
