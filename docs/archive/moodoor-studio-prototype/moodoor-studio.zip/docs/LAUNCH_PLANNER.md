# Sprint 18 Launch Planner

Moodoor Launch Planner turns an approved Campaign Package into a deliberate rollout sequence. It reuses Campaign story, scenes, copy direction, and product references without duplicating or mutating them.

The creator path is Campaign → Create Launch → Review Timeline → Adjust Moments → Check Readiness → Approve Launch Plan → Export. The plan is not a scheduler and does not claim to post to external channels.

Launch edits are scoped to sequence, timing, assignment, channel, CTA, and launch-specific copy. Campaign, Design, Collection, Blueprint, and ECR remain authoritative source records.

## Readiness

Plan readiness and release readiness are separate. A plan can be approved as a coherent sequence while assets, commerce facts, or future publication targets still require attention.

## Boundary

Sprint 18 does not reserve stock, decrement inventory, create orders, schedule external posts, publish pages, create calendar events, or invent scarcity.
