# Moodoor Sprint 14 Findings

## Mission

Sprint 14 introduces the **Collection Creator Engine**. It turns one memory, an approved design, an Essence, or a collection concept into a coordinated family of distinct designs. The governing rule is **shared Essence, distinct expressions**.

## Canonical boundary

Collections are stored as native `MoodoorCollectionRecord` entities under `moodoor.vnext.collections`. Existing legacy collection adapters and legacy keys remain read-only and are never written by Collection Creator. Individual generated designs continue to use the existing canonical vNext design repository and reference their collection through `collection_ids` and lightweight collection membership records.

The collection record contains a separate Collection Essence, emotional arc, palette system, material language, movement and silhouette vocabulary, negative-space philosophy, configurable design slots, hero designation, collection story, aggregate render status, validation scorecards, inventory forecast, revision, lifecycle, and provenance. Collection Essence is distinct from each design’s individual Essence.

## Orchestration

`MoodoorCollectionCreatorService` reuses `MoodoorDesignOrchestrator` for each slot. The creator-facing operation is **Generate Collection**, not a sequence of engine approvals for every member. The service develops the collection world, creates differentiated design slots, invokes the existing deterministic pipeline for each slot, links resulting designs back to the collection, computes validation, and leaves the collection in review.

The service supports Essence derivation, architecture and direction generation, slot creation, per-slot regeneration, replacement, locks, collection approval, validation, and stale propagation. Locked members are not replaced by regeneration. A material or Essence change can mark members `NEEDS_REVIEW` without deleting completed designs.

## Differentiation and coherence

Validation measures composition, focal, silhouette, palette, material, and density variation, while separately evaluating Essence, territory, palette, material, and movement coherence. Excessive repeated signatures produce a blocking clone failure. Missing slot population produces a review warning. The model leaves room for future stronger family-fit and random-assortment detectors without collapsing the two dimensions into one opaque score.

The collection palette and material systems support shared foundations, differentiated emphasis, signature materials, family budgets, movement language, and negative-space language. Inventory is represented as forecast-only collection metadata; no reservation or decrement is performed.

## Creator experience

The active Collections rail item now opens `/studio/collections`. The creator path consists of a simple Collection Create screen, a Collection World view, a Collection Board with design cards, and a secondary Advanced view containing technical evidence. Human-readable actions include **Create Collection**, **Generate Collection**, **Keep/lock a design**, **Replace Design**, and **Approve Collection**. Internal ECR, EVS, qualification, and pipeline details remain out of the default board cards.

## Deterministic upstream repair

Sprint 14 exposed a latent self-reference in the existing greenery architecture candidate seed. The focal variation now computes a candidate center before checking recent candidates. Eye-rest preservation now reflects explicit approved composition and negative-space inputs rather than rejecting valid designs solely because focal and eye-rest centers are close. Existing greenery regression tests remain passing.

## Verification

TypeScript checking, production build, and 14 Vitest suites pass with 79 tests. The new collection suite covers memory generation, five differentiated slots, locked Hero preservation, clone blocking, legacy write safety, and stale propagation.

## Completion boundary

Sprint 14 stops at Collection Creator. It does not begin Collection Curator, Campaign Studio, lookbook generation, lifestyle scenes, launch planning, production reservation, public publishing, customer-memory matching, reverse-render reconstruction, legacy migration, or final humanization.
