# Moodoor Studio — Sprint 12 Findings

## Outcome

Sprint 12 adds the bridge from approved ECR scene truth to a renderer-specific package and provenance-rich render result. The architecture is intentionally split into `APPROVED ECR → Render Bridge → Renderer Adapter → Render Package → Renderer Transport → Render Result → Moodoor Render Record`.

The implementation uses `moodoor.reference.mock` as the single reference adapter because no live image-renderer credential or provider is configured in the project environment. The mock adapter is an honest transport boundary: it validates and normalizes the package, returns an unavailable submission state, and never fabricates an image URI or successful external render.

## Input gate

Rendering is blocked unless Blueprint status is `APPROVED`, ECR status is `APPROVED`, ECR validation is `PASS`, and the Blueprint-to-ECR diff contains no `ERROR`. Stale ECRs therefore cannot silently enter the bridge. The gate is centralized in `MoodoorRenderBridge` and applies to preparation, package creation, submission, and retry.

## Render Package contract

`RenderPackageRecord` is renderer-specific and is not canonical design truth. It includes the render package identity, renderer and adapter versions, ECR source identity and revision, an inspectable structured design contract, asset context, structured prompt payload sections, negative constraints, reference assets, renderer parameters, a separate controlled presentation profile, validation, attempt number, status, and provenance.

| Package section | Purpose | Authority |
|---|---|---|
| `design_contract` | Preserve canvas, foundation, objects, relationships, silence, negative space, and render constraints | ECR |
| `asset_context` | Carry approved SKU, family, and foundation references | ECR / Inventory-derived ECR objects |
| `prompt_payload` | Translate structured sections into renderer-compatible language with traceability | Adapter, constrained by ECR |
| `negative_constraints` | Strong renderer-facing prohibitions derived from structured constraints | ECR constraints |
| `presentation` | Controlled inspection camera, lighting, crop, and background | Render presentation profile |
| `renderer_parameters` | Renderer-specific transport settings | Adapter |

The adapter may translate ECR into renderer-compatible language, but it may not move the focal, fill silence, change families or palette, add unspecified botanicals, flatten depth, remove foundation visibility, or redesign the wreath.

## Presentation profile

The first reference profile is `studio_product`: near-frontal camera, neutral background, soft editorial studio lighting, full-wreath crop, one-to-one aspect ratio, and design-inspection priority. This profile is explicitly outside ECR geometry so photographic presentation cannot mutate canonical design truth.

## Result intake and QC boundary

Render result intake records submission identity, adapter provenance, source ECR identity and revision, result status, image URI when available, raw adapter output, and `qc_status: NOT_STARTED`. Sprint 12 does not judge whether the image emotionally or geometrically succeeded. That comparison is reserved for Sprint 13.

## UI

The Render Bridge inspector is available at `/studio/library/:canonicalId/render`. It exposes input gates, presentation profile, structured design-contract counts, renderer constraints, transport/result state, provenance, and the explicit QC deferral. The page is read-only and does not alter ECR geometry.

## Regression coverage

Sprint 12 adds four focused tests for missing approval gates, package fidelity without ECR mutation, honest mock submission and result normalization, and stale package/result propagation. The full project suite now passes 69 tests across 11 test files, with TypeScript and production build checks passing.

## Explicit exclusions

No external render success is claimed. No renderer-specific prompt logic is placed inside ECR. No species substitution, geometry redesign, image QC, emotional comparison, inventory mutation, or legacy write-back is introduced.
