# Design Intent Contract

`design_intent` is the bridge into a future design-engine sprint. It describes emotional visual behavior without choosing actual materials or geometry.

| Field | Controlled values used in Sprint 3 |
|---|---|
| `presence` | quiet, present |
| `movement` | slow, ascending, lively |
| `density` | restrained, balanced |
| `restraint` | high, moderate |
| `negative_space` | significant, measured |
| `visual_tension` | derived emotional tension string |
| `directionality` | ascending, outward |
| `hierarchy` | single-dominant, layered |
| `rhythm` | measured, repeating with interruption |

No field assigns clock positions, stem counts, flowers, greenery pockets, blueprint points, ECR data, or render composition. The intent is inspectable and suitable as an input contract for Sprint 4, but it is not an instruction to execute a design.

## North Star checks

`heard_check` records whether concrete memory cues were retained. `unexpected_check` records whether the interpretation avoids literal reproduction while preserving emotional truth. Unexpected does not mean random novelty.

## References

[1]: ../client/src/data/essence.ts "Design intent and North Star derivation"
[2]: ../client/src/pages/DesignDetail.tsx "Design intent review UI"

[1] [2]
