# Floral Role Taxonomy

| Role | Compositional job |
|---|---|
| `PRIMARY_FOCAL` | One dominant emotional event |
| `SECONDARY_FOCAL` | Subordinate support, echo, counterbalance, or continuation |
| `SUPPORTING_FLORAL` | Nest, frame, soften, extend, separate, or repeat |
| `BRIDGE` | Relate two separated design events without erasing space |
| `ACCENT` | Small visual punctuation |
| `TEXTURAL_ACCENT` | Surface/form contrast without major direction |
| `DIRECTIONAL_ACCENT` | Reinforce flow or an extension |
| `ECHO` | Recall a major event without becoming a miniature duplicate |
| `TRANSITION` | Manage density, scale, depth, or focal-to-silence changes |

Roles carry abstract form requirements such as mass, cup, disc, spire, spray, branch, cluster, line, orb, trailing, or airy. They also carry relative scale classes and quantity intentions. These describe the job, not a species or exact count.

The hierarchy is explicit: a floral design with intended floral presence has one primary focal role. Secondary focal, supporting, bridge, and accent roles remain subordinate unless an approved composition justifies intentional duality.

## References

[1]: ../client/src/data/vnext.ts "Floral role taxonomy fields"
[2]: ../client/src/data/orchestration.ts "Role shaping and hierarchy"

[1] [2]
