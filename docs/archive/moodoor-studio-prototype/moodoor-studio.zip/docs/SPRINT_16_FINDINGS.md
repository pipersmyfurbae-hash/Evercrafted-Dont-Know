# Sprint 16 Findings — Story & Campaign Studio

## Outcome

Sprint 16 adds a native `MOODOOR_CAMPAIGN_V1` layer above approved Design, Collection, and curated Collection records. Campaign Studio defines the world the approved product already belongs to. It does not generate lifestyle imagery, render lookbooks, or replace the Render Package.

## Narrative hierarchy

Memory remains what was remembered. Essence remains the emotional interpretation. Design Story explains why one design exists. Collection Story explains why several designs belong together. Campaign Story invites another person into the world. Product Copy communicates factual and commercial information. These layers are stored separately and are presented separately in the creator UI.

## Source and safety boundaries

Campaign creation requires an approved Design, approved Blueprint/ECR, approved Collection, or reviewed saved collection. Source Design, Essence, botanical selection, Blueprint, ECR, Render, QC, Memory, and Collection records are never mutated. Campaign provenance stores source identifiers and revisions. Material source changes can mark a campaign `NEEDS_REVIEW` without deletion.

## Story World

The Story World stores emotional center, emotional tension, territory, place character, seasonal and time-of-day character, light, weather, materials, surfaces, sound and scent cues, temperature, objects, architecture, human traces, movement, stillness, sensory contrasts, source memory, creative interpretation, and anti-literalization guidance. A place or holiday signal is interpreted through material, threshold, light, and atmosphere rather than copied into literal landmarks or seasonal prop shorthand.

## Narrative and visual direction

Narrative Architecture defines the smallest meaningful sequence for Mini, Core, or Editorial campaigns. Stages have an emotional job and a beat. Reveal strategy and controlled human presence are explicit. Visual Direction separates photographic character, camera language, depth of field, lighting progression, environment palette, material world, architecture, human presence, texture, and avoid rules. Product palette and campaign environment palette remain distinct.

## Scene Architecture and handoff

Scene cards define scene type, narrative role, emotional job, product role, environment, visual direction, continuity requirements, avoid rules, and product identity references. Product scenes carry design ID, Blueprint revision, ECR revision, and approved render reference when available. Scene cards are a storyboard direction only. The Campaign Package is the structured handoff for Sprint 17 and is separate from the renderer-specific Render Package.

## Copy direction

Campaign Copy includes direction, headline and subhead candidates, campaign narrative, product stories, product-copy candidates, social directions, email directions, and future site blocks. Generic luxury filler is explicitly listed as avoid language. Commerce facts are not invented by poetic copy.

## Validation and review

Campaign validation checks Essence alignment, narrative progression, visual material language, product identity locks, copy separation, memory-fidelity risk, and continuity. Blocking product mutations prevent approval. Unsupported autobiographical claims produce review. Human review remains authoritative; `HEARD` and `UNEXPECTED` are internal checks and can remain unresolved until review.

## Sprint 17 boundary

Sprint 16 stops after Campaign Package approval. Lifestyle scene generation, lookbook layout, launch scheduling, production, public publishing, customer memory matching, existing-render reconstruction, legacy migration, and final humanization are deferred.

## Verification

Sprint 16 adds single-design and collection campaign tests covering source non-mutation, narrative separation, product identity references, collection scenes, approval/package gating, and stale lifecycle. TypeScript and production build pass. Existing legacy storage remains read-only.
