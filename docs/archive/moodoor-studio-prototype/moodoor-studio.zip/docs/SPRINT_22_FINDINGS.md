# Moodoor Sprint 22 Findings

## Mission and boundary

Sprint 22 adds a reverse path for existing rendered wreath images and photographs that do not yet have a canonical Moodoor Blueprint, ECR, Story, inventory mapping, or product record. The creator workflow is Upload Render, Review What Moodoor Found, Correct Anything Wrong, and Create Design Record.

The governing boundary is explicit: Moodoor may infer from an image, but it must never present image inference as original design truth. Reverse intake is isolated from legacy records and does not silently canonize an image, invent an original prompt, recover hidden geometry, claim exact stems, resolve exact SKUs, or infer a personal memory that was never declared.

## Canonical record

`MoodoorRenderIntake` uses `MOODOOR_RENDER_INTAKE_V1` under the isolated `moodoor.vnext.render_intakes` key. It preserves source image reference, original filename, imported time, declared source type, optional creator context, observations, reconstruction profile, reconstructed Blueprint candidate, confidence, unresolved unknowns, human edits, sellability review, created Design ID, revision, and provenance history.

Each reconstructed field is represented by a value, evidence type, confidence, reason, and optional history. Evidence types remain separate: `OBSERVED`, `INFERRED`, `DECLARED`, `UNKNOWN`, and `HUMAN_CONFIRMED`. Creator-provided context is never collapsed into image observation. Human confirmation preserves the previous inference in field history.

## Analysis and reconstruction behavior

The bounded render-analysis service uses visible-evidence language and conservative intake metadata. It distinguishes wreath/product evidence from background assumptions, supports `CLEAR`, `PARTIAL`, `AMBIGUOUS`, and `NOT_FOUND` detection states, and refuses approval when a reconstruction has not been reviewed or when no wreath is found.

The reconstruction profile includes identity, composition, greenery architecture, floral roles, botanical families, controlled palette, observed emotional semantics, territory, essence candidate, story signals, confidence, and unresolved unknowns. It describes what the object currently conveys rather than inventing a personal origin story.

The Blueprint candidate is explicitly `MOODOOR_BP_RECONSTRUCTED_V1` with product type `CONCEPT_BLUEPRINT`. It uses approximate focal language, visible-count uncertainty, unresolved foundation and hidden insertion paths, and SKU candidates that remain human-confirmation-required. It is never mislabeled as the original canonical Blueprint and never promoted to physical-production readiness silently.

## Sellability and handoff

Sellability is separate from image aesthetics and separate from physical production readiness. The current service returns `RECONSTRUCTABLE` or `NOT_ENOUGH_EVIDENCE` with reasons, while `physical_production_ready` remains false. A creator may approve the reconstruction only after review, then create a native vNext Design whose origin is `render_intake` and whose render evidence retains the source image reference. The resulting Design remains a draft and does not write to legacy data.

## Creator experience

The new Studio route is `/studio/reverse-intake`. The entry surface asks for an image reference, original filename, and declared source type. The review surface shows wreath detection, evidence-tagged fields, reconstruction Blueprint status, unresolved unknowns, approval/rejection actions, and the final Create Design from render handoff. Technical details remain secondary to the creator workflow, while the Studio rail and archive readouts preserve the Botanical Instrument Panel language.

## Verification

Sprint 22 verification includes TypeScript, the complete Vitest suite, and the production build. The suite contains 22 test files and 112 passing tests. Coverage includes source provenance, declared context, conservative not-found handling, concept-only Blueprint creation, approval gating, render-intake Design origin, human-confirmed field history, and legacy/public safety. Visual review covered the reverse-intake entry and Studio home; accepted amendments strengthened instrument strips, provenance readouts, and clay-red unresolved-state treatment. Existing non-blocking asset-resolution and bundle-size notices remain unchanged.
