# Botanical Characteristic Taxonomy

Qualifications use controlled characteristics rather than botanical names. Form classes include mass, cup, disc, orb, spire, spray, branch, line, cluster, trailing, airy, and spike. Relative visible scale uses hero, large, medium, small, micro, and ranges such as `large_to_hero`.

Additional dimensions include silhouette, structural substance, surface appearance, faux-botanical read, visual density, nesting ability, edge behavior, stem behavior, orientation capability, movement character, texture complexity, color behavior, temperature, saturation, and texture-contrast role. Color is expressed only as behavior such as tonal, bridge tone, quiet dominant, or accent contrast.

Exact colors, measurements, species, and quantities are outside this taxonomy.
