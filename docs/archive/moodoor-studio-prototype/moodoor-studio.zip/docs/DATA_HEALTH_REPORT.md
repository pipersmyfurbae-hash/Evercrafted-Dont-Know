# Data Health Report

## Fixture-mode snapshot

| Metric | Value |
|---|---:|
| LibraryItems | 3 |
| Catalog records | 3 |
| Stories | 3 |
| Renders | 3 |
| Collections | 2 |
| Orders | 1 constructor fixture |
| Exact identity matches | 3 |
| Resolved aliases | 5 |
| Ambiguous records | 0 |
| Orphan relationships | 2 |
| Missing render payloads | 2 |
| Missing stories | 1 |
| Broken collection membership | 0 |

The numbers are derived from the explicit Sprint 0.75 development fixtures. They are not a claim about live browser localStorage.

## Findings

The normalized service keeps three canonical LibraryItems visible and retains source aliases. Two render references have no binary payload in the snapshot, so the UI shows missing payload status rather than inventing an image. Two source relationships are orphaned because the fixture intentionally includes records without a resolvable `library_item_id`. No fuzzy merge occurs, and ambiguity remains a visible status if future data produces competing candidates.

## Unresolved dependencies

`image-slot.js`, Prompt Library HTML, the bundled pipeline, and standalone Stories Studio are documented but intentionally not imported. They remain later-module dependencies only.

## References

[1]: ../client/src/data/service.ts "Health summary implementation"
[2]: ../client/src/pages/DataHealth.tsx "Diagnostic view"
[3]: ../client/src/data/fixtures "Fixture sources"

[1] [2] [3]
