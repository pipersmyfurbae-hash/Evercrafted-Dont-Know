# Campaign Studio

Campaign Studio turns an approved Design, approved Collection, or saved curated Collection into a structured campaign world. The creator-facing path is **Design or Collection → Create Campaign → Story World → Campaign Direction → Review/Refine → Approve Campaign**.

The primary workflow shows world, story, scenes, and copy as understandable views. Technical schema, provenance, continuity, validation, and package data remain behind Advanced Inspector. Campaign interpretation never overwrites source Memory, Essence, Design Story, Collection Story, Blueprint, ECR, botanical selection, geometry, render, or QC.

Campaign Studio ends at an approved Campaign Package. It does not generate lifestyle scenes, render a lookbook, schedule launches, publish publicly, perform production, match customer memories, reconstruct existing renders, migrate legacy data, or perform final humanization. Those boundaries are explicitly deferred to later sprints.

Campaigns use the canonical `moodoor.vnext.campaigns` namespace and `MOODOOR_CAMPAIGN_V1` schema. Source revisions and meaningful campaign revisions remain in provenance so material source changes can mark a campaign `NEEDS_REVIEW` without deleting it.
