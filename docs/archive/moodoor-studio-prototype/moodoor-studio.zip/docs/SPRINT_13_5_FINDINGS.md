# Moodoor Sprint 13.5 Findings

## Mission

Sprint 13.5 adds a creator-facing orchestration layer over the authoritative deterministic engines from Sprints 1–13. The normal path is now **Create → Design → Visualize → Refine → Finish**. Internal engine names and approval mechanics remain available through the existing technical Design Inspector, but they are no longer required for normal creator operation.

## Orchestration boundary

`MoodoorDesignOrchestrator` runs eligible stages in dependency order: memory, Essence, composition, greenery structure, flower structure, botanical qualification, materials, Blueprint, ECR, and Render Package. It invokes the existing services rather than replacing them with a monolithic AI call. Each automatic transition retains the internal approved record and provenance. A missing memory is the only creator-facing input block in the current deterministic flow; engine exceptions are surfaced as a single readable message.

The orchestrator stops at a **render-ready** state rather than claiming an image exists. The reference renderer remains intentionally unavailable, so the validated Render Package is the terminal automatic state until a real adapter is connected.

## Creator-facing surfaces

The new creator route is `/studio/design/:canonicalId/:view`, with `design`, `visualize`, `refine`, and `finish` views. Create now asks only for memory, optional working name, wreath size, season, and constraints. Its single primary action creates a vNext record and runs the orchestrator.

The Visualize view exposes **Render Design**, **Copy Render Prompt**, **Download Render Package**, **Upload Existing Render**, and **Render Again**. The render prompt is a derived presentation prompt from approved ECR geometry and constraints; it does not replace the structured ECR. The Refine view links to the existing technical inspector. Finish consolidates story, Blueprint, material counts, and readiness.

## Safety and fidelity

New records and generated creator stories are written only to the canonical vNext store. Legacy records remain read-only. The orchestrator does not create new design intelligence or reinterpret approved geometry. The current reference adapter still reports unavailable rendering honestly.

## Verification

The automated one-memory scenario creates a canonical design, runs all authoritative stages without manual approval clicks, prepares a validated Render Package, generates a creator story, and reaches `READY_TO_VISUALIZE`. TypeScript checking, 13 Vitest suites, 74 tests, and the production build pass.
