# Release Fix 25.2 — Design Completeness and Conflict Validation

## Scope

Release Fix 25.2 corrects the next failure boundary after Standard continuation and copied-prompt completeness. It does not begin Sprint 26, introduce a new renderer provider, or alter legacy records. The correction operates on canonical vNext records and keeps valid floral placement geometry intact.

The primary regression is `MD-000001`, where the observed design path exposed repeated Peony family resolution, a missing secondary material path, and greenery crossing a hard silence arc. The committed regression fixture uses the same canonical identifier and the evidence shape described in the release brief. A production browser `localStorage` export is still required before claiming that the live customer record has been repaired; the validator therefore reports evidence rather than silently rewriting it.

## Failure boundaries

| Boundary | Evidence | Release Fix 25.2 behavior |
|---|---|---|
| Floral orchestration | Role intent is the authority for primary, secondary, bridge, support, and accent jobs. A secondary role may legitimately be absent when upstream composition does not request one. | The validator distinguishes “secondary not requested” from “secondary requested but lost.” |
| Botanical selection | Each role previously selected independently, allowing several roles to resolve to the same strongest catalog family. | A non-declared single-family collapse across multiple active floral jobs is classified as `ACCIDENTAL_FAMILY_COLLAPSE` and blocks readiness. Declared monobotanical intent remains valid. |
| Inventory resolution | Inventory resolves the approved family; it does not create diversity or repair a collapsed selection. | Unknown, no-match, or unavailable required material blocks canonical readiness rather than being treated as a harmless warning. |
| Blueprint | Prior compilation flattened non-primary placements into a generic supporting phase and hardcoded a greenery sweep that could cross the hard silence interval. | Blueprint placements preserve the canonical orchestration role. A conflicting sweep is reflowed around the authoritative hard silence while floral angles and placement records remain unchanged. |
| ECR and Render | Downstream stages can only be trusted after upstream completeness. | Standard orchestration stops before Blueprint/ECR/Render when a hard completeness issue is present. The copied prompt uses catalog-backed visual characteristics only. |

## Completeness contract

`MoodoorDesignCompletenessService.validate` returns `PASS`, `WARNING`, or `BLOCK`, together with issue codes, source stages, a role trace, and a creator-readable summary. Hard failures include required material loss, accidental family collapse, unavailable required inventory, hard-silence collision, and missing silence/negative-space contracts. Warnings include an unmet family budget or reduced depth expression when the design is otherwise usable.

The validator follows precedence deliberately. A declared intentional monobotanical design is not treated as a family-collapse error. A secondary role that was never requested is not treated as missing. A secondary role that was requested but has no surviving selection, inventory resolution, Blueprint placement, or downstream evidence is a hard stop.

## Standard-mode behavior

When the completeness result is blocked, the Standard creator flow returns `NEEDS_INPUT`, suppresses `renderReady`, and gives the creator one clear refinement action: resolve the design issue. It does not create a false Blueprint, ECR, or render-ready state. Existing technical records remain available to Advanced surfaces for diagnosis.

The creator-facing message is intentionally specific without exposing internal implementation vocabulary as the primary copy: “We need to resolve one part of your design. Multiple floral jobs collapsed into one family without an intentional monobotanical declaration.” The associated issue codes remain available to Advanced inspection and regression tests.

## Greenery and silence reflow

The hard silence interval remains authoritative. When a sweep overlaps it, the reflow helper searches deterministic alternative arcs and preserves the original sweep length, zone identity, SKU, depth plane, and flow direction wherever possible. It does not move floral placements, alter angles, change quantity, or rewrite the approved composition. If no safe alternative exists, the collision remains visible and the record cannot be approved.

## Renderer-facing botanical description

The copied prompt now supplements each botanical line with characteristics already present in the canonical catalog: common name, supported color families, form class, surface, stem behavior, and faux-read category. It does not invent species traits, texture, count, lighting, or visual behavior. Internal family IDs and SKUs remain provenance data rather than customer-facing prose.

## Verification

The Release Fix 25.2 suite passes with **133 tests across 26 files**, including four new completeness and reflow regressions. TypeScript compilation and the production build pass. The test coverage includes MD-000001 family collapse, requested-secondary loss, intentional monobotanical sharing, hard-silence collision, geometry-preserving reflow, role-preserving Blueprint compilation, and the existing golden Standard flow.

## Explicit stop boundary

Sprint 26 is not started. This release stops after canonical completeness validation, targeted Blueprint reflow, readiness gating, role preservation, and catalog-backed renderer descriptions. A production browser export remains the next evidence step for applying the validator to the actual live `MD-000001` record rather than the committed regression representation.
