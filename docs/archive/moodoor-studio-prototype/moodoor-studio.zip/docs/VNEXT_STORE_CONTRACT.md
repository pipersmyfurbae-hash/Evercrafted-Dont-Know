# vNext Store Contract

## Record contract

Native designs use the `VNextDesign` contract in `client/src/data/vnext.ts`. The record keeps structured sections instead of flattening the design into a single object.

| Section | Purpose |
|---|---|
| `canonical_id` | Immutable Moodoor-generated ID such as `MD-000001`; never a legacy ID. |
| `schema_version` | `vnext.design.v1`. |
| `identity` | Working name, product type, size, season, and notes. |
| `origin` | Origin type, source reference, source label, and creating flow. |
| `essence` | Separate `memory`, `essence`, and emotional tags. |
| `predicted_evs` / `observed_evs` | Seven-axis vectors kept separate; optional for drafts. |
| `effective_evs` | Runtime selection with explicit source. |
| `design` | Blueprint, materials, renders, stories, and collections. |
| `commerce` / `production` / `publishing` | Reserved structured sections for later sprints. |
| `legacy_aliases` | Preserved source aliases for explicit legacy forks. |
| `raw_legacy` | Provenance payload for forked records; unknown data is not flattened. |
| `created_at`, `updated_at`, `revision`, `status` | Lifecycle and revision metadata. |

## Validation

Persisted native records are validated before create and update. Validation requires the canonical ID, schema version, name, origin, timestamps, revision at least one, valid status, structured aliases, and EVS values between 0 and 1 when present. Predicted and observed vectors cannot be collapsed. Invalid records throw an error and are not silently repaired.

## ID behavior

`MoodoorIdService` determines the next stable sequence from existing native IDs. The ID is generated once, is not title-derived, and remains unchanged across edits, archive, restore, and unified-library reads.

## References

[1]: ../client/src/data/vnext.ts "VNextDesign contract and validation"
[2]: ../client/src/data/models.ts "Runtime EVS axes and normalized models"

[1] [2]
