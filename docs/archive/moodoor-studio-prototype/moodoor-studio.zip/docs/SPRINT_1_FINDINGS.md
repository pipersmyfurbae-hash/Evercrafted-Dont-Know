# Moodoor Sprint 1 Findings

## What was built

Sprint 1 now has a separate React Studio application at `/home/ubuntu/moodoor-studio`. It is a read-only compatibility foundation beside the legacy Moodoor project. The application includes a persistent operator frame, explicit Development Fixture Mode, Home, Library, design detail, and internal Data Health routes.

## Canonical models created

The runtime model layer defines `MoodoorDesign`, `LegacyAlias`, `EVSVector`, `StoryRef`, `RenderRef`, `CollectionRef`, `BlueprintRef`, `MaterialRef`, `CommerceRef`, `ProductionRef`, and `PublishingRef`. Models retain predicted and observed EVS separately, raw source records, aliases, source counts, and relationship status.

## Adapters created

Read-only adapters exist for LibraryItems, catalog, stories, renders, collections, blueprints, and featured/public compatibility records. Each adapter preserves `source`, `sourceId`, normalized data, raw data, parsing errors, and missing relationships.

## Identity resolver results

The resolver follows exact LibraryItem ID, explicit foreign key, stable blueprint ID, known legacy alias, and candidate-only evidence. Candidate/fuzzy matching never auto-merges. The fixture set yields three exact canonical LibraryItem matches, five visible aliases, no ambiguous matches, and two orphan relationships.

## Crosswalk behavior

Legacy aliases are retained in runtime memory and shown in the Library and detail views. No old ID is rewritten. No identity map is persisted and no legacy storage key is touched.

## Data health findings

The fixture-mode diagnostics report three LibraryItems, three catalog records, three stories, three renders, two collections, and one constructor-level order fixture. Two render payloads are missing because binary assets are absent from the source snapshot. One story is missing from a canonical design, and two relationships are orphaned. These findings remain visible and are not repaired automatically.

## Unresolved dependencies

The missing `image-slot.js`, Prompt Library HTML, bundled pipeline, and standalone Stories Studio remain documented legacy dependencies. They do not block Sprint 1 because rendering, prompt text, public image handling, and Story behavior were not changed.

## Files created

| Area | Files |
|---|---|
| Runtime | `client/src/data/models.ts`, `evs.ts`, `adapters.ts`, `resolver.ts`, `service.ts` |
| UI | `client/src/App.tsx`, `client/src/pages/Home.tsx`, `Library.tsx`, `DesignDetail.tsx`, `DataHealth.tsx`, `index.css` |
| Fixtures | `client/src/data/fixtures/*.json` |
| Documentation | `docs/SPRINT_1_ARCHITECTURE.md`, `COMPATIBILITY_LAYER.md`, `STUDIO_ROUTE_MAP.md`, `DATA_HEALTH_REPORT.md`, `SPRINT_1_FINDINGS.md` |
| Design | `ideas.md` and generated Moodoor visual assets referenced through lifecycle-safe storage URLs |

## Files modified

Only files inside the new `/home/ubuntu/moodoor-studio` project were modified. The original Evercrafted/Moodoor legacy source files were not modified.

## Regression results

`pnpm check` passes with zero TypeScript errors. `pnpm build` passes and produces the static application bundle. Representative screenshots were captured for Home, Library, detail, and Data Health. The new application contains no localStorage calls, no `MoodoorData` imports, no mutation methods, no migration controls, and no public Moodoor route changes. The build emits a non-blocking chunk-size warning and a runtime asset-resolution warning for the lifecycle-safe paper texture URL; the image URL is intentionally preserved for deployment.

## Recommendations for Sprint 2

Sprint 2 should begin only after review of the compatibility foundation. The next safe increment is a real-store read adapter behind an explicit source selector, with cloned exports, fixture/real-data isolation, and regression tests before any new create or mutation engine is considered. Rendering, prompt, Story, Collection, Campaign, Production, and public-site migrations remain outside this completion boundary.

## References

[1]: SPRINT_1_ARCHITECTURE.md "Sprint 1 architecture"
[2]: COMPATIBILITY_LAYER.md "Compatibility contract"
[3]: DATA_HEALTH_REPORT.md "Fixture-mode data health"
[4]: STUDIO_ROUTE_MAP.md "Studio routes"
[5]: ../client/src/data/service.ts "Unified service"
[6]: ../client/src/pages/ "Read-only Studio pages"

[1] [2] [3] [4] [5] [6]
