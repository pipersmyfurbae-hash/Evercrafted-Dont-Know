# Clock Coordinate System

Moodoor uses one canonical wreath clock convention for all compositional engines.

> **12:00 = 0 degrees. Degrees increase clockwise. 3:00 = 90 degrees, 6:00 = 180 degrees, and 9:00 = 270 degrees.**

Clock values use `H:MM` with twelve-hour human-facing language. Internal angular values are degrees in the range 0–360 and are used only for validation and diagram rendering. `clockToAngle` and `angleToClock` are the shared conversion functions; later engines must not invent alternate mappings.

A focal area is always a zone with a center, start, and end clock. A secondary movement, eye entry, eye rest, flow, negative-space preference, and silence zone also use clock language. The UI prioritizes human-readable clock values and keeps raw angular math out of the primary operator surface.

## References

[1]: ../client/src/data/focal.ts "Clock conversion helpers"
[2]: ../client/src/pages/DesignDetail.tsx "Circular composition instrument"

[1] [2]
