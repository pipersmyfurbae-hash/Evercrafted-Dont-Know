# Moodoor Studio Sprint 1 — Design Direction

## Approach 1

**Theme Name:** Botanical Instrument Panel

**Very Brief Intro:** A quiet operator console where data is treated like a material: warm paper, ink-black structure, and botanical green signals. The mood is editorial, precise, and calm under complexity.

**Probability:** 0.07

## Approach 2

**Theme Name:** Midnight Render Lab

**Very Brief Intro:** A dark studio with luminous diagnostics, deep charcoal surfaces, and electric accents that make identity health feel like a live instrument readout. The mood is investigative and technical.

**Probability:** 0.03

## Approach 3

**Theme Name:** Archive of Quiet Things

**Very Brief Intro:** A museum-like archive with generous cream space, serif typography, and restrained brass/lichen cues. Records feel conserved, labeled, and worthy of careful handling.

**Probability:** 0.06

## Chosen Approach: Botanical Instrument Panel

### Design Movement
Contemporary editorial modernism with references to botanical field journals and specialist conservation catalogs.

### Core Principles
1. **Evidence before ornament:** every surface should clarify provenance, identity health, or relationship state.
2. **Quiet density:** information is compact but never cramped, using rails, labels, and intentional whitespace instead of card sprawl.
3. **Material contrast:** warm paper, dark ink, lichen green, and brass marks distinguish source facts from system interpretation.
4. **Visible uncertainty:** ambiguous and orphan records are presented as first-class states, never hidden behind optimistic UI.

### Color Philosophy
The palette starts with aged paper and mineral ink to make the interface feel like a well-kept working archive. Lichen green is the ownable signal for resolved identity and healthy continuity; oxidized brass marks provenance and emphasis; clay red is reserved for ambiguity, broken links, and unresolved evidence. Color carries semantic weight instead of decoration.

### Layout Paradigm
A persistent left rail establishes the Studio as an internal tool. The main canvas uses an asymmetric split: a broad record field on the left and a narrow diagnostic/provenance rail on the right. Library cards behave like labeled archive drawers rather than generic dashboards. Detail pages use a two-column evidence spread with raw source records visible beside normalized interpretation.

### Signature Elements
- A small **field-note index** in every major header: sprint, mode, record count, and source state.
- **Identity ribbons** that combine status, evidence tier, and source alias count.
- A **seven-axis EVS strip** rendered as calibrated dots and fine rules, not a generic chart.

### Interaction Philosophy
Interactions should feel like opening a drawer in a reference archive: immediate, reversible, and explicit. Filters update read-only results without hidden state. Hovering reveals provenance, but key evidence remains visible without hover. No destructive actions exist in Sprint 1.

### Animation
Use short 160–220ms ease-out transitions for rail selection, filter changes, and record expansion. Entrance motion is a restrained opacity/translate reveal for the first content block only. Never animate metrics or imply data change. Respect reduced-motion preferences.

### Typography System
Use **DM Serif Display** for page titles and record names, paired with **IBM Plex Sans** for interface text and **IBM Plex Mono** for IDs, evidence tiers, and source names. Display typography should be editorial and warm; operational labels should be crisp, compact, and highly legible.

### Brand Essence
Moodoor Studio is the quiet compatibility desk for operators who need to see what Moodoor knows, what it only suspects, and what must remain untouched. Personality: **observant, exacting, composed**.

### Brand Voice
Headlines are concise and evidentiary. CTAs describe the action rather than selling it. Microcopy names uncertainty without apology.

Example lines:
- “A library view with the seams left visible.”
- “Nothing here writes back to legacy.”

### Wordmark & Logo
Use a compact **open-ring mark**: a dark botanical stem forming three-quarters of a circle, with the missing quarter rendered as a brass calibration tick. It signals a design record that is understood but still leaves room for evidence.

### Signature Brand Color
**Lichen Green `#627A62`** — a muted, ownable green that reads as continuity, not decoration.

## Style Decisions

- The Studio uses an editorial archive language, not a generic SaaS dashboard.
- Fixture mode is visually prominent and never blended with real data.
- Identity health is always visible in the record list and detail view.
- Red is reserved for unresolved relationships; green is reserved for exact/resolved continuity.
